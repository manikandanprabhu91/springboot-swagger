package com.cargill.customerfacing.dscportal.domain;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
public class ContractTest {

  Contract contract;
  
  @Before
  public void setupMock() {
    MockitoAnnotations.initMocks(this);
    contract = new Contract();
  }
  
  @Test
  public void testGetContractId() {
    contract.getContractId();
  }

  @Test
  public void testSetContractId() {
    contract.setContractId(1);
  }

  @Test
  public void testGetCakNo() {
    contract.getCakNo();
  }

  @Test
  public void testSetCakNo() {
    contract.setCakNo("16");
  }

  @Test
  public void testGetCakDate() {
    contract.getCakDate();
  }

  @Test
  public void testSetCakDate() {
    contract.setCakDate("10/11/2017");
  }

  @Test
  public void testGetCommodity() {
    contract.getCommodity();
  }

  @Test
  public void testSetCommodity() {
    contract.setCommodity("SBM");
  }

  @Test
  public void testGetQuantity() {
    contract.getQuantity();
  }

  @Test
  public void testSetQuantity() {
    contract.setQuantity(1);
  }

  @Test
  public void testGetReceived() {
    contract.getReceived();
  }

  @Test
  public void testSetReceived() {
    contract.setReceived(10);
  }

  @Test
  public void testGetBalanceStock() {
    contract.getBalanceStock();
  }

  @Test
  public void testSetBalanceStock() {
    contract.setBalanceStock(100);;
  }

  @Test
  public void testGetContractType() {
    contract.getContractType();
  }

  @Test
  public void testSetContractType() {
    contract.setContractType("Service");
  }

  @Test
  public void testGetCustomerId() {
    contract.getCustomerId();
  }

  @Test
  public void testSetCustomerId() {
    contract.setCustomerId("123");
  }

  @Test
  public void testGetContractStatus() {
    contract.getContractStatus();
  }

  @Test
  public void testSetContractStatus() {
    contract.setContractStatus("Unsigned");
  }

  @Test
  public void testGetContractTypeId() {
    contract.getContractTypeId();
  }

  @Test
  public void testSetContractTypeId() {
    contract.setContractTypeId(1);
  }

  @Test
  public void testGetStatusId() {
    contract.getStatusId();
  }

  @Test
  public void testSetStatusId() {
    contract.setStatusId("1");
  }

  @Test
  public void testGetContractCategory() {
    contract.getContractCategory();
  }

  @Test
  public void testSetContractCategory() {
    contract.setContractCategory("VNGOSC");
  }

  @Test
  public void testGetBasis() {
    contract.getBasis();
  }

  @Test
  public void testSetBasis() {
    contract.setBasis("basis");
  }

  @Test
  public void testGetTendered() {
    contract.getTendered();
  }

  @Test
  public void testSetTendered() {
    contract.setTendered(10);
  }

  @Test
  public void testGetDestination() {
    contract.getDestination();
  }

  @Test
  public void testSetDestination() {
    contract.setDestination("location");
  }

  @Test
  public void testGetCurrency() {
    contract.getCurrency();
  }

  @Test
  public void testSetCurrency() {
    contract.setCurrency("doller");
  }

  @Test
  public void testGetPaymentTerms() {
    contract.getPaymentTerms();
  }

  @Test
  public void testSetPaymentTerms() {
    contract.setPaymentTerms("Terms");
  }

  @Test
  public void testGetTolarance() {
    contract.getTolarance();
  }

  @Test
  public void testSetTolarance() {
    contract.setTolarance(1);
  }

  @Test
  public void testGetShipPeriod() {
    contract.getShipPeriod();
  }

  @Test
  public void testSetShipPeriod() {
    contract.setShipPeriod("12/12/2017");
  }

  @Test
  public void testGetPackageType() {
    contract.getPackageType();
  }

  @Test
  public void testSetPackageType() {
    contract.setPackageType("Type");
  }

  @Test
  public void testGetFinalWeightAt() {
    contract.getFinalWeightAt();
  }

  @Test
  public void testSetFinalWeightAt() {
    contract.setFinalWeightAt("wet");
  }

  @Test
  public void testGetCargoOrigin() {
    contract.getCargoOrigin();
  }

  @Test
  public void testSetCargoOrigin() {
    contract.setCargoOrigin("cargoOrigin");
  }

  @Test
  public void testGetContractPrice() {
    contract.getContractPrice();
  }

  @Test
  public void testSetContractPrice() {
    contract.setContractPrice(100);
  }

  @Test
  public void testGetUnitPrice() {
    contract.getUnitPrice();
  }

  @Test
  public void testSetUnitPrice() {
    contract.setUnitPrice(10);
  }

  @Test
  public void testGetStorageTerms() {
    contract.getStorageTerms();
  }

  @Test
  public void testSetStorageTerms() {
    contract.setStorageTerms("ST");
  }

  @Test
  public void testGetErpContractStatus() {
    contract.getErpContractStatus();
  }

  @Test
  public void testSetErpContractStatus() {
    contract.setErpContractStatus(1);
  }

}
