package com.cargill.customerfacing.dscportal.impl;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cargill.customerfacing.dscportal.domain.Contract;
import com.cargill.customerfacing.dscportal.domain.Customer;
import com.cargill.customerfacing.dscportal.domain.Status;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.repository.ContractRepository;
import com.cargill.customerfacing.dscportal.service.IContractService;

@RunWith(SpringJUnit4ClassRunner.class)
public class VietnamContractServiceImplTest {
  
  @Mock
  IContractService iContractService;
  
  VietnamContractServiceImpl vietnamContractServiceImpl;
  
  ContractRepository contractRepository;
  
  Contract contract;
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      vietnamContractServiceImpl = new VietnamContractServiceImpl();
      contractRepository = Mockito.mock(ContractRepository.class);
      vietnamContractServiceImpl.contractRepository = contractRepository;
      contract = new Contract();
      contract.setBalanceStock(100);
      contract.setBasis("basis");
      contract.setCakDate("10/11/2017");
      contract.setCakNo("15");
      contract.setCargoOrigin("cargoOrigin");
      contract.setCommodity("SBM");
      contract.setContractCategory("VNGOSC");
      contract.setContractId(1);
      contract.setContractPrice(100);
      contract.setContractStatus("Unsigned");
      contract.setContractType("Service");
      contract.setContractTypeId(1);
      contract.setErpContractStatus(1);
      contract.setCurrency("doller");
      contract.setCustomerId("123");
      contract.setDestination("Desc");
      contract.setFinalWeightAt("wet");
      contract.setPackageType("Type");
      contract.setPaymentTerms("Terms");
      contract.setQuantity(123);
      contract.setReceived(10);
      contract.setShipPeriod("12/12/2017");
      contract.setStatusId("1");
      contract.setStorageTerms("ST");
      contract.setTendered(10);
      contract.setTolarance(1);
      contract.setUnitPrice(10);
  }

  @Test
  public void testGetContractlist() throws BaseClassException {
   // List<Contract> contracts = vietnamContractServiceImpl.getContractlist("Service", "Unsigned", "VNGOSC", "rk@crgl.com","S",1,10);
//    assertTrue(contracts.size()==0);
  }

  @Test
  public void testGetContract() throws BaseClassException{
//    List<Contract> contract = vietnamContractServiceImpl.getContract(1, "VNGOSC", "rk@crgl.com");
//    assertTrue(contract==null);
  }

  @Test
  public void testInsertContract() throws BaseClassException{
    //Contract insertC = vietnamContractServiceImpl.insertContract(contract, "rk@crgl.com","VNGOSC");
//    assertTrue(insertC ==null);
  }

  @Test
  public void testUpdateContract() throws BaseClassException{
    //int updateC = vietnamContractServiceImpl.updateContract(contract, 1,  "rk@crgl.com");
//    assertTrue(updateC ==0);
  }

  @Test
  public void testDeleteContract() throws BaseClassException{
    //int deleteC = vietnamContractServiceImpl.deleteContract(1, "rk@crgl.com");
//    assertTrue(deleteC ==0);
  }

  @Test
  public void testGetStatusList() throws BaseClassException{
    List<Status> status = vietnamContractServiceImpl.getStatusList("payment");
    assertTrue(status.size()==0);
  }

  @Test
  public void testGetCustomerList() throws BaseClassException{
    List<Customer> customers = vietnamContractServiceImpl.getCustomerList("VNGOSC");
    assertTrue(customers.size()==0);
  }

}
