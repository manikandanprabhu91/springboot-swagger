package com.cargill.customerfacing.dscportal.domain;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
public class UserAlertMappingTest {

  UserAlertMapping userAlertMapping;
  
  @Before
  public void setupMock() {
    MockitoAnnotations.initMocks(this);
    userAlertMapping = new UserAlertMapping();
  }
  
  @Test
  public void testGetUserId() {
   userAlertMapping.getUserId();
  }

  @Test
  public void testSetUserId() {
   userAlertMapping.setUserId("rk@gmail.com");
  }

  @Test
  public void testGetMessage() {
   userAlertMapping.getMessage();
  }

  @Test
  public void testSetMessage() {
   userAlertMapping.setMessage("");
  }

  @Test
  public void testGetWeb() {
   userAlertMapping.getWeb();
  }

  @Test
  public void testSetWeb() {
   userAlertMapping.setWeb("Y");
  }

  @Test
  public void testGetEmail() {
   userAlertMapping.getEmail();
  }

  @Test
  public void testSetEmail() {
   userAlertMapping.setEmail("e@gmail.com");
  }

  @Test
  public void testGetSms() {
   userAlertMapping.getSms();
  }

  @Test
  public void testSetSms() {
   userAlertMapping.setSms("Y");
  }

  @Test
  public void testGetAlertId() {
   userAlertMapping.getAlertId();
  }

  @Test
  public void testSetAlertId() {
   userAlertMapping.setAlertId(1);
  }

}
