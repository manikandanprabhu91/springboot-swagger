package com.cargill.customerfacing.dscportal.impl;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cargill.customerfacing.dscportal.domain.ApprovedQuantity;
import com.cargill.customerfacing.dscportal.domain.Payment;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.repository.PaymentRepository;
import com.cargill.customerfacing.dscportal.service.IPaymentService;

@RunWith(SpringJUnit4ClassRunner.class)
public class VietnamPaymentImplTest {
  
  @Mock
  IPaymentService iPaymentService;
  
  VietnamPaymentImpl vietnamPaymentImpl;
  
  PaymentRepository paymentRepository;
  
  Payment payment;
  
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      vietnamPaymentImpl = new VietnamPaymentImpl();
      paymentRepository = Mockito.mock(PaymentRepository.class);
      vietnamPaymentImpl.paymentRepository = paymentRepository;
      payment = new Payment();
      payment.setPaymentAmount(10000);
      payment.setContractId(1);
      payment.setPaymentDate("2017-12-26");
      payment.setFile("filename");
      payment.setPaymentId(1);
      payment.setStatusCode("NPD");
      payment.setStatusDesc("");
      payment.setStatusDescription("");
  }

  @Test
  public void testGetPaymentList() throws BaseClassException {
    List<Payment> payments = vietnamPaymentImpl.getPaymentList(1, "rk@gmail.com");
    assertTrue(payments.size()==0);
  }

  @Test
  public void testInsertPayment() throws BaseClassException {
    Payment insert = vietnamPaymentImpl.insertPayment(payment, "rk@gmail.com");
    assertTrue(insert ==null);
  }

  @Test
  public void testUpdatePayment() throws BaseClassException {
    int updatPay = vietnamPaymentImpl.updatePayment(payment, "rk@gmail.com", null);
    assertTrue(updatPay ==0);
  }

  @Test
  public void testDeletePayment() throws BaseClassException {
    int delPay = vietnamPaymentImpl.deletePayment(1, 1, "rk@gmail.com");
    assertTrue(delPay ==0);
  }

  @Test
  public void testUpdateApprovedQuantity() throws BaseClassException {
    ApprovedQuantity approvedQuantity = new ApprovedQuantity();
    approvedQuantity.setApprovedQty(100);
    approvedQuantity.setApprovedQuantityId(1);
    approvedQuantity.setContractId(1);
    ApprovedQuantity updataqty = vietnamPaymentImpl.updateApprovedQuantity(approvedQuantity, "rk@gmail.com","");
    assertTrue(updataqty ==null);
  }

  @Test
  public void testGetApprovedQuantityList() throws BaseClassException {
    ApprovedQuantity informations = vietnamPaymentImpl.getApprovedQuantityList(1);
    assertTrue(informations == null);
  }

}
