package com.cargill.customerfacing.dscportal.domain;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
public class ArrivalScheduleTest
{
    
    ArrivalSchedule arrivalSchedule;
    
    @Before
    public void setupMock()
    {
        MockitoAnnotations.initMocks(this);
        arrivalSchedule = new ArrivalSchedule();
    }
    
    @Test
    public void testGetCommodity()
    {
        arrivalSchedule.getCommodity();
    }
    
    @Test
    public void testSetCargo()
    {
        arrivalSchedule.setCommodity("commodity");
    }
    
    @Test
    public void testGetTendered()
    {
        arrivalSchedule.getTendered();
    }
    
    @Test
    public void testSetTendered()
    {
        arrivalSchedule.setTendered("ss");
    }
    
    @Test
    public void testGetApprovedQuantity()
    {
        arrivalSchedule.getApprovedQuantity();
    }
    
    @Test
    public void testSetApprovedQuantity()
    {
        arrivalSchedule.setApprovedQuantity(10);
    }
    
    @Test
    public void testGetShipmentPeriod()
    {
        arrivalSchedule.getShipmentPeriod();
    }
    
    @Test
    public void testSetShipmentPeriod()
    {
        arrivalSchedule.setShipmentPeriod("period");
    }
    
    @Test
    public void testGetVesselName()
    {
        arrivalSchedule.getVesselName();
    }
    
    @Test
    public void testSetVesselName()
    {
        arrivalSchedule.setVesselName("SN");
    }
    
    @Test
    public void testGetWareHouse()
    {
        arrivalSchedule.getWareHouse();
    }
    
    @Test
    public void testSetWareHouse()
    {
        arrivalSchedule.setWareHouse("soy");
    }
    
    @Test
    public void testGetEtaDate()
    {
        arrivalSchedule.getEtaDate();
    }
    
    @Test
    public void testSetEta()
    {
        arrivalSchedule.setEtaDate("2017-12-11");
    }
    
    @Test
    public void testGetEtaTime()
    {
        arrivalSchedule.getEtaTime();
    }
    
    @Test
    public void testSetTime()
    {
        arrivalSchedule.setEtaTime("00:00");
    }
    
    @Test
    public void testGetArrivalScheduleId()
    {
        arrivalSchedule.getArrivalScheduleId();
    }
    
    @Test
    public void testSetArrivalScheduleId()
    {
        arrivalSchedule.setArrivalScheduleId(1);
    }
    
    @Test
    public void testGetContractId()
    {
        arrivalSchedule.getContractId();
    }
    
    @Test
    public void testSetContractId()
    {
        arrivalSchedule.setContractId(1);
    }
    
    @Test
    public void testGetDeliveryBasis()
    {
        arrivalSchedule.getDeliveryBasis();
    }
    
    @Test
    public void testSetDeliveryBasis()
    {
        arrivalSchedule.setDeliveryBasis("basis");
    }
}
