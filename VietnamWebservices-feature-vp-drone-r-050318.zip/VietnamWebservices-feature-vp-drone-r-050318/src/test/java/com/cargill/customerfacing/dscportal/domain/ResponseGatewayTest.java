package com.cargill.customerfacing.dscportal.domain;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
public class ResponseGatewayTest {

  ResponseGateway responseGateway;
  
  @Before
  public void setupMock() {
    MockitoAnnotations.initMocks(this);
    responseGateway = new ResponseGateway();
  }
  
  @Test
  public void testGetStatusCode() {
    responseGateway.getStatusCode();
  }

  @Test
  public void testSetStatusCode() {
    responseGateway.setStatusCode("500");
  }

  @Test
  public void testGetMessage() {
    responseGateway.getMessage();
  }

  //@Test
  public void testSetMessage() {
    //responseGateway.setMessage(List<T> message);
  }

  @Test
  public void testGetStatus() {
    responseGateway.getStatus();
  }

  @Test
  public void testSetStatus() {
    responseGateway.setStatus("status");
  }

//  @Test
//  public void testGetObjMessage() {
//    responseGateway.getObjMessage();
//  }
//
//  @Test
//  public void testSetObjMessage() {
//    responseGateway.setObjMessage("");
//  }

}
