package com.cargill.customerfacing.dscportal.domain;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
public class UserConfigTest {
  
  UserConfig userConfig;
  
  @Before
  public void setupMock() {
    MockitoAnnotations.initMocks(this);
    userConfig = new UserConfig();
  }
  
  @Test
  public void testGetUserId() {
    userConfig.getUserId();
  }

  @Test
  public void testSetUserId() {
    userConfig.setUserId("");
  }

  @Test
  public void testGetScreenId() {
    userConfig.getScreenId();
  }

  @Test
  public void testSetScreenId() {
    userConfig.setScreenId(1);
  }

  @Test
  public void testGetSectionId() {
    userConfig.getSectionId();
  }

  @Test
  public void testSetSectionId() {
    userConfig.setSectionId(1);
  }

  @Test
  public void testGetAttributeId() {
    userConfig.getAttributeId();
  }

  @Test
  public void testSetAttributeId() {
    userConfig.setAttributeId(1);
  }

  @Test
  public void testGetAttributeValue() {
    userConfig.getAttributeValue();
  }

  @Test
  public void testSetAttributeValue() {
    userConfig.setAttributeValue("");
  }

  @Test
  public void testGetUserConfigCol() {
    userConfig.getUserConfigCol();
  }

  @Test
  public void testSetUserConfigCol() {
    userConfig.setUserConfigCol("");
  }

}
