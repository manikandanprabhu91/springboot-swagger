package com.cargill.customerfacing.dscportal.webservices;

import static org.junit.Assert.assertTrue;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cargill.customerfacing.dscportal.domain.PickUpSchedule;
import com.cargill.customerfacing.dscportal.domain.ResponseGateway;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.region.factory.RegionFactoryService;
import com.cargill.customerfacing.dscportal.service.IPickUpSchedule;

@RunWith(SpringJUnit4ClassRunner.class)
public class PickUpScheduleControllerTest {

  RegionFactoryService regionFactoryService;
  
  PickUpScheduleController pickUpScheduleController;
  
  @Mock
  IPickUpSchedule iPickUpSchedule;
  
  PickUpSchedule pickUpSchedule;
  @Mock
  HttpServletResponse response;
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      pickUpScheduleController = new PickUpScheduleController();
      regionFactoryService = Mockito.mock(RegionFactoryService.class);
      regionFactoryService = new RegionFactoryService();
      regionFactoryService.setVietnamPickUpScheduleService(iPickUpSchedule);
      pickUpScheduleController.regionFactoryService = regionFactoryService;
      pickUpSchedule = new PickUpSchedule();
      pickUpSchedule.setApprovedPickUpDate("2012-04-04 04:03:35");
      pickUpSchedule.setArrivalScheduleId(1);
      pickUpSchedule.setContractId(1);
      pickUpSchedule.setPickUpDate("2012-04-04 04:03:35");
      pickUpSchedule.setFileName("vietnam");
      pickUpSchedule.setPickUpId(1);
      pickUpSchedule.setPickUpQty(156);
      pickUpSchedule.setStatus("Agree");
  }
  
  @Test
  public void testInsertPickUpSchedule() throws BaseClassException{
    ResponseEntity<ResponseGateway> ePickup =  pickUpScheduleController.insertPickUpSchedule(pickUpSchedule,"VNGOSC","rk@gmail.com");
    assertTrue(ePickup.getStatusCode()  == HttpStatus.valueOf(200));
  }
  
  @Test
  public void testInsertNPickUpSchedule() throws BaseClassException{
    pickUpScheduleController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
    gateway = pickUpScheduleController.insertPickUpSchedule(pickUpSchedule,"VNGOSC","rk@gmail.com");
    assertTrue(gateway.getStatusCode()  == HttpStatus.valueOf(200));
  }
  
  
  @Test
  public void testGetPickUpScheduleList() throws BaseClassException{
    ResponseEntity<ResponseGateway> pickUpSchedules= pickUpScheduleController.getPickUpScheduleList(1,"VNGOSC","rk@gmail.com");
    assertTrue(pickUpSchedules.getStatusCode()  == HttpStatus.valueOf(200));
    
    pickUpScheduleController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
    gateway = pickUpScheduleController.getPickUpScheduleList(1,"VNGOSC","rk@gmail.com");
    assertTrue(gateway.getStatusCode()  == HttpStatus.valueOf(200));
  }
  
  @Test
  public void testGetPickUpScheduleBYID() throws BaseClassException {
    ResponseEntity<ResponseGateway>  pickUpSchedule = pickUpScheduleController.getPickUpScheduleBYID(1, "VNGOSC",1);
    assertTrue(pickUpSchedule.getStatusCode()  == HttpStatus.valueOf(200));
    
    pickUpScheduleController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
    gateway =  pickUpScheduleController.getPickUpScheduleBYID(1, "VNGOSC",1);
      assertTrue(gateway.getStatusCode()  == HttpStatus.valueOf(200));
  }
  
  @Test
  public void testUpdatePickUpSchedule() throws BaseClassException {
    ResponseEntity<ResponseGateway> updatePickup =  pickUpScheduleController.updatePickUpSchedule(1,pickUpSchedule,"VNGOSC","rk@gmail.com");
    assertTrue(updatePickup.getStatusCode()  == HttpStatus.valueOf(200));
    
    pickUpScheduleController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
    gateway = pickUpScheduleController.updatePickUpSchedule(1,pickUpSchedule,"VNGOSC","rk@gmail.com");
      assertTrue(gateway.getStatusCode()  == HttpStatus.valueOf(200));
  }

  @Test
  public void testDeletePickUpSchedule() throws BaseClassException{
    ResponseEntity<ResponseGateway> del =   pickUpScheduleController.deletePickUpSchedule(1,"VNGOSC","rk@gmail.com",1);
    assertTrue(del.getStatusCode()  == HttpStatus.valueOf(200));
    
    pickUpScheduleController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
    gateway= pickUpScheduleController.deletePickUpSchedule(1,"VNGOSC","rk@gmail.com",1);
      assertTrue(gateway.getStatusCode()  == HttpStatus.valueOf(200));
  }
  
  @Test
  public void testGenerateQRCode() throws BaseClassException, IOException{
    pickUpScheduleController.generateQRCode(1, 1, null, response);
  }

}
