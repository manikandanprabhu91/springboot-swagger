package com.cargill.customerfacing.dscportal.domain;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
public class InvoiceTest {
  
  Invoice invoice;
  
  @Before
  public void setupMock() {
    MockitoAnnotations.initMocks(this);
    invoice = new Invoice();
  }
  

  @Test
  public void testGetInvoiceNo() {
    invoice.getInvoiceNo();
  }

  @Test
  public void testSetInvoiceNo() {
    invoice.setInvoiceNo(1);
  }

  @Test
  public void testGetInvoiceDate() {
    invoice.getInvoiceDate();
  }

  @Test
  public void testSetInvoiceDate() {
    invoice.setInvoiceDate("2017-12-23");
  }

  @Test
  public void testGetCargoVolume() {
    invoice.getCommodityQty();
  }

  @Test
  public void testSetCargoVolume() {
    invoice.setCommodityQty(123);
  }

  @Test
  public void testGetInvoiceAmount() {
    invoice.getInvoiceAmount();
  }

  @Test
  public void testSetInvoiceAmount() {
    invoice.setInvoiceAmount(2011);
  }

  @Test
  public void testGetFileName() {
    invoice.getFileName();
  }

  @Test
  public void testSetFileName() {
    invoice.setFileName("bob");
  }

  @Test
  public void testGetCommodityName() {
    invoice.getCommodityName();
  }

  @Test
  public void testSetCargoName() {
    invoice.setCommodityName("cargoName");
  }

  @Test
  public void testGetContractId() {
    invoice.getContractId();
  }

  @Test
  public void testSetContractId() {
    invoice.setContractId(1);
  }

}
