package com.cargill.customerfacing.dscportal.exception;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
public class BaseClassExceptionTest {

  Exception exception;
  
  BaseClassException baseClassException;
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      baseClassException = Mockito.mock(BaseClassException.class);
  }
  
  @Test
  public void testGetException() {
    baseClassException.getException();
  }

  @Test
  public void testCatchException() {
    BaseClassException.catchException("500");
    BaseClassException.catchException("400");
  }

}
