package com.cargill.customerfacing.dscportal.webservices;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cargill.customerfacing.dscportal.domain.MarketInformation;
import com.cargill.customerfacing.dscportal.domain.ResponseGateway;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.region.factory.RegionFactoryService;
import com.cargill.customerfacing.dscportal.service.IMarketInformation;

@RunWith(SpringJUnit4ClassRunner.class)
public class MarketInformationControllerTest {

  RegionFactoryService regionFactoryService;

  MarketInformationController marketInformationController;
  
  @Mock
  IMarketInformation vietnamMarketInformationService;
  
  MarketInformation information;
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      marketInformationController = new MarketInformationController();
      regionFactoryService = Mockito.mock(RegionFactoryService.class);
      regionFactoryService = new RegionFactoryService();
      regionFactoryService.setVietnamMarketInformationService(vietnamMarketInformationService);
      marketInformationController.regionFactoryService = regionFactoryService;
      information = new MarketInformation();
      information.setContractCategory("VNGOSC");;
      information.setDetails("Welcome Cargill");
      information.setHeading("Test");
      information.setMarketId(1);
      information.setStatus("Status");
  }
  
  @Test
  public void testGetMarketInfoList() throws BaseClassException {
    ResponseEntity<ResponseGateway> marketInformation =  marketInformationController.getMarketInfoList("VNGOSC", "rk@gmail.com");
    assertTrue(marketInformation.getStatusCode() == HttpStatus.valueOf(200));
    
    marketInformationController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
    gateway=  marketInformationController.getMarketInfoList("VNGOSC", "rk@gmail.com");
    assertTrue(gateway.getStatusCode() == HttpStatus.valueOf(200));
  }

  @Test
  public void testInsertMarketInformation() throws BaseClassException {
    ResponseEntity<ResponseGateway> insertstaus = marketInformationController.insertMarketInformation(information,"VNGOSC","rk@gmail.com");
    assertTrue(insertstaus.getStatusCode() == HttpStatus.valueOf(200));
    
    marketInformationController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
      gateway= marketInformationController.insertMarketInformation(information,"VNGOSC","rk@gmail.com");
      assertTrue(gateway.getStatusCode() == HttpStatus.valueOf(200));
  }

  @Test
  public void testUpdateMarketInformation() throws BaseClassException {
    ResponseEntity<ResponseGateway> updatestaus = marketInformationController.updateMarketInformation(information,"VNGOSC","rk@gmail.com");
    assertTrue(updatestaus.getStatusCode() == HttpStatus.valueOf(200));
    
    marketInformationController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
      gateway=  marketInformationController.updateMarketInformation(information,"VNGOSC","rk@gmail.com");
      assertTrue(gateway.getStatusCode() == HttpStatus.valueOf(200));
  }

  @Test
  public void testDeleteMarketInformation() throws BaseClassException {
    ResponseEntity<ResponseGateway>  sa= marketInformationController.deleteMarketInformation(1,"VNGOSC","rk@gmail.com");
    assertTrue(sa.getStatusCode() == HttpStatus.valueOf(200));
    
    marketInformationController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
      gateway=  marketInformationController.deleteMarketInformation(1,"VNGOSC","rk@gmail.com");
      assertTrue(gateway.getStatusCode() == HttpStatus.valueOf(200));
  }

}
