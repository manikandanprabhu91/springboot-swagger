package com.cargill.customerfacing.dscportal.repository;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cargill.customerfacing.dscportal.domain.SetUpAlert;
import com.cargill.customerfacing.dscportal.domain.UserAlertMapping;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;

@RunWith(SpringJUnit4ClassRunner.class)
public class AlertNotificationRepositoryTest{

  AlertNotificationRepository alertNotificationRepository;
  
  JdbcTemplate dynamicNamedParameterJdbcTemplate;
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      alertNotificationRepository = new AlertNotificationRepository();
      dynamicNamedParameterJdbcTemplate = Mockito.mock(JdbcTemplate.class);
      alertNotificationRepository.jdbcTemplate = dynamicNamedParameterJdbcTemplate;
  }
  
  
  @Test
  public void testSetupAlert() throws BaseClassException {
//    SetUpAlert alert = alertNotificationRepository.setupAlert(100, "VNGOSC", 123,"rk@gmail.com",1,0,0);
//    assertTrue(alert==null);
//    
//    alertNotificationRepository.jdbcTemplate = null;
//    boolean thrown = false;
//    try {
//      alertNotificationRepository.setupAlert(100, "VNGOSC", 123,"rk@gmail.com",1,0,0);
//    } catch (Exception e) {
//      thrown = true;
//    }
//    assertTrue(thrown);
  }

  @Test
  public void testGetAlertList() throws BaseClassException {
    List<SetUpAlert> strings = alertNotificationRepository.getAlertList("VNGOSC", "rk@gmail.com", 0, 0);
    assertTrue(strings.isEmpty());
    
    alertNotificationRepository.jdbcTemplate = null;
    boolean thrown = false;
    try {
      alertNotificationRepository.getAlertList("VNGOSC", "rk@gmail.com", 0, 0);
    } catch (Exception e) {
      thrown = true;
    }
    assertTrue(thrown);
  }

  @Test
  public void testUpdateAlert() throws BaseClassException {
    int alert = alertNotificationRepository.updateAlert(1, "Read", "rk@gmail.com");
    assertTrue(alert==0);
    
    alertNotificationRepository.jdbcTemplate = null;
    boolean thrown = false;
    try {
      alertNotificationRepository.updateAlert(1, "Read", "rk@gmail.com");
    } catch (Exception e) {
      thrown = true;
    }
    assertTrue(thrown);
  }

  @Test
  public void testPaymentReminding() throws BaseClassException {
//    SetUpAlert alert = alertNotificationRepository.setupAlert(100, "VNGOSC", 123,"rk@gmail.com",1,0,0);
//    assertTrue(alert==null);
//    
//    alertNotificationRepository.jdbcTemplate = null;
//    boolean thrown = false;
//    try {
//      alertNotificationRepository.setupAlert(100, "VNGOSC", 123,"rk@gmail.com",1,0,0);
//    } catch (Exception e) {
//      thrown = true;
//    }
//    assertTrue(thrown);
  }

  @Test
  public void testGetAlertUserMappingList() throws BaseClassException {
    List<UserAlertMapping> alertMappings = alertNotificationRepository.getAlertUserMappingList("VNGOSC","rk@gmail.com");
    assertTrue(alertMappings.isEmpty());
    
    alertNotificationRepository.jdbcTemplate = null;
    boolean thrown = false;
    try {
      alertNotificationRepository.getAlertUserMappingList("VNGOSC","rk@gmail.com");
    } catch (Exception e) {
      thrown = true;
    }
    assertTrue(thrown);
  }

  @Test
  public void testUpdateAlertUserMapping() throws BaseClassException {
    UserAlertMapping alertMapping = new UserAlertMapping();
    alertMapping.setAlertId(1);
    alertMapping.setEmail("rk@gmail.com");
    alertMapping.setMessage("message");
    alertMapping.setSms("N");
    alertMapping.setUserId("rk@gmail.com");
    alertMapping.setWeb("Y");
    int alert = alertNotificationRepository.updateAlertUserMapping(alertMapping, "VNGOSC","rk@gmail.com");
    assertTrue(alert==0);
    
    alertNotificationRepository.jdbcTemplate = null;
    boolean thrown = false;
    try {
      alertNotificationRepository.updateAlertUserMapping(alertMapping, "VNGOSC","rk@gmail.com");
    } catch (Exception e) {
      thrown = true;
    }
    assertTrue(thrown);
  }

}
