package com.cargill.customerfacing.dscportal.domain;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
public class InventoryTest {

  Inventory inventory;
  
  @Before
  public void setupMock() {
    MockitoAnnotations.initMocks(this);
    inventory = new Inventory();
  }
  
  @Test
  public void testGetCargo() {
    inventory.getCargo();
  }

  @Test
  public void testSetCargo() {
    inventory.setCargo("cargo");
  }

  @Test
  public void testGetVehicleType() {
    inventory.getVehicleType();
  }

  @Test
  public void testSetVehicleType() {
    inventory.setVehicleType("VN");
  }

  @Test
  public void testGetVehicleNo() {
    inventory.getVehicleNo();
  }

  @Test
  public void testSetVehicleNo() {
    inventory.setVehicleNo("TN456");
  }

  @Test
  public void testGetTimeInDate() {
    inventory.getTimeInDate();
  }

  @Test
  public void testSetTimeIn() {
    inventory.setTimeInDate("2017-04-04 04:03:35");
  }

  @Test
  public void testGetWeightIn() {
    inventory.getWeightIn();
  }

  @Test
  public void testSetWeightIn() {
    inventory.setWeightIn(10);
  }

  @Test
  public void testGetTimeOut() {
    inventory.getTimeOutDate();
  }

  @Test
  public void testSetTimeOut() {
    inventory.setTimeOutDate("2017-04-04 04:03:35");
  }

  @Test
  public void testGetWeightOut() {
    inventory.getWeightOut();
  }

  @Test
  public void testSetWeightOut() {
    inventory.setWeightOut(11);
  }

  @Test
  public void testGetPacking() {
    inventory.getPacking();
  }

  @Test
  public void testSetPacking() {
    inventory.setPacking("packing");
  }

  @Test
  public void testGetMode() {
    inventory.getMode();
  }

  @Test
  public void testSetMode() {
    inventory.setMode("Vesseltrucks");
  }

  @Test
  public void testGetLocation() {
    inventory.getLocation();
  }

  @Test
  public void testSetLocation() {
    inventory.setLocation("VTN");
  }

  @Test
  public void testGetPickUpId() {
    inventory.getPickUpId();
  }

  @Test
  public void testGetTotalWeight() {
    inventory.getTotalWeight();
  }

  @Test
  public void testSetTotalWeight() {
    inventory.setTotalWeight(26);
  }

  @Test
  public void testSetPickUpId() {
    inventory.setPickUpId(1);
  }

  @Test
  public void testGetContractType() {
    inventory.getContractType();
  }

  @Test
  public void testSetContractType() {
    inventory.setContractType("Service");
  }

  @Test
  public void testGetRemarks() {
    inventory.getRemarks();
  }

  @Test
  public void testSetRemarks() {
    inventory.setRemarks("remark");
  }

  @Test
  public void testGetContractId() {
    inventory.getContractId();
  }

  @Test
  public void testSetContractId() {
    inventory.setContractId(1);
  }

  @Test
  public void testGetNetWeight() {
    inventory.getNetWeight();
  }

  @Test
  public void testSetNetWeight() {
    inventory.setNetWeight(100);
  }

  @Test
  public void testGetCakNo() {
    inventory.getCakNo();
  }

  @Test
  public void testSetCakNo() {
    inventory.setCakNo("16");
  }

  @Test
  public void testGetEtaDate() {
    inventory.getEtaDate();
  }

  @Test
  public void testSetEtaDate() {
    inventory.setEtaDate("2017-04-04");
  }

  @Test
  public void testGetInventoryId() {
    inventory.getInventoryId();
  }

  @Test
  public void testSetInventoryId() {
    inventory.setInventoryId(1);
  }

}
