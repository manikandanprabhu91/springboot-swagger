package com.cargill.customerfacing.dscportal.domain;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
public class CustomerTest {
  
  Customer customer;
  
  @Before
  public void setupMock() {
    MockitoAnnotations.initMocks(this);
    customer = new Customer();
  }

  @Test
  public void testGetCustomerId() {
    customer.getCustomerId();
  }

  @Test
  public void testSetCustomerId() {
    customer.setCustomerId("123");
  }

  @Test
  public void testGetCustomerName() {
    customer.getCustomerName();
  }

  @Test
  public void testSetCustomerName() {
    customer.setCustomerName("Customer");
  }

  @Test
  public void testGetContractCategory() {
    customer.getContractCategory();
  }

  @Test
  public void testSetContractCategory() {
    customer.setContractCategory("VNGOSC");
  }

}
