package com.cargill.customerfacing.dscportal.webservices;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cargill.customerfacing.dscportal.domain.Invoice;
import com.cargill.customerfacing.dscportal.domain.ResponseGateway;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.region.factory.RegionFactoryService;
import com.cargill.customerfacing.dscportal.service.IInvoice;

@RunWith(SpringJUnit4ClassRunner.class)
public class InvoiceControllerTest {

  RegionFactoryService regionFactoryService;
  
  InvoiceController invoiceController;
  
  @Mock
  IInvoice iInvoice;
  
  Invoice invoice;
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      invoiceController = new InvoiceController();
      regionFactoryService = Mockito.mock(RegionFactoryService.class);
      regionFactoryService = new RegionFactoryService();
      regionFactoryService.setVietnamInvoiceService(iInvoice);
      invoiceController.regionFactoryService = regionFactoryService;
      invoice = new Invoice();
      invoice.setCommodityName("cargoName");
      invoice.setCommodityQty(25);
      invoice.setContractId(1);
      invoice.setFileName("");
      invoice.setInvoiceAmount(2011);
      invoice.setInvoiceDate("2017-12-23");
      invoice.setInvoiceNo(1);
  }
  
  @Test
  public void testGetInvoiceList() throws BaseClassException {
    ResponseEntity<ResponseGateway> marketInformation =  invoiceController.getInvoiceList(1, "rk@gmail.com","1","1", null, 0, 0, 0, 0, 0,"");
    assertTrue(marketInformation.getStatusCode() == HttpStatus.valueOf(200));
    
    invoiceController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
    gateway=  invoiceController.getInvoiceList(1, "rk@gmail.com","1","1", null, 0, 0, 0, 0, 0,"");
      assertTrue(gateway.getStatusCode() == HttpStatus.valueOf(200));
      
  }

  @Test
  public void testInsertInvoice() throws BaseClassException{
    ResponseEntity<ResponseGateway> insertstaus = invoiceController.insertInvoice(invoice,"VNGOSC", "rk@gmail.com");
    assertTrue(insertstaus.getStatusCode() == HttpStatus.valueOf(200));
    
    
    invoiceController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
    gateway=  invoiceController.insertInvoice(invoice,"VNGOSC", "rk@gmail.com");
      assertTrue(gateway.getStatusCode() == HttpStatus.valueOf(200));
  }

  @Test
  public void testUpdateInvoice() throws BaseClassException{
    ResponseEntity<ResponseGateway> insertstaus = invoiceController.updateInvoice(invoice,"VNGOSC","rk@gmail.com");
    assertTrue(insertstaus.getStatusCode() == HttpStatus.valueOf(200));
    
    invoiceController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
    gateway=  invoiceController.updateInvoice(invoice,"VNGOSC","rk@gmail.com");
      assertTrue(gateway.getStatusCode() == HttpStatus.valueOf(200));
      
  }

}
