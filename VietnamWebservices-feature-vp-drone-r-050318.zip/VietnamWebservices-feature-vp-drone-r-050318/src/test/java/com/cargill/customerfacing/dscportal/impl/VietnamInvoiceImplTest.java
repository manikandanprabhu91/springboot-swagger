package com.cargill.customerfacing.dscportal.impl;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cargill.customerfacing.dscportal.domain.Invoice;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.repository.InvoiceRepository;
import com.cargill.customerfacing.dscportal.service.IInvoice;

@RunWith(SpringJUnit4ClassRunner.class)
public class VietnamInvoiceImplTest {
  
  InvoiceRepository invoiceRepository;
  
  VietnamInvoiceImpl vietnamInvoiceImpl;
  
  @Mock
  IInvoice iInvoice;
  
  Invoice invoice;
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      vietnamInvoiceImpl = new VietnamInvoiceImpl();
      invoiceRepository = Mockito.mock(InvoiceRepository.class);
      vietnamInvoiceImpl.invoiceRepository = invoiceRepository;
      invoice = new Invoice();
      invoice.setCommodityName("cargoName");
      invoice.setCommodityQty(25);
      invoice.setContractId(1);
      invoice.setFileName("");
      invoice.setInvoiceAmount(2011);
      invoice.setInvoiceDate("2017-12-23");
      invoice.setInvoiceNo(1);
  }

  @Test
  public void testGetInvoiceList() throws BaseClassException {
    List<Invoice> invoices = vietnamInvoiceImpl.getInvoiceList(1, "rk@gmail.com","1","1", 0, 0, 0, 0, 0,"");
    assertTrue(invoices.size()==0);
  }

  @Test
  public void testInsertInvoice() throws BaseClassException{
    Invoice insertinv = vietnamInvoiceImpl.insertInvoice(invoice, "rk@gmail.com");
    assertTrue(insertinv ==null);
  }

  @Test
  public void testUpdateInvoice() throws BaseClassException{
    int updateInv = vietnamInvoiceImpl.updateInvoice(invoice, "rk@gmail.com");
    assertTrue(updateInv ==0);
  }

}
