package com.cargill.customerfacing.dscportal.webservices;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cargill.customerfacing.dscportal.domain.Contract;
import com.cargill.customerfacing.dscportal.domain.ResponseGateway;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.region.factory.RegionFactoryService;
import com.cargill.customerfacing.dscportal.service.IContractService;

@RunWith(SpringJUnit4ClassRunner.class)
public class ContractControllerTest {

  RegionFactoryService regionFactoryService;
  
  ContractController contractController;
  
  @Mock
  IContractService iContractService;
  
  Contract contract;
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      contractController = new ContractController();
      regionFactoryService = Mockito.mock(RegionFactoryService.class);
      regionFactoryService = new RegionFactoryService();
      regionFactoryService.setVietnamContractService(iContractService);
      contractController.regionFactoryService = regionFactoryService;
      contract = new Contract();
      contract.setBalanceStock(100);
      contract.setBasis("basis");
      contract.setCakDate("10/11/2017");
      contract.setCakNo("15");
      contract.setCargoOrigin("cargoOrigin");
      contract.setCommodity("SBM");
      contract.setContractCategory("VNGOSC");
      contract.setContractId(1);
      contract.setContractPrice(100);
      contract.setContractStatus("Unsigned");
      contract.setContractType("Service");
      contract.setContractTypeId(1);
      contract.setErpContractStatus(1);
      contract.setCurrency("doller");
      contract.setCustomerId("123");
      contract.setDestination("Desc");
      contract.setFinalWeightAt("wet");
      contract.setPackageType("Type");
      contract.setPaymentTerms("Terms");
      contract.setQuantity(123);
      contract.setReceived(10);
      contract.setShipPeriod("12/12/2017");
      contract.setStatusId("1");
      contract.setStorageTerms("ST");
      contract.setTendered(10);
      contract.setTolarance(1);
      contract.setUnitPrice(10);
  }
  
  @Test
  public void testGetContractList() throws BaseClassException {
    ResponseEntity<ResponseGateway>  contractL =  contractController.getContractList("Service", "Unsigned", "VNGOSC", "rk@crgl.com","S",1,10);
    assertTrue(contractL.getStatusCode() == HttpStatus.valueOf(200));
    
    contractController.regionFactoryService = null;
    ResponseEntity<ResponseGateway>  gateway = null;
    gateway=  contractController.getContractList("Service", "Unsigned", "VNGOSC", "rk@crgl.com","S",1,10);
      assertTrue(gateway.getStatusCode() == HttpStatus.valueOf(200));
  }

  @Test
  public void testContractById() throws BaseClassException{
    ResponseEntity<ResponseGateway> contract =  contractController.contractById(1, "VNGOSC", "rk@crgl.com");
    assertTrue(contract.getStatusCode() == HttpStatus.valueOf(200));
    
    contractController.regionFactoryService = null;
    ResponseEntity<ResponseGateway>  response= contractController.contractById(1, "VNGOSC", "rk@crgl.com");
      assertTrue(response.getStatusCode() == HttpStatus.valueOf(200));
  }

  @Test
  public void testInsertContract() throws BaseClassException{
    ResponseEntity<ResponseGateway> insertstaus = contractController.insertContract(contract,  "VNGOSC", "rk@crgl.com");
    assertTrue(insertstaus.getStatusCode() == HttpStatus.valueOf(200));
    
    contractController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
    gateway=  contractController.insertContract(contract,  "VNGOSC", "rk@crgl.com");
    assertTrue(gateway.getStatusCode() == HttpStatus.valueOf(200));
  }

  @Test
  public void testUpdateContract() throws BaseClassException{
    ResponseEntity<ResponseGateway> upctstaus = contractController.updateContract(1, contract,  "VNGOSC", "rk@crgl.com");
    assertTrue(upctstaus.getStatusCode() == HttpStatus.valueOf(200));
    
    contractController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
    gateway=  contractController.updateContract(1, contract,  "VNGOSC", "rk@crgl.com");
      assertTrue(gateway.getStatusCode() == HttpStatus.valueOf(200));
  }

  @Test
  public void testDeleteContract() throws BaseClassException{
    ResponseEntity<ResponseGateway> delc = contractController.deleteContract(1,  "VNGOSC", "rk@crgl.com");
    assertTrue(delc.getStatusCode() == HttpStatus.valueOf(200));
    
    contractController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
    gateway=  contractController.deleteContract(1,  "VNGOSC", "rk@crgl.com");
    assertTrue(gateway.getStatusCode() == HttpStatus.valueOf(200));
  }

  @Test
  public void testGetStatusList() throws BaseClassException{
   ResponseEntity<ResponseGateway> status =  contractController.getStatusList("payment","VNGOSC");
    assertTrue(status.getStatusCode() == HttpStatus.valueOf(200));
    
    contractController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
    gateway=  contractController.getStatusList("payment","VNGOSC");
    assertTrue(gateway.getStatusCode() == HttpStatus.valueOf(200));
  }

  @Test
  public void testGetCustomerList() throws BaseClassException{
//    ResponseEntity<ResponseGateway> custo =  contractController.getCustomerList("VNGOSC");
//    assertTrue(custo.getStatusCode() == HttpStatus.valueOf(200));
//    
//    contractController.regionFactoryService = null;
//    ResponseEntity<ResponseGateway> gateway = null;
//    gateway=  contractController.getCustomerList("VNGOSC");
//      assertTrue(gateway.getStatusCode() == HttpStatus.valueOf(200));
  }

}
