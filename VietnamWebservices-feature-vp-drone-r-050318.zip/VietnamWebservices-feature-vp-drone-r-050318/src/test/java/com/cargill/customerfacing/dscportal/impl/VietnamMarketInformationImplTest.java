package com.cargill.customerfacing.dscportal.impl;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import com.cargill.customerfacing.dscportal.domain.MarketInformation;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.repository.MarketInformationRepository;
import com.cargill.customerfacing.dscportal.service.IMarketInformation;

@RunWith(SpringJUnit4ClassRunner.class)
public class VietnamMarketInformationImplTest{
  
  @Mock
  IMarketInformation iMarketInformation;
  
  VietnamMarketInformationImpl vietnamMarketInformationImpl;
  
  MarketInformationRepository marketInformationRepository;
  
  MarketInformation information;
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      vietnamMarketInformationImpl = new VietnamMarketInformationImpl();
      marketInformationRepository = Mockito.mock(MarketInformationRepository.class);
      vietnamMarketInformationImpl.marketInformationRepository = marketInformationRepository;
      information = new MarketInformation();
      information.setContractCategory("VNGOSC");;
      information.setDetails("Welcome Cargill");
      information.setHeading("Test");
      information.setMarketId(1);
      information.setStatus("Status");
  }

  @Test
  public void testGetMarketInfoList() throws BaseClassException {
    List<MarketInformation> informations = vietnamMarketInformationImpl.getMarketInfoList("VNGOSC");
    assertTrue(informations.size()==0);
//    assertEquals("VNGOSC", marketinfolist.get(0).getContractCategory());
  }

  @Test
  public void testInsertMarketInformation() throws BaseClassException {
    MarketInformation insert = vietnamMarketInformationImpl.insertMarketInformation(information, "","VNGOSC");
    assertEquals("VNGOSC", information.getContractCategory());
    assertTrue(insert ==null);
  }
  
  
  @Test
  public void testUpdateMarketInformation() throws BaseClassException {
    int update = vietnamMarketInformationImpl.updateMarketInformation(information, "","VNGOSC");
    assertEquals("VNGOSC", information.getContractCategory());
    assertTrue(update ==0);
  }
  
  @Test
  public void testDeleteMarketInformation() throws BaseClassException {
    int delete = vietnamMarketInformationImpl.deleteMarketInformation(1,"");
    assertTrue(delete ==0);
  }
}
