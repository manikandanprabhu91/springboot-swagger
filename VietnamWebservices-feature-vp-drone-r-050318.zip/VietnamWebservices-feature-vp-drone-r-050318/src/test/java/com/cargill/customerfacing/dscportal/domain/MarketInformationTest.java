package com.cargill.customerfacing.dscportal.domain;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
public class MarketInformationTest {
  
  MarketInformation marketInformation;
  
  @Before
  public void setupMock() {
    MockitoAnnotations.initMocks(this);
    marketInformation = new MarketInformation();
  }

  @Test
  public void testGetHeading() {
    marketInformation.getHeading();
  }

  @Test
  public void testSetHeading() {
    marketInformation.setHeading("Test");
  }

  @Test
  public void testGetStatus() {
    marketInformation.getStatus();
  }

  @Test
  public void testSetStatus() {
    marketInformation.setStatus("Status");
  }

  @Test
  public void testGetDetails() {
    marketInformation.getDetails();
  }

  @Test
  public void testSetDetails() {
    marketInformation.setDetails("Welcome Cargill");
  }

  @Test
  public void testGetMarketId() {
    marketInformation.getMarketId();
  }

  @Test
  public void testSetMarketId() {
    marketInformation.setMarketId(1);
  }

  @Test
  public void testGetContractCategory() {
    marketInformation.getContractCategory();
  }

  @Test
  public void testSetContractCategory() {
    marketInformation.setContractCategory("VNGOSC");;
  }

}
