package com.cargill.customerfacing.dscportal.impl;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cargill.customerfacing.dscportal.domain.UserConfig;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.repository.UserProfileRepository;
import com.cargill.customerfacing.dscportal.service.IUserProfile;

@RunWith(SpringJUnit4ClassRunner.class)
public class VietnamUserProfileImplTest {
  
  @Mock
  IUserProfile iUserProfile;
  
  VietnamUserProfileImpl vietnamUserProfileImpl;
  
  UserProfileRepository userProfileRepository;
  
  UserConfig config;
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      vietnamUserProfileImpl = new VietnamUserProfileImpl();
      userProfileRepository = Mockito.mock(UserProfileRepository.class);
      vietnamUserProfileImpl.profileRepository = userProfileRepository;
  }

  @Test
  public void testGetUserConfig() throws BaseClassException {
    List<UserConfig> configs = vietnamUserProfileImpl.getUserConfig("VNGOSC","rk@gmail.com");
    assertTrue(configs.size()==0);
  }

  @Test
  public void testUpdateUserConfig() throws BaseClassException {
    config = new UserConfig();
    config.setAttributeId(1);
    config.setAttributeValue("sec");
    config.setScreenId(1);
    config.setSectionId(1);
    config.setUserConfigCol("h");
    config.setUserId("rk@gmail.com");
    int update = vietnamUserProfileImpl.updateUserConfig(config, "VNGOSC","rk@gmail.com");
    assertTrue(update ==0);
  }

}
