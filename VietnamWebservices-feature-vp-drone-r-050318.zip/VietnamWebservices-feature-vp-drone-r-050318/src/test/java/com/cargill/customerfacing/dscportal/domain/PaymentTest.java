package com.cargill.customerfacing.dscportal.domain;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
public class PaymentTest {
  
  Payment payment;
  
  @Before
  public void setupMock() {
    MockitoAnnotations.initMocks(this);
    payment = new Payment();
  }

  @Test
  public void testGetPaymentDate() {
    payment.getPaymentDate();
  }

  @Test
  public void testSetPaymentDate() {
    payment.setPaymentDate("2017-12-26");
  }

  @Test
  public void testGetPaymentAmount() {
    payment.getPaymentAmount();
  }

  @Test
  public void testSetPaymentAmount() {
    payment.setPaymentAmount(10000);
  }

  @Test
  public void testGetContractId() {
    payment.getContractId();
  }

  @Test
  public void testSetContractId() {
    payment.setContractId(1);
  }

  @Test
  public void testGetFile() {
    payment.getFile();
  }

  @Test
  public void testSetFile() {
    payment.setFile("filename");
  }

  @Test
  public void testGetStatusDescription() {
    payment.getStatusDescription();
  }

  @Test
  public void testSetStatusDescription() {
    payment.setStatusDescription("");
  }

  @Test
  public void testGetStatusCode() {
    payment.getStatusCode();
  }

  @Test
  public void testSetStatusCode() {
    payment.setStatusCode("NPD");
  }

  @Test
  public void testGetStatusDesc() {
    payment.getStatusDesc();
  }

  @Test
  public void testSetStatusDesc() {
    payment.setStatusDesc("");
  }

  @Test
  public void testGetPaymentId() {
    payment.getPaymentId();
  }

  @Test
  public void testSetPaymentId() {
    payment.setPaymentId(1);
  }

}
