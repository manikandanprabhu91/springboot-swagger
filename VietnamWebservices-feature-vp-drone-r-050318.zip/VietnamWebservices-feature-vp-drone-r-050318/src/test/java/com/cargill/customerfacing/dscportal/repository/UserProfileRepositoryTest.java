package com.cargill.customerfacing.dscportal.repository;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cargill.customerfacing.dscportal.domain.UserConfig;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;

@RunWith(SpringJUnit4ClassRunner.class)
public class UserProfileRepositoryTest{

  UserProfileRepository userProfileRepository;
  
  JdbcTemplate dynamicNamedParameterJdbcTemplate;
  
  UserConfig config;
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      userProfileRepository = new UserProfileRepository();
      dynamicNamedParameterJdbcTemplate = Mockito.mock(JdbcTemplate.class);
      userProfileRepository.jdbcTemplate = dynamicNamedParameterJdbcTemplate;
      config = new UserConfig();
      config.setAttributeId(1);
      config.setAttributeValue("sec");
      config.setScreenId(1);
      config.setSectionId(1);
      config.setUserConfigCol("h");
      config.setUserId("rk@gmail.com");
  }
  
  @Test
  public void testGetUserConfig() throws BaseClassException {
    List<UserConfig> configs = userProfileRepository.getUserConfig("VNGOSC","rk@gmail.com");
    assertTrue(configs.isEmpty());
    
   
    userProfileRepository.jdbcTemplate = null;
   // Mockito.when(userProfileRepository.getUserConfig("VNGOSC","rk@gmail.com")).thenThrow(EmptyResultDataAccessException.class);
    boolean thrown = false;
    try {
      userProfileRepository.getUserConfig("VNGOSC","rk@gmail.com");
    } catch (Exception e) {
      thrown = true;
    }
    assertTrue(thrown);
    
    
  }

  @Test
  public void testUpdateUserConfig() throws BaseClassException {
    int alert = userProfileRepository.updateUserConfig(config, "VNGOSC","rk@gmail.com");
    assertTrue(alert==0);
    
    userProfileRepository.jdbcTemplate = null;
    boolean thrown = false;
    try {
      userProfileRepository.getUserConfig("VNGOSC","rk@gmail.com");
    } catch (Exception e) {
      thrown = true;
    }
    assertTrue(thrown);
  }

}
