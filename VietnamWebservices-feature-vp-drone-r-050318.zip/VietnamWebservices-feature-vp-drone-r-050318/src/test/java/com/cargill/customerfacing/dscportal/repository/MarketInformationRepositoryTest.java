package com.cargill.customerfacing.dscportal.repository;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cargill.customerfacing.dscportal.domain.MarketInformation;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;


@RunWith(SpringJUnit4ClassRunner.class)
public class MarketInformationRepositoryTest{

  MarketInformationRepository  marketInformationRepository;
 
  JdbcTemplate dynamicNamedParameterJdbcTemplate; 
 
  MarketInformation information;
  
 @Before
 public void setupMock() {
   
     MockitoAnnotations.initMocks(this);
     marketInformationRepository = new MarketInformationRepository();
     dynamicNamedParameterJdbcTemplate = Mockito.mock(JdbcTemplate.class);
     marketInformationRepository.jdbcTemplate = dynamicNamedParameterJdbcTemplate;
     information = new MarketInformation();
     information.setContractCategory("VNGOSC");;
     information.setDetails("Welcome Cargill");
     information.setHeading("Test");
     information.setMarketId(1);
     information.setStatus("Status");
 }

  @Test
  public void testInsertMarketInformation() throws BaseClassException {
//    MarketInformation l = marketInformationRepository.insertMarketInformation(information, "","VNGOSC");
//    assertTrue(l==null);
//    
//    marketInformationRepository.jdbcTemplate = null;
//    boolean thrown = false;
//    try {
//     marketInformationRepository.insertMarketInformation(information, "","VNGOSC");
//    } catch (Exception e) {
//      thrown = true;
//    }
//    assertTrue(thrown);
  }

  @Test
  public void testUpdateMarketInformation() throws BaseClassException {
    int l = marketInformationRepository.updateMarketInformation(information, "","VNGOSC");
    assertTrue(l==0);
    
    marketInformationRepository.jdbcTemplate = null;
    boolean thrown = false;
    try {
     marketInformationRepository.updateMarketInformation(information, "","VNGOSC");
    } catch (Exception e) {
      thrown = true;
    }
    assertTrue(thrown);
  }

  @Test
  public void testDeleteMarketInformation() throws BaseClassException {
    int l = marketInformationRepository.deleteMarketInformation(1, "");
    assertTrue(l==0);
    
    marketInformationRepository.jdbcTemplate = null;
    boolean thrown = false;
    try {
     marketInformationRepository.deleteMarketInformation(1, "");
    } catch (Exception e) {
      thrown = true;
    }
    assertTrue(thrown);
  }

  @Test
  public void testGetMarketInfoList() throws Exception {
    boolean thrown = false;
    List<MarketInformation> informations = marketInformationRepository.getMarketInfoList("VNGOSC");
    assertTrue(informations.isEmpty());
    
    marketInformationRepository.jdbcTemplate = null;
    try {
     marketInformationRepository.getMarketInfoList("VNGOSC");
    } catch (Exception e) {
      thrown = true;
    }
    assertTrue(thrown);
  }
  
  
}
