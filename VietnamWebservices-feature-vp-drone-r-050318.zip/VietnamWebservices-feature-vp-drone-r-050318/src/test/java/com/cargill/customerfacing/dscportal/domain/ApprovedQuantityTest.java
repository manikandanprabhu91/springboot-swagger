package com.cargill.customerfacing.dscportal.domain;

import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;

public class ApprovedQuantityTest {
  
  ApprovedQuantity approvedQuantity;
  
  @Before
  public void setupMock() {
    MockitoAnnotations.initMocks(this);
    approvedQuantity = new ApprovedQuantity();
  }

  @Test
  public void testGetApprovedQuantityId() {
    approvedQuantity.getApprovedQuantityId();
  }

  @Test
  public void testSetApprovedQuantityId() {
    approvedQuantity.setApprovedQuantityId(1);
  }

  @Test
  public void testGetApprovedQty() {
    approvedQuantity.getApprovedQty();
  }

  @Test
  public void testSetApprovedQty() {
    approvedQuantity.setApprovedQty(10);
  }

  @Test
  public void testGetContractId() {
    approvedQuantity.getContractId();
  }

  @Test
  public void testSetContractId() {
    approvedQuantity.setContractId(10);
  }

}
