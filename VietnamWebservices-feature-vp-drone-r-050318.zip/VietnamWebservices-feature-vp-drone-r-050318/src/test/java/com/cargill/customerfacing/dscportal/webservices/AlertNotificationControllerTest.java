package com.cargill.customerfacing.dscportal.webservices;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cargill.customerfacing.dscportal.domain.DSCConstants;
import com.cargill.customerfacing.dscportal.domain.ResponseGateway;
import com.cargill.customerfacing.dscportal.domain.UserAlertMapping;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.region.factory.RegionFactoryService;
import com.cargill.customerfacing.dscportal.service.IAlertNotification;

@RunWith(SpringJUnit4ClassRunner.class)
public class AlertNotificationControllerTest {
  
  RegionFactoryService regionFactoryService;
  
  AlertNotificationController alertNotificationController;
  
  @Mock
  IAlertNotification iAlertNotification;
  
  UserAlertMapping alertMapping;
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      alertNotificationController = new AlertNotificationController();
      regionFactoryService = Mockito.mock(RegionFactoryService.class);
      regionFactoryService = new RegionFactoryService();
      regionFactoryService.setVietnamAlertNotificationService(iAlertNotification);
      alertNotificationController.regionFactoryService = regionFactoryService;
      alertMapping = new UserAlertMapping();
      alertMapping.setAlertId(1);
      alertMapping.setEmail("rk@gmail.com");
      alertMapping.setMessage("message");
      alertMapping.setSms("N");
      alertMapping.setUserId("rk@gmail.com");
      alertMapping.setWeb("Y");
  }

  @Test
  public void testInsertAlerts() throws BaseClassException {
//    ResponseEntity<ResponseGateway> insertstaus = alertNotificationController.insertAlerts("rk@gmail.com",100, "VNGOSC", 123,1,0,0);
//    assertTrue(insertstaus.getStatusCode() == HttpStatus.valueOf(200));
//    
//    alertNotificationController.regionFactoryService = null;
//    ResponseEntity<ResponseGateway> gateway = null;
//    gateway =   alertNotificationController.insertAlerts("rk@gmail.com",100, "VNGOSC", 123,1,0,0);
//      assertTrue(gateway.getStatusCode() == HttpStatus.valueOf(500));
  }

  @Test
  public void testGetAlertList() throws BaseClassException {
    ResponseEntity<ResponseGateway> strings =  alertNotificationController.getAlertList("VNGOSC", "rk@gmail.com", null, null);
    assertTrue(strings.getStatusCode() == HttpStatus.valueOf(200));
    
    alertNotificationController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
    gateway =  alertNotificationController.getAlertList("VNGOSC", "rk@gmail.com", null, null);
      assertTrue(gateway.getStatusCode() ==  HttpStatus.valueOf(200));
  }

  @Test
  public void testUpdateAlert() throws BaseClassException {
//    ResponseEntity<ResponseGateway> insertstaus = alertNotificationController.updateAlert(1,  "Read","VNGOSC", "rk@gmail.com");
//    assertTrue(insertstaus.getStatusCode() == HttpStatus.valueOf(200));
//    
//    alertNotificationController.regionFactoryService = null;
//    ResponseEntity<ResponseGateway> gateway = null;
//      gateway =   alertNotificationController.updateAlert(1,  "Read","VNGOSC", "rk@gmail.com");
//      assertTrue(gateway.getStatusCode() ==  HttpStatus.valueOf(500));
  }

  @Test
  public void testPaymentReminding() throws BaseClassException {
//    ResponseEntity<ResponseGateway> insertstaus = alertNotificationController.paymentReminding(1, "rk@gmail.com", "VNGOSC",1);
//    assertTrue(insertstaus.getStatusCode()==  HttpStatus.valueOf(200));
//    
//    alertNotificationController.regionFactoryService = null;
//    ResponseEntity<ResponseGateway> gateway = null;
//    gateway =  alertNotificationController.paymentReminding(1, "rk@gmail.com", "VNGOSC",1);
//      assertTrue(gateway.getStatusCode() ==  HttpStatus.valueOf(500));
  }

  @Test
  public void testGetAlertUserMappingList() throws BaseClassException {
//    ResponseEntity<ResponseGateway> alertUser =  alertNotificationController.getAlertUserMappingList("VNGOSC", "rk@gmail.com");
//    assertTrue(alertUser.getStatusCode() ==HttpStatus.valueOf(200));
//    
//    alertNotificationController.regionFactoryService = null;
//    ResponseEntity<ResponseGateway> gateway = null;
//    gateway =   alertNotificationController.getAlertUserMappingList("VNGOSC", "rk@gmail.com");
//      assertTrue(gateway.getStatusCode() ==  HttpStatus.valueOf(500));
  }

  @Test
  public void testUpdateAlertUserMapping() throws BaseClassException {
//    ResponseEntity<ResponseGateway> upstaus = alertNotificationController.updateAlertUserMapping(alertMapping, "VNGOSC","rk@gmail.com");
//    assertTrue(upstaus.getStatusCode() ==HttpStatus.valueOf(200));;
//    
//    alertNotificationController.regionFactoryService = null;
//    ResponseEntity<ResponseGateway> gateway = null;
//    gateway =   alertNotificationController.updateAlertUserMapping(alertMapping, "VNGOSC","rk@gmail.com");
//      assertTrue(gateway.getStatusCode() ==  HttpStatus.valueOf(500));
  }

}
