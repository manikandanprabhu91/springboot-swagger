package com.cargill.customerfacing.dscportal.impl;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cargill.customerfacing.dscportal.domain.PickUpSchedule;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.repository.PickUpScheduleRepository;
import com.cargill.customerfacing.dscportal.service.IPickUpSchedule;

@RunWith(SpringJUnit4ClassRunner.class)
public class VietnamPickUpScheduleImplTest {
  
  @Mock
  IPickUpSchedule iPickUpSchedule;
  
  VietnamPickUpScheduleImpl vietnamPickUpScheduleImpl;
  
  PickUpScheduleRepository pickUpScheduleRepository;
  
  PickUpSchedule pickUpSchedule;
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      vietnamPickUpScheduleImpl = new VietnamPickUpScheduleImpl();
      pickUpScheduleRepository = Mockito.mock(PickUpScheduleRepository.class);
      vietnamPickUpScheduleImpl.pickUpScheduleRepository = pickUpScheduleRepository;
      pickUpSchedule = new PickUpSchedule();
      pickUpSchedule.setApprovedPickUpDate("2012-04-04 04:03:35");
      pickUpSchedule.setArrivalScheduleId(1);
      pickUpSchedule.setContractId(1);
      pickUpSchedule.setPickUpDate("2012-04-04 04:03:35");
      pickUpSchedule.setFileName("vietnam");
      pickUpSchedule.setPickUpId(1);
      pickUpSchedule.setPickUpQty(156);
      pickUpSchedule.setStatus("Agree");
  }

  @Test
  public void testInsertPickUpSchedule() throws BaseClassException{
    PickUpSchedule savePickup =  vietnamPickUpScheduleImpl.insertPickUpSchedule(pickUpSchedule,"rk@gmail.com", null);
    assertTrue(savePickup ==null);
  }
  
  @Test
  public void testGetPickUpScheduleList() throws BaseClassException{
    List<PickUpSchedule> pickUpSchedules= vietnamPickUpScheduleImpl.getPickUpScheduleList(1,"rk@gmail.com");
    assertTrue(pickUpSchedules.size()==0);
  }
  
  @Test
  public void testGetPickUpScheduleBYID() throws BaseClassException {
    List<PickUpSchedule> pickUpSchedule = vietnamPickUpScheduleImpl.getPickUpScheduleBYID(1, 1);
    assertTrue(pickUpSchedule.size()==0);
  }

  @Test
  public void testUpdatePickUpSchedule() throws BaseClassException {
    int updatePickup =  vietnamPickUpScheduleImpl.updatePickUpSchedule(pickUpSchedule,1,"rk@gmail.com", null);
    assertTrue(updatePickup ==0);
  }

  @Test
  public void testDeletePickUpSchedule() throws BaseClassException{
    int del =   vietnamPickUpScheduleImpl.deletePickUpSchedule(1,"rk@gmail.com",1);
    assertTrue(del ==0);
  }

}
