package com.cargill.customerfacing.dscportal.impl;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cargill.customerfacing.dscportal.domain.SetUpAlert;
import com.cargill.customerfacing.dscportal.domain.UserAlertMapping;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.repository.AlertNotificationRepository;
import com.cargill.customerfacing.dscportal.service.IAlertNotification;

@RunWith(SpringJUnit4ClassRunner.class)
public class VietnamAlertNotificationImplTest {
  
  AlertNotificationRepository alertNotificationRepository;
  
  @Mock
  IAlertNotification iAlertNotification;
  
  VietnamAlertNotificationImpl vietnamAlertNotificationImpl;
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      vietnamAlertNotificationImpl = new VietnamAlertNotificationImpl();
      alertNotificationRepository = Mockito.mock(AlertNotificationRepository.class);
      vietnamAlertNotificationImpl.alertNotificationRepository = alertNotificationRepository;
  }

  @Test
  public void testSetupAlert() throws BaseClassException {
    SetUpAlert alert = vietnamAlertNotificationImpl.setupAlert(100, "VNGOSC", "123","rk@gmail.com",1,0,0,0);
    assertTrue(alert==null);
  }

  @Test
  public void testGetAlertList() throws BaseClassException {
    List<SetUpAlert> getalert = vietnamAlertNotificationImpl.getAlertList("VNGOSC", "rk@gmail.com", 0, 0);
    assertTrue(getalert.size()==0);
  }

  @Test
  public void testUpdateAlert() throws BaseClassException {
    int updatealert = vietnamAlertNotificationImpl.updateAlert(1,  "Read", "rk@gmail.com");
    assertTrue(updatealert ==0);
  }

  @Test
  public void testPaymentReminding() throws BaseClassException {
    SetUpAlert payrem = vietnamAlertNotificationImpl.setupAlert(100, "VNGOSC", "123","rk@gmail.com",1,0,0,0);
    assertTrue(payrem ==null);
  }

  @Test
  public void testGetAlertUserMappingList() throws BaseClassException {
    List<UserAlertMapping> alert = vietnamAlertNotificationImpl.getAlertUserMappingList("VNGOSC", "rk@gmail.com");
    assertTrue(alert.size()==0);
  }

  @Test
  public void testUpdateAlertUserMapping() throws BaseClassException {
    UserAlertMapping alertMapping = new UserAlertMapping();
    alertMapping.setAlertId(1);
    alertMapping.setEmail("rk@gmail.com");
    alertMapping.setMessage("message");
    alertMapping.setSms("N");
    alertMapping.setUserId("rk@gmail.com");
    alertMapping.setWeb("Y");
    int alert = vietnamAlertNotificationImpl.updateAlertUserMapping(alertMapping, "VNGOSC","rk@gmail.com");
    assertTrue(alert==0);
  }

}
