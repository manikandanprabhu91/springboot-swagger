package com.cargill.customerfacing.dscportal.domain;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
public class UserProfileTest {

  UserProfile userProfile;
  
  @Before
  public void setupMock() {
    MockitoAnnotations.initMocks(this);
    userProfile = new UserProfile();
  }
  
  @Test
  public void testGetUserId() {
    userProfile.getUserId();
  }

  @Test
  public void testSetUserId() {
    userProfile.setUserId("");
  }

  @Test
  public void testGetEmail() {
    userProfile.getEmail();
  }

  @Test
  public void testSetEmail() {
    userProfile.setEmail("Y");
  }

  @Test
  public void testGetCustomerId() {
    userProfile.getCustomerId();
  }

  @Test
  public void testSetCustomerId() {
    userProfile.setCustomerId("123");
  }

  @Test
  public void testGetCargillUser() {
    userProfile.getCargillUser();
  }

  @Test
  public void testSetCargillUser() {
    userProfile.setCargillUser("Y");
  }

}
