package com.cargill.customerfacing.dscportal.webservices;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cargill.customerfacing.dscportal.domain.ApprovedQuantity;
import com.cargill.customerfacing.dscportal.domain.Payment;
import com.cargill.customerfacing.dscportal.domain.ResponseGateway;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.region.factory.RegionFactoryService;
import com.cargill.customerfacing.dscportal.service.IPaymentService;

@RunWith(SpringJUnit4ClassRunner.class)
public class PaymentControllerTest {

  RegionFactoryService regionFactoryService;
  
  PaymentController paymentController;
  
  @Mock
  IPaymentService iPaymentService;
  
  Payment payment;
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      paymentController = new PaymentController();
      regionFactoryService = Mockito.mock(RegionFactoryService.class);
      regionFactoryService = new RegionFactoryService();
      regionFactoryService.setVietnamPaymentService(iPaymentService);
      paymentController.regionFactoryService = regionFactoryService;
      payment = new Payment();
      payment.setPaymentAmount(10000);
      payment.setContractId(1);
      payment.setPaymentDate("2017-12-26");
      payment.setFile("filename");
      payment.setPaymentId(1);
      payment.setStatusCode("NPD");
      payment.setStatusDesc("");
      payment.setStatusDescription("");
  }
  
  @Test
  public void testGetPaymentList() throws BaseClassException {
    ResponseEntity<ResponseGateway> inventoryl =  paymentController.getPaymentList(1, "VNGOSC", "rk@gmail.com");
    assertTrue(inventoryl.getStatusCode() == HttpStatus.valueOf(200));
    
    paymentController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
    gateway =  paymentController.getPaymentList(1, "VNGOSC", "rk@gmail.com");
      assertTrue(gateway.getStatusCode()  == HttpStatus.valueOf(200));
  }

  @Test
  public void testInsertPayment() throws BaseClassException{
    ResponseEntity<ResponseGateway> insertstaus = paymentController.insertPayment(payment, "VNGOSC","rk@gmail.com");
    assertTrue(insertstaus.getStatusCode()  == HttpStatus.valueOf(200));
    
    paymentController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
    gateway = paymentController.insertPayment(payment, "VNGOSC","rk@gmail.com");
      assertTrue(gateway.getStatusCode()  == HttpStatus.valueOf(200));
  }

  @Test
  public void testUpdatePayment() throws BaseClassException{
    ResponseEntity<ResponseGateway>  uppay = paymentController.updatePayment(payment, "VNGOSC","rk@gmail.com");
    assertTrue(uppay.getStatusCode()  == HttpStatus.valueOf(200));
    
    paymentController.regionFactoryService = null;
    ResponseEntity<ResponseGateway>  gateway = null;
    gateway = paymentController.updatePayment(payment,"VNGOSC", "rk@gmail.com");
      assertTrue(gateway.getStatusCode()  == HttpStatus.valueOf(200));
  }

  @Test
  public void testDeletePayment() throws BaseClassException{
    ResponseEntity<ResponseGateway>  delpay = paymentController.deletePayment(1, "VNGOSC", 1, "rk@gmail.com");
    assertTrue(delpay.getStatusCode() == HttpStatus.valueOf(200));
    
    paymentController.regionFactoryService = null;
    ResponseEntity<ResponseGateway>  gateway = null;
    gateway =  paymentController.deletePayment(1, "VNGOSC", 1, "rk@gmail.com");
      assertTrue(gateway.getStatusCode()  == HttpStatus.valueOf(200));
  }

  @Test
  public void testUpdateApprovedQuantity() throws BaseClassException{
    ApprovedQuantity approvedQuantity = new ApprovedQuantity();
    approvedQuantity.setApprovedQty(100);
    approvedQuantity.setApprovedQuantityId(1);
    approvedQuantity.setContractId(1);
    ResponseEntity<ResponseGateway>  qty =  paymentController.updateApprovedQuantity(approvedQuantity,"VNGOSC", "rk@gmail.com");
    assertTrue(qty.getStatusCode() == HttpStatus.valueOf(200));
    
    paymentController.regionFactoryService = null;
    ResponseEntity<ResponseGateway>  gateway = null;
    gateway =  paymentController.updateApprovedQuantity(approvedQuantity,"VNGOSC", "rk@gmail.com");
      assertTrue(gateway.getStatusCode()  == HttpStatus.valueOf(200));
  }

//  @Test
//  public void testApprovedQuantityList() throws BaseClassException {
//    ResponseEntity<ResponseGateway>  qty1 =  paymentController.approvedQuantityList(1,"VNGOSC");
//    assertTrue(qty1.getStatusCode()  == HttpStatus.valueOf(200));
//    
//    paymentController.regionFactoryService = null;
//    ResponseEntity<ResponseGateway>  gateway = null;
//    gateway = paymentController.approvedQuantityList(1,"VNGOSC");
//      assertTrue(gateway.getStatusCode()  == HttpStatus.valueOf(500));
//  }

}
