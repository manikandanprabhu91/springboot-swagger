package com.cargill.customerfacing.dscportal.domain;

import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;

public class SetUpAlertTest {
  
  SetUpAlert setUpAlert;
  
  @Before
  public void setupMock() {
    MockitoAnnotations.initMocks(this);
    setUpAlert = new SetUpAlert();
  }
  
  @Test
  public void testGetAlertCode() {
    setUpAlert.getAlertCode();
  }

  @Test
  public void testSetAlertCode() {
    setUpAlert.setAlertCode(100);
  }

  @Test
  public void testGetDescription() {
    setUpAlert.getDescription();
  }

  @Test
  public void testSetDescription() {
    setUpAlert.setDescription("");
  }

  @Test
  public void testGetWeb() {
    setUpAlert.getWeb();
  }

  @Test
  public void testSetWeb() {
    setUpAlert.setWeb("Y");
  }

  @Test
  public void testGetMessage() {
    setUpAlert.getMessage();
  }

  @Test
  public void testSetMessage() {
    setUpAlert.setMessage("");
  }

  @Test
  public void testGetAlertId() {
    setUpAlert.getAlertId();
  }

  @Test
  public void testSetAlertId() {
    setUpAlert.setAlertId(1);
  }

}
