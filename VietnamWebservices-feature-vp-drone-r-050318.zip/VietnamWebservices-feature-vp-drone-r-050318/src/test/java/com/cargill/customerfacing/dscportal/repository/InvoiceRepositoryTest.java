//package com.cargill.customerfacing.dscportal.repository;
//
//import static org.junit.Assert.assertTrue;
//
//
//import java.util.List;
//
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.Mockito;
//import org.mockito.MockitoAnnotations;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
//
//import com.cargill.customerfacing.dscportal.Application;
//import com.cargill.customerfacing.dscportal.domain.Invoice;
//import com.cargill.customerfacing.dscportal.exception.BaseClassException;
//
//@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes=Application.class)
//public class InvoiceRepositoryTest{
//
//  InvoiceRepository invoiceRepository;
//  
//  JdbcTemplate dynamicNamedParameterJdbcTemplate;
//  
//  Invoice invoice;
//  
//  @Before
//  public void setupMock() {
//      MockitoAnnotations.initMocks(this);
//      invoiceRepository = new InvoiceRepository();
//      dynamicNamedParameterJdbcTemplate = Mockito.mock(JdbcTemplate.class);
//      invoiceRepository.jdbcTemplate = dynamicNamedParameterJdbcTemplate;
//      invoice = new Invoice();
//      invoice.setCargoName("cargoName");
//      invoice.setCargoVolume("cargoVolume");
//      invoice.setContractId(1);
//      invoice.setDocument("bob");
//      invoice.setInvoiceAmount(2011);
//      invoice.setInvoiceDate("2017-12-23");
//      invoice.setInvoiceNo(1);
//  }
//  
//  @Test
//  public void testGetInvoiceList() throws BaseClassException {
//    List<Invoice> invoice = invoiceRepository.getInvoiceList(1, "rk@crgl.com");
//    assertTrue(invoice.isEmpty());
//    
//    invoiceRepository.jdbcTemplate = null;
//    boolean thrown = false;
//    try {
//      invoiceRepository.getInvoiceList(1, "rk@crgl.com");
//    } catch (Exception e) {
//      thrown = true;
//    }
//    assertTrue(thrown);
//  }
//
//  @Test
//  public void testInsertInvoice() throws BaseClassException {
//    int insert = invoiceRepository.insertInvoice(1, invoice, "");
//    assertTrue(insert==0);
//    
//    invoiceRepository.jdbcTemplate = null;
//    boolean thrown = false;
//    try {
//      invoiceRepository.getInvoiceList(1, "rk@crgl.com");
//    } catch (Exception e) {
//      thrown = true;
//    }
//    assertTrue(thrown);
//  }
//  
//  @Test
//  public void testUpdateInvoice() throws BaseClassException {
//    int update = invoiceRepository.updateInvoice(invoice,1, "");
//    assertTrue(update==0);
//    
//    invoiceRepository.jdbcTemplate = null;
//    boolean thrown = false;
//    try {
//      invoiceRepository.getInvoiceList(1, "rk@crgl.com");
//    } catch (Exception e) {
//      thrown = true;
//    }
//    assertTrue(thrown);
//  }
//
//}
