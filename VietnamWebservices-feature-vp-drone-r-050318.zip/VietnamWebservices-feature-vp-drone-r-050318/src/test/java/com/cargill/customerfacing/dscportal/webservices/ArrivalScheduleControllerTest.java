package com.cargill.customerfacing.dscportal.webservices;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cargill.customerfacing.dscportal.domain.ArrivalSchedule;
import com.cargill.customerfacing.dscportal.domain.ResponseGateway;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.region.factory.RegionFactoryService;
import com.cargill.customerfacing.dscportal.service.IArrivalSchedule;

@RunWith(SpringJUnit4ClassRunner.class)
public class ArrivalScheduleControllerTest {
  
  RegionFactoryService regionFactoryService;

  ArrivalScheduleController arrivalScheduleController;
  
  @Mock
  IArrivalSchedule iArrivalSchedule;
  
  ArrivalSchedule arrivalSchedule;
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      arrivalScheduleController = new ArrivalScheduleController();
      regionFactoryService = Mockito.mock(RegionFactoryService.class);
      regionFactoryService = new RegionFactoryService();
      regionFactoryService.setVietnamArrivalScheduleService(iArrivalSchedule);
      arrivalScheduleController.regionFactoryService = regionFactoryService;
      arrivalSchedule = new ArrivalSchedule();
      arrivalSchedule.setArrivalScheduleId(1);
      arrivalSchedule.setCommodity("commodity");
      arrivalSchedule.setContractId(1);
      arrivalSchedule.setEtaDate("2017-12-11");
      arrivalSchedule.setEtaTime("00:00");
      arrivalSchedule.setShipmentPeriod("period");
      arrivalSchedule.setTendered("ss");
      arrivalSchedule.setVesselName("SN");
      arrivalSchedule.setApprovedQuantity(10);
      arrivalSchedule.setWareHouse("soy");
      arrivalSchedule.setDeliveryBasis("basis");
  }

  @Test
  public void testGetArrivalScheduleList() throws BaseClassException {
    ResponseEntity<ResponseGateway> arrival =  arrivalScheduleController.getArrivalScheduleList(1,"VNGOSC", "rk@gmail.com","");
    assertTrue(arrival.getStatusCode() == HttpStatus.valueOf(200));
    
    arrivalScheduleController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
    gateway =   arrivalScheduleController.getArrivalScheduleList(1,"VNGOSC", "rk@gmail.com","");
      assertTrue(gateway.getStatusCode()  == HttpStatus.valueOf(200));
  }

  @Test
  public void testInsertArrivalSchedule() throws BaseClassException {
    ResponseEntity<ResponseGateway> insertstaus = arrivalScheduleController.insertArrivalSchedule(arrivalSchedule,"VNGOSC", "rk@gmail.com");
    assertTrue(insertstaus.getStatusCode()  == HttpStatus.valueOf(200));
    
    arrivalScheduleController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
    gateway =   arrivalScheduleController.insertArrivalSchedule(arrivalSchedule, "VNGOSC", "rk@gmail.com");
      assertTrue(gateway.getStatusCode()  == HttpStatus.valueOf(200));
  }

  @Test
  public void testUpdateArrivalSchedule() throws BaseClassException {
    ResponseEntity<ResponseGateway> updArr = arrivalScheduleController.updateArrivalSchedule( arrivalSchedule, "VNGOSC", "rk@gmail.com");
    assertTrue(updArr.getStatusCode()  == HttpStatus.valueOf(200));
    
    arrivalScheduleController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
    gateway =   arrivalScheduleController.updateArrivalSchedule(arrivalSchedule, "VNGOSC", "rk@gmail.com");
      assertTrue(gateway.getStatusCode()  == HttpStatus.valueOf(200));
  }

  @Test
  public void testDeleteArrivalSchedule() throws BaseClassException {
    ResponseEntity<ResponseGateway> delarrstaus = arrivalScheduleController.deleteArrivalSchedule(1, 1,  "VNGOSC");
    assertTrue(delarrstaus.getStatusCode()  == HttpStatus.valueOf(200));
    
    arrivalScheduleController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
    gateway =  arrivalScheduleController.deleteArrivalSchedule(1, 1,  "VNGOSC");
      assertTrue(gateway.getStatusCode() == HttpStatus.valueOf(200));
  }

}
