package com.cargill.customerfacing.dscportal.webservices;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cargill.customerfacing.dscportal.domain.ResponseGateway;
import com.cargill.customerfacing.dscportal.domain.UserConfig;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.region.factory.RegionFactoryService;
import com.cargill.customerfacing.dscportal.service.IUserProfile;

@RunWith(SpringJUnit4ClassRunner.class)
public class UserProfileControllerTest {
  
  RegionFactoryService regionFactoryService;
  
  UserProfileController userProfileController;
  
  @Mock
  IUserProfile iUserProfile;
  
  UserConfig config;
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      userProfileController = new UserProfileController();
      regionFactoryService = Mockito.mock(RegionFactoryService.class);
      regionFactoryService = new RegionFactoryService();
      regionFactoryService.setVietnamUserProfileService(iUserProfile);
      userProfileController.regionFactoryService = regionFactoryService;
  }

  @Test
  public void testGetUserConfig() throws BaseClassException {
    ResponseEntity<ResponseGateway> configs = userProfileController.getUserConfig("VNGOSC","rk@gmail.com");
    assertTrue(configs.getStatusCode() == HttpStatus.valueOf(200));
    
    userProfileController.regionFactoryService = null;
    ResponseEntity<ResponseGateway>  gateway = null;
      gateway = userProfileController.getUserConfig("VNGOSC","rk@gmail.com");
      assertTrue(gateway.getStatusCode() == HttpStatus.valueOf(200));
  }

  @Test
  public void testUpdateUserConfig() throws BaseClassException {
    config = new UserConfig();
    config.setAttributeId(1);
    config.setAttributeValue("sec");
    config.setScreenId(1);
    config.setSectionId(1);
    config.setUserConfigCol("h");
    config.setUserId("rk@gmail.com");
    ResponseEntity<ResponseGateway> update = userProfileController.updateUserConfig(config, "VNGOSC","rk@gmail.com");
    assertTrue(update.getStatusCode() == HttpStatus.valueOf(200));
    
    userProfileController.regionFactoryService = null;
    ResponseEntity<ResponseGateway>  gateway = null;
      gateway =  userProfileController.updateUserConfig(config, "VNGOSC","rk@gmail.com");
      assertTrue(gateway.getStatusCode()== HttpStatus.valueOf(200));
  }

}
