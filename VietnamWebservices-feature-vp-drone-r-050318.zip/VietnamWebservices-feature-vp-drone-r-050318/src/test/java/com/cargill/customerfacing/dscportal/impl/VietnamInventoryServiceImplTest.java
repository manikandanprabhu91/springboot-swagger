package com.cargill.customerfacing.dscportal.impl;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cargill.customerfacing.dscportal.domain.Inventory;
import com.cargill.customerfacing.dscportal.domain.User;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.repository.InventoryRepository;
import com.cargill.customerfacing.dscportal.service.IInventory;

@RunWith(SpringJUnit4ClassRunner.class)
public class VietnamInventoryServiceImplTest {
  
  InventoryRepository inventoryRepository;
  
  VietnamInventoryServiceImpl vietnamInventoryServiceImpl;
  
  @Mock
  IInventory iInventory;
  
  Inventory inventory;
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      vietnamInventoryServiceImpl = new VietnamInventoryServiceImpl();
      inventoryRepository = Mockito.mock(InventoryRepository.class);
      vietnamInventoryServiceImpl.inventoryRepository = inventoryRepository;
      inventory = new Inventory();
      inventory.setCakNo("1");
      inventory.setCargo("ss");
      inventory.setContractId(1);
      inventory.setContractType("Service");
      inventory.setEtaDate("2017-04-04");
      inventory.setInventoryId(1);
      inventory.setLocation("VTN");
      inventory.setMode("Vesseltrucks");
      inventory.setNetWeight(100);
      inventory.setPacking("packing");
      inventory.setPickUpId(1);
      inventory.setRemarks("remark");
      inventory.setTimeInDate("2017-04-04 04:03:35");
      inventory.setTimeOutDate("2017-04-04 04:03:35");
      inventory.setTotalWeight(26);
      inventory.setVehicleNo("TN456");
      inventory.setVehicleType("VN");
      inventory.setWeightIn(10);
      inventory.setWeightOut(11);
  }
  
  @Test
  public void testGetInventoryList() throws BaseClassException {
      User user = null;
    List<Inventory> inventories = vietnamInventoryServiceImpl.getInventoryList(1, "123", 1, "VNGOSC", user, 0, 0, null, null, null);
    assertTrue(inventories.size()==0);
  }

  @Test
  public void testInsertInventory() throws BaseClassException{
    Inventory insertinve = vietnamInventoryServiceImpl.insertInventory(1, inventory, "rk@gmail.com");
    assertTrue(insertinve ==null);
  }

  @Test
  public void testUpdateInventory() throws BaseClassException{
    int updinve = vietnamInventoryServiceImpl.updateInventory(inventory,  "rk@gmail.com");
    assertTrue(updinve ==0);
  }

}
