package com.cargill.customerfacing.dscportal.repository;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cargill.customerfacing.dscportal.domain.PickUpSchedule;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;

@RunWith(SpringJUnit4ClassRunner.class)
public class PickUpScheduleRepositoryTest{

  PickUpScheduleRepository pickUpScheduleRepository;
  
  JdbcTemplate dynamicNamedParameterJdbcTemplate;
  
  PickUpSchedule pickUpSchedule;
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      pickUpScheduleRepository = new PickUpScheduleRepository();
      dynamicNamedParameterJdbcTemplate = Mockito.mock(JdbcTemplate.class);
      pickUpScheduleRepository.jdbcTemplate = dynamicNamedParameterJdbcTemplate;
      pickUpSchedule = new PickUpSchedule();
      pickUpSchedule.setApprovedPickUpDate("2012-04-04 04:03:35");
      pickUpSchedule.setArrivalScheduleId(1);
      pickUpSchedule.setContractId(1);     
      pickUpSchedule.setPickUpDate("2012-04-04 04:03:35");
      pickUpSchedule.setFileName("vietnam");
      pickUpSchedule.setPickUpId(1);
      pickUpSchedule.setPickUpQty(156);
      pickUpSchedule.setStatus("Agree");
  }
  
  @Test
  public void testInsertPickUpSchedule() throws BaseClassException{
//    int l = pickUpScheduleRepository.insertPickUpSchedule(pickUpSchedule, "rk@gmail.com");
//    assertTrue(l==0);
//    
    pickUpScheduleRepository.jdbcTemplate = null;
    boolean thrown = false;
    try {
      pickUpScheduleRepository.insertPickUpSchedule(pickUpSchedule, "rk@gmail.com", null);
    } catch (Exception e) {
      thrown = true;
    }
    assertTrue(thrown);
  }

  @Test
  public void testGetPickUpScheduleList() throws BaseClassException{
    List<PickUpSchedule> pickUpScheduleRepositories = pickUpScheduleRepository.getPickUpScheduleList(1, "rk@gmail.com");
    assertTrue(pickUpScheduleRepositories.isEmpty());
    
    pickUpScheduleRepository.jdbcTemplate = null;
    boolean thrown = false;
    try {
      pickUpScheduleRepository.getPickUpScheduleList(1, "rk@gmail.com");
    } catch (Exception e) {
      thrown = true;
    }
    assertTrue(thrown);
  }

  @Test
  public void testGetPickUpScheduleBYID() throws BaseClassException{
    List<PickUpSchedule> pickUpSchedule = pickUpScheduleRepository.getPickUpScheduleBYID(1, 1);
    assertTrue(pickUpSchedule.size()==0);
    
    pickUpScheduleRepository.jdbcTemplate = null;
    boolean thrown = false;
    try {
      pickUpScheduleRepository.getPickUpScheduleBYID(1, 1);
    } catch (Exception e) {
      thrown = true;
    }
    assertTrue(thrown);
  }

  @Test
  public void testUpdatePickUpSchedule() throws BaseClassException{
//    int l = pickUpScheduleRepository.updatePickUpSchedule(pickUpSchedule, 1, "rk@gmail.com");
//    assertTrue(l==0);
//    
    pickUpScheduleRepository.jdbcTemplate = null;
    boolean thrown = false;
    try {
      pickUpScheduleRepository.updatePickUpSchedule(pickUpSchedule, 1, "rk@gmail.com", null);
    } catch (Exception e) {
      thrown = true;
    }
    assertTrue(thrown);
  }

  @Test
  public void testDeletePickUpSchedule() throws BaseClassException{
    int l = pickUpScheduleRepository.deletePickUpSchedule(1, "rk@gmail.com", 1);
    assertTrue(l==0);
    
    pickUpScheduleRepository.jdbcTemplate = null;
    boolean thrown = false;
    try {
      pickUpScheduleRepository.deletePickUpSchedule(1, "rk@gmail.com", 1);
    } catch (Exception e) {
      thrown = true;
    }
    assertTrue(thrown);
  }
}
