package com.cargill.customerfacing.dscportal.webservices;

import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cargill.customerfacing.dscportal.domain.Inventory;
import com.cargill.customerfacing.dscportal.domain.ResponseGateway;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.region.factory.RegionFactoryService;
import com.cargill.customerfacing.dscportal.service.IInventory;

@RunWith(SpringJUnit4ClassRunner.class)
public class InventoryControllerTest {

  RegionFactoryService regionFactoryService;
  
  InventoryController inventoryController;
  
  @Mock
  IInventory iInventory;
  
  Inventory inventory;
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      inventoryController = new InventoryController();
      regionFactoryService = Mockito.mock(RegionFactoryService.class);
      regionFactoryService = new RegionFactoryService();
      regionFactoryService.setVietnamInventoryService(iInventory);
      inventoryController.regionFactoryService = regionFactoryService;
      inventory = new Inventory();
      inventory.setCakNo("1");
      inventory.setCargo("ss");
      inventory.setContractId(1);
      inventory.setContractType("Service");
      inventory.setEtaDate("2017-04-04");
      inventory.setInventoryId(1);
      inventory.setLocation("VTN");
      inventory.setMode("Vesseltrucks");
      inventory.setNetWeight(100);
      inventory.setPacking("packing");
      inventory.setPickUpId(1);
      inventory.setRemarks("remark");
      inventory.setTimeInDate("2017-04-04");
      inventory.setTimeOutDate("2017-04-04");
      inventory.setTotalWeight(26);
      inventory.setVehicleNo("TN456");
      inventory.setVehicleType("VN");
      inventory.setWeightIn(10);
      inventory.setWeightOut(11);
  }
  
  @Test
  public void testGetInventoryList() throws BaseClassException {
    ResponseEntity<ResponseGateway> inventoryl =  inventoryController.getInventoryList(1, "123", 1, "VNGOSC", "rk@gmail.com", null, null, null, null, null);
    assertTrue(inventoryl.getStatusCode() == HttpStatus.valueOf(200));
    
    inventoryController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
    gateway=  inventoryController.getInventoryList(1, "123", 1, "VNGOSC", "rk@gmail.com", null, null, null, null, null);
    assertTrue(gateway.getStatusCode() == HttpStatus.valueOf(200));
  }

  @Test
  public void testInsertInventory() throws BaseClassException {
    ResponseEntity<ResponseGateway> insertstaus = inventoryController.insertInventory(1, inventory,"VNGOSC", "rk@gmail.com");
    assertTrue(insertstaus.getStatusCode() == HttpStatus.valueOf(200));
    
    inventoryController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
    gateway=  inventoryController.insertInventory(1, inventory,"VNGOSC", "rk@gmail.com");
    assertTrue(gateway.getStatusCode() == HttpStatus.valueOf(200));
  }

  @Test
  public void testUpdateInventory() throws BaseClassException {
    ResponseEntity<ResponseGateway> uptstaus = inventoryController.updateInventory(inventory, "VNGOSC", "rk@gmail.com");
    assertTrue(uptstaus.getStatusCode()  == HttpStatus.valueOf(200));
    
    inventoryController.regionFactoryService = null;
    ResponseEntity<ResponseGateway> gateway = null;
    gateway=  inventoryController.updateInventory(inventory, "VNGOSC", "rk@gmail.com");
    assertTrue(gateway.getStatusCode()  == HttpStatus.valueOf(200));
  }

}
