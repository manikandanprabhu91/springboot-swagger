package com.cargill.customerfacing.dscportal.domain;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.MockitoAnnotations;

public class StatusTest {
  
  Status status;
  
  @Before
  public void setupMock() {
    MockitoAnnotations.initMocks(this);
    status = new Status();
  }

  @Test
  public void testGetStatusId() {
    status.getStatusId();
  }

  @Test
  public void testSetStatusId() {
    status.setStatusId(1);
  }

  @Test
  public void testGetStatusType() {
    status.getStatusType();
  }

  @Test
  public void testSetStatusType() {
    status.setStatusType("");
  }

  @Test
  public void testGetDescription() {
    status.getDescription();
  }

  @Test
  public void testSetDescription() {
    status.setDescription("");
  }

  @Test
  public void testGetScreen() {
    status.getScreen();
  }

  @Test
  public void testSetScreen() {
    status.setScreen("contract");
  }

}
