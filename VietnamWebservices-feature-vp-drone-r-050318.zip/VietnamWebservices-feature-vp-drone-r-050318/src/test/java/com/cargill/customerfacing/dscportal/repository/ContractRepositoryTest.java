package com.cargill.customerfacing.dscportal.repository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cargill.customerfacing.dscportal.domain.Contract;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;

@RunWith(SpringJUnit4ClassRunner.class)
public class ContractRepositoryTest {

  private ContractRepository contractRepository;
  
  JdbcTemplate dynamicNamedParameterJdbcTemplate;
  
  Contract contract;
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      contractRepository = new ContractRepository();
      dynamicNamedParameterJdbcTemplate = Mockito.mock(JdbcTemplate.class);
      contractRepository.jdbcTemplate = dynamicNamedParameterJdbcTemplate;
      contract = new Contract();
      contract.setBalanceStock(100);
      contract.setBasis("basis");
      contract.setCakDate("10/11/2017");
      contract.setCakNo("15");
      contract.setCargoOrigin("cargoOrigin");
      contract.setCommodity("SBM");
      contract.setContractCategory("VNGOSC");
      contract.setContractId(1);
      contract.setContractPrice(100);
      contract.setContractStatus("Unsigned");
      contract.setContractType("Service");
      contract.setContractTypeId(1);
      contract.setErpContractStatus(1);
      contract.setCurrency("doller");
      contract.setCustomerId("123");
      contract.setDestination("Desc");
      contract.setFinalWeightAt("wet");
      contract.setPackageType("Type");
      contract.setPaymentTerms("Terms");
      contract.setQuantity(123);
      contract.setReceived(10);
      contract.setShipPeriod("12/12/2017");
      contract.setStatusId("1");
      contract.setStorageTerms("ST");
      contract.setTendered(10);
      contract.setTolarance(1);
      contract.setUnitPrice(10);
  }
  
  @Test
  public void getContractList() throws Exception {
//    List<Contract> contracts = contractRepository.getContractlist("Service", "Unsigned", "VNGOSC", "rk@crgl.com","S",1,10);
//    assertTrue(contracts.isEmpty());
//    List<Contract> contractsall = contractRepository.getContractlist("Service", "All", "VNGOSC", "rk@crgl.com","S",1,10);
//    assertTrue(contractsall.isEmpty());
//    
//    contractRepository.jdbcTemplate = null;
//    boolean thrown = false;
//    try {
//      contractRepository.getContractlist("Service", "All", "VNGOSC", "rk@crgl.com","S",1,10);
//    } catch (Exception e) {
//      thrown = true;
//    }
//    assertTrue(thrown);
  }
  
  @Test
  public void getContractDetails() throws Exception {
//    contractRepository.getContract(1, "VNGOSC", "rk@crgl.com");
//    assertTrue(true);
//    
//    contractRepository.jdbcTemplate = null;
//    boolean thrown = false;
//    try {
//      contractRepository.getContract(1, "VNGOSC", "rk@crgl.com");
//    } catch (Exception e) {
//      thrown = true;
//    }
//    assertTrue(thrown);
  }
  
  @Test
  public void getCustomerDetails() throws Exception {
//    List<Customer> customer = contractRepository.getCustomerList("VNGOSC");
//    assertTrue(customer.isEmpty());
//    
//    contractRepository.jdbcTemplate = null;
//    boolean thrown = false;
//    try {
//      contractRepository.getCustomerList("VNGOSC");
//    } catch (Exception e) {
//      thrown = true;
//    }
//    assertTrue(thrown);
  }
  
  @Test
  public void getStatusDetails() throws Exception {
//    List<Status> status = contractRepository.getStatusList("payment");
//    assertTrue(status.isEmpty());
//    
//    contractRepository.jdbcTemplate = null;
//    boolean thrown = false;
//    try {
//      contractRepository.getStatusList("payment");
//    } catch (Exception e) {
//      thrown = true;
//    }
//    assertTrue(thrown);
  }
  
  @Test
  public void testInsertContract() throws BaseClassException {
//    Contract l = contractRepository.insertContract(contract, "rk@gmail.com","VNGOSC");
//    assertTrue(l==null);
//    
//    contractRepository.jdbcTemplate = null;
//    boolean thrown = false;
//    try {
//      contractRepository.insertContract(contract, "rk@gmail.com","VNGOSC");
//    } catch (Exception e) {
//      thrown = true;
//    }
//    assertTrue(thrown);
  }
  
  @Test
  public void testUpdateContract() throws BaseClassException {
//    int l = contractRepository.updateContract(contract, 1,"rk@gmail.com");
//    assertTrue(l==0);
//    
//    contractRepository.jdbcTemplate = null;
//    boolean thrown = false;
//    try {
//      contractRepository.updateContract(contract, 1,"rk@gmail.com");
//    } catch (Exception e) {
//      thrown = true;
//    }
//    assertTrue(thrown);
  }
//  
  @Test
  public void testDeleteContract() throws BaseClassException {
//    int l = contractRepository.deleteContract(1, "rk@gmail.com");
//    assertTrue(l==0);
//    
//    contractRepository.jdbcTemplate = null;
//    boolean thrown = false;
//    try {
//      contractRepository.deleteContract(1, "rk@gmail.com");
//    } catch (Exception e) {
//      thrown = true;
//    }
//    assertTrue(thrown);
  }
}
