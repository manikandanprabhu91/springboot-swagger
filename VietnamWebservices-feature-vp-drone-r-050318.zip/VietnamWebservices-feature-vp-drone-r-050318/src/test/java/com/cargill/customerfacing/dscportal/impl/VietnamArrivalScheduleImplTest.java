package com.cargill.customerfacing.dscportal.impl;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cargill.customerfacing.dscportal.domain.ArrivalSchedule;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.repository.ArrivalScheduleRepository;
import com.cargill.customerfacing.dscportal.service.IArrivalSchedule;

@RunWith(SpringJUnit4ClassRunner.class)
public class VietnamArrivalScheduleImplTest {
  
  VietnamArrivalScheduleImpl vietnamArrivalScheduleImpl;
  
  @Mock
  IArrivalSchedule iArrivalSchedule;
  
  ArrivalScheduleRepository arrivalScheduleRepository;
  
  ArrivalSchedule arrivalSchedule;
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      vietnamArrivalScheduleImpl = new VietnamArrivalScheduleImpl();
      arrivalScheduleRepository = Mockito.mock(ArrivalScheduleRepository.class);
      vietnamArrivalScheduleImpl.arrivalScheduleRepository = arrivalScheduleRepository;
      arrivalSchedule = new ArrivalSchedule();
      arrivalSchedule.setArrivalScheduleId(1);
      arrivalSchedule.setCommodity("commodity");
      arrivalSchedule.setContractId(1);
      arrivalSchedule.setEtaDate("2017-12-11");
      arrivalSchedule.setEtaTime("00:00");
      arrivalSchedule.setShipmentPeriod("period");
      arrivalSchedule.setTendered("ss");
      arrivalSchedule.setVesselName("SN");
      arrivalSchedule.setApprovedQuantity(10);
      arrivalSchedule.setWareHouse("soy");
  }

  @Test
  public void testInsertArrivalSchedule() throws BaseClassException {
    ArrivalSchedule l = vietnamArrivalScheduleImpl.insertArrivalSchedule( arrivalSchedule,"rk@gmail.com","VNGOSC");
    assertTrue(l==null);
  }

  @Test
  public void testUpdateArrivalSchedule() throws BaseClassException {
    int l = vietnamArrivalScheduleImpl.updateArrivalSchedule(arrivalSchedule, "rk@gmail.com","VNGOSC");
    assertTrue(l==0);
  }

  @Test
  public void testDeleteArrivalSchedule() throws BaseClassException {
    int l = vietnamArrivalScheduleImpl.deleteArrivalSchedule(1, 1);
    assertTrue(l==0);
  }

  @Test
  public void testGetArrivalScheduleList() throws BaseClassException {
    List<ArrivalSchedule> arrivalSchedules = vietnamArrivalScheduleImpl.getArrivalScheduleList(1, "ark@gmail.com","");
    assertTrue(arrivalSchedules.isEmpty());
  }

}
