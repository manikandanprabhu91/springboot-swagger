package com.cargill.customerfacing.dscportal.repository;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cargill.customerfacing.dscportal.domain.ApprovedQuantity;
import com.cargill.customerfacing.dscportal.domain.Payment;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;

@RunWith(SpringJUnit4ClassRunner.class)
public class PaymentRepositoryTest{
  
  PaymentRepository paymentRepository;
  
  JdbcTemplate dynamicNamedParameterJdbcTemplate;
  
  Payment payment;
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      paymentRepository = new PaymentRepository();
      dynamicNamedParameterJdbcTemplate = Mockito.mock(JdbcTemplate.class);
      paymentRepository.jdbcTemplate = dynamicNamedParameterJdbcTemplate;
      payment = new Payment();
      payment.setPaymentAmount(10000);
      payment.setContractId(1);
      payment.setPaymentDate("2017-12-26");
      payment.setFile("filename");
      payment.setPaymentId(1);
      payment.setStatusCode("NPD");
      payment.setStatusDesc("");
      payment.setStatusDescription("");
  }

  @Test
  public void testGetPaymentList() throws BaseClassException {
    List<Payment> payments = paymentRepository.getPaymentList(1, "rk@crgl.com");
    assertTrue(payments.isEmpty());
    
    paymentRepository.jdbcTemplate = null;
    boolean thrown = false;
    try {
      paymentRepository.getPaymentList(1, "rk@crgl.com");
    } catch (Exception e) {
      thrown = true;
    }
    assertTrue(thrown);
  }

  @Test
  public void testInsertPayment() throws BaseClassException{
//    Payment l = paymentRepository.insertPayment(payment, "rk@crgl.com");
//    assertTrue(l==0);
    
    paymentRepository.jdbcTemplate = null;
    boolean thrown = false;
    try {
      paymentRepository.insertPayment(payment, "rk@crgl.com");
    } catch (Exception e) {
      thrown = true;
    }
    assertTrue(thrown);
  }

//  @Test
//  public void testUpdatePayment() throws BaseClassException{
//    int l = paymentRepository.updatePayment(payment, "rk@crgl.com");
//    assertTrue(l==0);
//    
//    paymentRepository.jdbcTemplate = null;
//    boolean thrown = false;
//    try {
//      paymentRepository.updatePayment(payment, "rk@crgl.com");
//    } catch (Exception e) {
//      thrown = true;
//    }
//    assertTrue(thrown);
//  }

  @Test
  public void testDeletePayment() throws BaseClassException{
    int l = paymentRepository.deletePayment(1, 2, "rk@crgl.com");
    assertTrue(l==0);
    
    paymentRepository.jdbcTemplate = null;
    boolean thrown = false;
    try {
      paymentRepository.deletePayment(1, 2, "rk@crgl.com");
    } catch (Exception e) {
      thrown = true;
    }
    assertTrue(thrown);
  }

//  @Test
//  public void testUpdateApprovedQuantity() throws BaseClassException{
//    ApprovedQuantity approvedQuantity = new ApprovedQuantity();
//    approvedQuantity.setApprovedQty(100);
//    approvedQuantity.setApprovedQuantityId(1);
//    approvedQuantity.setContractId(1);
//    int l = paymentRepository.updateApprovedQuantity(approvedQuantity, "rk@crgl.com","");
//    assertTrue(l==0);
//    
//    paymentRepository.jdbcTemplate = null;
//    boolean thrown = false;
//    try {
//      paymentRepository.updateApprovedQuantity(approvedQuantity, "rk@crgl.com","");
//    } catch (Exception e) {
//      thrown = true;
//    }
//    assertTrue(thrown);
//  }

  @Test
  public void testGetApprovedQuantityList() throws BaseClassException{
    ApprovedQuantity approvedQuantity = paymentRepository.getApprovedQuantityList(1);
    assertTrue(approvedQuantity==null);
    
    paymentRepository.jdbcTemplate = null;
    boolean thrown = false;
    try {
      paymentRepository.getApprovedQuantityList(1);
    } catch (Exception e) {
      thrown = true;
    }
    assertTrue(thrown);
  }

}
