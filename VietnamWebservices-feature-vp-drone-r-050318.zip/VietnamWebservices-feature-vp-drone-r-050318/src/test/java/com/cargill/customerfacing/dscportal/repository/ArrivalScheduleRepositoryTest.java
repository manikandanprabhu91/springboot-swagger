package com.cargill.customerfacing.dscportal.repository;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.cargill.customerfacing.dscportal.domain.ArrivalSchedule;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;

@RunWith(SpringJUnit4ClassRunner.class)
public class ArrivalScheduleRepositoryTest{

  ArrivalScheduleRepository arrivalScheduleRepository;
  
  JdbcTemplate dynamicNamedParameterJdbcTemplate;
  
  ArrivalSchedule arrivalSchedule;
  
  @Before
  public void setupMock() {
      MockitoAnnotations.initMocks(this);
      arrivalScheduleRepository = new ArrivalScheduleRepository();
      dynamicNamedParameterJdbcTemplate = Mockito.mock(JdbcTemplate.class);
      arrivalScheduleRepository.jdbcTemplate = dynamicNamedParameterJdbcTemplate;
      arrivalSchedule = new ArrivalSchedule();
      arrivalSchedule.setArrivalScheduleId(1);
      arrivalSchedule.setCommodity("commodity");
      arrivalSchedule.setContractId(1);
      arrivalSchedule.setEtaDate("2017-12-11");
      arrivalSchedule.setEtaTime("00:00");
      arrivalSchedule.setShipmentPeriod("period");
      arrivalSchedule.setTendered("ss");
      arrivalSchedule.setVesselName("SN");
      arrivalSchedule.setApprovedQuantity(10);
      arrivalSchedule.setWareHouse("soy");
      arrivalSchedule.setDeliveryBasis("basis");
  }
  
  @Test
  public void testInsertArrivalSchedule() throws BaseClassException {
//    int l = arrivalScheduleRepository.insertArrivalSchedule( arrivalSchedule,"rk@gmail.com","VNGOSC");
//    assertTrue(l==0);
//    
    arrivalScheduleRepository.jdbcTemplate = null;
    boolean thrown = false;
    try {
      arrivalScheduleRepository.insertArrivalSchedule( arrivalSchedule,"rk@gmail.com","VNGOSC");
    } catch (Exception e) {
      thrown = true;
    }
    assertTrue(thrown);
  }

  @Test
  public void testUpdateArrivalSchedule() throws BaseClassException {
//    int l = arrivalScheduleRepository.updateArrivalSchedule(arrivalSchedule,  "rk@gmail.com","VNGOSC");
//    assertTrue(l==0);
    
    arrivalScheduleRepository.jdbcTemplate = null;
    boolean thrown = false;
    try {
      arrivalScheduleRepository.updateArrivalSchedule(arrivalSchedule, "rk@gmail.com","VNGOSC");
    } catch (Exception e) {
      thrown = true;
    }
    assertTrue(thrown);
  }

  @Test
  public void testDeleteArrivalSchedule() throws BaseClassException {
    int l = arrivalScheduleRepository.deleteArrivalSchedule(1, 1);
    assertTrue(l==0);
    
    arrivalScheduleRepository.jdbcTemplate = null;
    boolean thrown = false;
    try {
      arrivalScheduleRepository.deleteArrivalSchedule(1, 1);
    } catch (Exception e) {
      thrown = true;
    }
    assertTrue(thrown);
  }

  @Test
  public void testGetArrivalScheduleList() throws BaseClassException {
    List<ArrivalSchedule> arrivalSchedules = arrivalScheduleRepository.getArrivalScheduleList(1, "ark@gmail.com","");
    assertTrue(arrivalSchedules.isEmpty());
    
    arrivalScheduleRepository.jdbcTemplate = null;
    boolean thrown = false;
    try {
      arrivalScheduleRepository.getArrivalScheduleList(1, "ark@gmail.com","");
    } catch (Exception e) {
      thrown = true;
    }
    assertTrue(thrown);
  }
}
