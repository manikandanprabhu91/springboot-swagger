package com.cargill.customerfacing.dscportal.domain;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
public class PickUpScheduleTest {

  PickUpSchedule pickUpSchedule;
  
  @Before
  public void setupMock() {
    MockitoAnnotations.initMocks(this);
    pickUpSchedule = new PickUpSchedule();
  }
  
  @Test
  public void testGetPickUpDate() {
   pickUpSchedule.getPickUpDate();
  }

  @Test
  public void testSetPickUpDate() {
    pickUpSchedule.setPickUpDate("2012-04-04 04:03:35");
  }

  @Test
  public void testGetApprovedPickUpDate() {
   pickUpSchedule.getApprovedPickUpDate();
  }

  @Test
  public void testSetApprovedPickUpDate() {
    pickUpSchedule.setApprovedPickUpDate("2012-04-04 04:03:35");
  }

  @Test
  public void testGetPickUpId() {
   pickUpSchedule.getPickUpId();
  }

  @Test
  public void testSetPickUpId() {
    pickUpSchedule.setPickUpId(1);
  }

  @Test
  public void testGetArrivalScheduleId() {
   pickUpSchedule.getArrivalScheduleId();
  }

  @Test
  public void testSetArrivalScheduleId() {
    pickUpSchedule.setArrivalScheduleId(1);
  }

  @Test
  public void testGetPickUpQty() {
   pickUpSchedule.getPickUpQty();
  }

  @Test
  public void testSetPickUpQty() {
    pickUpSchedule.setPickUpQty(156);
  }

  @Test
  public void testGetContractId() {
   pickUpSchedule.getContractId();
  }

  @Test
  public void testSetContractId() {
    pickUpSchedule.setContractId(1);
  }

  @Test
  public void testGetFileName() {
   pickUpSchedule.getFileName();
  }

  @Test
  public void testSetFileName() {
    pickUpSchedule.setFileName("vietnam");
  }

  @Test
  public void testGetStatus() {
   pickUpSchedule.getStatus();
  }

  @Test
  public void testSetStatus() {
    pickUpSchedule.setStatus("Agree");
  }

}
