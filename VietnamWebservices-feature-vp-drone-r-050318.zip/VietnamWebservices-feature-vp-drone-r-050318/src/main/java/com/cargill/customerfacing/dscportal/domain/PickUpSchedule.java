/*
 * PickUpSchedule.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.domain;

public class PickUpSchedule extends BaseModel
{
    
    private String pickUpDate;
    private String approvedPickUpDate;
    private int pickUpId;
    private int arrivalScheduleId;
    private int pickUpQty;
    private int contractId;
    private String fileName;
    private String status;
    private String authorizationNumber;
    private String pickUpTime;
    private String approvedPickUpTime;
    private int arrivalTotalQty;
    private int result;
    private int nextval;
    
    
    public int getResult()
    {
        return result;
    }
    public void setResult(int result)
    {
        this.result = result;
    }
    public int getNextval()
    {
        return nextval;
    }
    public void setNextval(int nextval)
    {
        this.nextval = nextval;
    }
    public String getPickUpDate()
    {
        return pickUpDate;
    }
    public void setPickUpDate(String pickUpDate)
    {
        this.pickUpDate = pickUpDate;
    }
    public String getApprovedPickUpDate()
    {
        return approvedPickUpDate;
    }
    public void setApprovedPickUpDate(String approvedPickUpDate)
    {
        this.approvedPickUpDate = approvedPickUpDate;
    }
    public int getArrivalScheduleId()
    {
        return arrivalScheduleId;
    }
    public void setArrivalScheduleId(int arrivalScheduleId)
    {
        this.arrivalScheduleId = arrivalScheduleId;
    }
    public int getContractId()
    {
        return contractId;
    }
    public void setContractId(int contractId)
    {
        this.contractId = contractId;
    }
    public String getStatus()
    {
        return status;
    }
    public void setStatus(String status)
    {
        this.status = status;
    }
    public String getAuthorizationNumber()
    {
        return authorizationNumber;
    }
    public void setAuthorizationNumber(String authorizationNumber)
    {
        this.authorizationNumber = authorizationNumber;
    }
    public String getPickUpTime()
    {
        return pickUpTime;
    }
    public void setPickUpTime(String pickUpTime)
    {
        this.pickUpTime = pickUpTime;
    }
    public String getApprovedPickUpTime()
    {
        return approvedPickUpTime;
    }
    public void setApprovedPickUpTime(String approvedPickUpTime)
    {
        this.approvedPickUpTime = approvedPickUpTime;
    }
    public int getArrivalTotalQty()
    {
        return arrivalTotalQty;
    }
    public void setArrivalTotalQty(int arrivalTotalQty)
    {
        this.arrivalTotalQty = arrivalTotalQty;
    }
    public String getFileName()
    {
        return fileName;
    }
    public void setFileName(String fileName)
    {
        this.fileName = fileName;
    }
    public int getPickUpId()
    {
        return pickUpId;
    }
    public void setPickUpId(int pickUpId)
    {
        this.pickUpId = pickUpId;
    }
    public int getPickUpQty()
    {
        return pickUpQty;
    }
    public void setPickUpQty(int pickUpQty)
    {
        this.pickUpQty = pickUpQty;
    }
    
    
}
