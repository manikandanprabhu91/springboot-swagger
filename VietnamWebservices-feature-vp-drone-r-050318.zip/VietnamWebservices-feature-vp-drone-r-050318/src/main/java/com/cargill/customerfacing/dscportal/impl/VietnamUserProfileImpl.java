/*
 * VietnamUserProfileImpl.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cargill.customerfacing.dscportal.domain.UserConfig;
import com.cargill.customerfacing.dscportal.domain.UserProfile;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.repository.UserProfileRepository;
import com.cargill.customerfacing.dscportal.service.IUserProfile;

@Service
public class VietnamUserProfileImpl implements IUserProfile
{
    
    @Autowired
    UserProfileRepository profileRepository;
    
    @Override
    public List<UserConfig> getUserConfig(String contractCategory ,
                        String userid) throws BaseClassException
    {
        return profileRepository.getUserConfig(contractCategory, userid);
    }
    
    @Override
    public int updateUserConfig(UserConfig userConfig ,
                        String contractCategory , String userid)
                        throws BaseClassException
    {
        return profileRepository.updateUserConfig(userConfig, contractCategory,
                            userid);
    }
    
    @Override
    public UserProfile insertUserProfile(UserProfile userProfile ,
                        String userid) throws BaseClassException
    {
        return profileRepository.insertUserProfile(userProfile, userid);
    }
    
    @Override
    public int updateUserProfile(UserProfile userProfile , String userid)
                        throws BaseClassException
    {
        return profileRepository.updateUserProfile(userProfile, userid);
    }
}
