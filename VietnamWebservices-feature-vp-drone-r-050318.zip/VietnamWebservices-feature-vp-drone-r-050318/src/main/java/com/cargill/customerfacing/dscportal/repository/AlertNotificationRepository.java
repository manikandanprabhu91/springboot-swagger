/*
 * AlertNotificationRepository.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;

import com.cargill.customerfacing.dscportal.domain.DSCConstants;
import com.cargill.customerfacing.dscportal.domain.SetUpAlert;
import com.cargill.customerfacing.dscportal.domain.UserAlertMapping;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;

@Repository
public class AlertNotificationRepository
{
  
  private static Logger logger = LoggerFactory
            .getLogger(AlertNotificationRepository.class);
  
  @Autowired
  JdbcTemplate jdbcTemplate;
  
  /**
   * This method is used to insert record in setup alert table
   * 
   * @param alertCode
   * @param contractCategory
   * @param customerId
   * @return
   * @throws BaseClassException
   */
  @SuppressWarnings("null")
public SetUpAlert setupAlert(int alertCode , String contractCategory ,
                      String customerId , String userid , int contractId , int paymentId ,
            int invoiceId,int addon) throws BaseClassException
  {
    int nextval = 0;
    StringBuilder var = new StringBuilder();
    var = var.append(DSCConstants.ERROR);
    int insertresult = 0;
    Date today = new java.util.Date();
    long t = today.getTime();
    SetUpAlert setUpAlert = null;
    String message = "";
    String  message1 = "";
    String contract = "%contractId%";
    try
    {
      setUpAlert = jdbcTemplate
                .queryForObject(DSCConstants.GET_ALERTID, new Object[]
      { alertCode, contractCategory }, new BeanPropertyRowMapper<SetUpAlert>(
                SetUpAlert.class));
      
      
      if (setUpAlert != null)
      {
          if(setUpAlert.getAlertCode() == 100) {
              message = setUpAlert.getMessage().replace(contract,String.valueOf(contractId));
          }else if(setUpAlert.getAlertCode() == 101) {
              message1 = setUpAlert.getMessage().replace(contract,String.valueOf(contractId));
              message = message1.replace("%paymentId%",String.valueOf(paymentId));
          }else if(setUpAlert.getAlertCode() == 104) {
              message = setUpAlert.getMessage().replace("%paymentId%",String.valueOf(paymentId));
         }else if(setUpAlert.getAlertCode() == 201 || setUpAlert.getAlertCode() == 202 || setUpAlert.getAlertCode() == 203) {
              message1 = setUpAlert.getMessage().replace(contract,String.valueOf(contractId));
              message = message1.replace("%pickId%",String.valueOf(addon));
         }else if(setUpAlert.getAlertCode() == 2 ) {
              message = setUpAlert.getMessage().replace("%cakno%",String.valueOf(addon));
        }
          nextval = jdbcTemplate.queryForObject(
                              DSCConstants.ACTUAL_ALERT_NEXTVAL, new Object[]
                              {}, Integer.class);
          
        insertresult = jdbcTemplate.update(DSCConstants.INSERT_ACTUAL_ALERT,
                  new Object[]
                  { nextval,customerId, setUpAlert.getAlertId(),
                          setUpAlert.getDescription(),message, contractId, paymentId,
                          invoiceId, userid, new java.sql.Date(t), userid,
                          new java.sql.Date(t), contractCategory, new java.sql.Date(t) });
                  
        if (insertresult > 0)
        {
            setUpAlert.setResult(jdbcTemplate.update(
                    DSCConstants.INSERT_ACTUAL_ALERT_USERMAP, new Object[]
                    { alertCode, contractCategory, customerId, contractId,
                            paymentId, invoiceId }));
            setUpAlert.setNextval(nextval);
        }
      }else {
          setUpAlert.setResult(0);
      }
      logger.info("NotificationRepository End -> ");
    } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
    {
      logger.error(var.append(cannotGetJdbcConnectionException.getMessage())
                .toString());
      throw new BaseClassException(cannotGetJdbcConnectionException.getMessage()
                + DSCConstants.ERROR500);
    } catch (DataAccessException accessException)
    {
      logger.error(var.append(accessException.getMessage()).toString());
      throw new BaseClassException(
                accessException.getMessage() + DSCConstants.ERROR500);
    } catch (Exception e)
    {
      logger.error(var.append(e.getMessage()).toString());
      throw new BaseClassException(e.getMessage());
    }
    return setUpAlert;
  }
  
  /**
   * Method to get Alert list
   * 
   * @param contractCategory
   * @param userId
   * @return
   * @throws BaseClassException
   */
  public List<SetUpAlert> getAlertList(String contractCategory , String userId,
                      int limit, int index)
            throws BaseClassException
  {
    StringBuilder var = new StringBuilder();
    var = var.append(DSCConstants.ERROR);
    List<SetUpAlert> message = null;
    StringBuilder query = new StringBuilder();
    logger.info("::::::::::::: getAlertList :::::::::::::::::::::::::");
    try
    {
        query.append(DSCConstants.ACTUAL_ALERT_SELECT_QUERY);
        
        if(limit > 0)
        {           
            query.append(DSCConstants.QUERY_LIMIT_APPEND);
        }
        
        PreparedStatementSetter pss = new PreparedStatementSetter() {
            public void setValues(PreparedStatement preparedStatement) throws SQLException {
                int i = 0;
                    i++;
                    preparedStatement.setString(i, contractCategory);
                    i++;
                    preparedStatement.setString(i, userId);
                
                if(limit > 0)
                {
                    int offset = (index == 0) ? 0 : index - 1;
                    i++;
                    preparedStatement.setInt(i, limit);
                    i++;
                    preparedStatement.setInt(i, offset);
                }
              
            }
          };
      message = jdbcTemplate.query(query.toString(),
                          pss,
                new BeanPropertyRowMapper<SetUpAlert>(SetUpAlert.class));
    } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
    {
      logger.error(var.append(cannotGetJdbcConnectionException.getMessage())
                .toString());
      throw new BaseClassException(cannotGetJdbcConnectionException.getMessage()
                + DSCConstants.ERROR500);
    } catch (DataAccessException accessException)
    {
      logger.error(var.append(accessException.getMessage()).toString());
      throw new BaseClassException(
                accessException.getMessage() + DSCConstants.ERROR500);
    } catch (Exception e)
    {
      logger.error(var.append(e.getMessage()).toString());
      throw new BaseClassException(e.getMessage());
    }
    return message;
  }
  
  /**
   * Method to get Alert count
   * 
   * @param contractCategory
   * @param userId
   * @return
   * @throws BaseClassException
   */
  public int getAlertCount(String contractCategory , String userId)
            throws BaseClassException
  {
    StringBuilder var = new StringBuilder();
    var = var.append(DSCConstants.ERROR);
    List<SetUpAlert> message = null;
    int count = 0;
    logger.info("::::::::::::: getAlertCount :::::::::::::::::::::::::");
    StringBuilder query = new StringBuilder();
    try
    {
      query.append(DSCConstants.ACTUAL_ALERT_COUNT);
      query.append(DSCConstants.ACTUAL_ALERT_SELECT_QUERY);
      query.append(DSCConstants.ACTUAL_ALERT_COUNT_END);
      
      PreparedStatementSetter pss = new PreparedStatementSetter() {
          public void setValues(PreparedStatement preparedStatement) throws SQLException {
              int i = 0;
                  i++;
                  preparedStatement.setString(i, contractCategory);
                  i++;
                  preparedStatement.setString(i, userId);
          }
        };
      message = jdbcTemplate.query(query.toString(),
                          pss,
                new BeanPropertyRowMapper<SetUpAlert>(SetUpAlert.class));
      
      for(SetUpAlert s:message) {
          count = s.getResult();
      }
    } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
    {
      logger.error(var.append(cannotGetJdbcConnectionException.getMessage())
                .toString());
      throw new BaseClassException(cannotGetJdbcConnectionException.getMessage()
                + DSCConstants.ERROR500);
    } catch (DataAccessException accessException)
    {
      logger.error(var.append(accessException.getMessage()).toString());
      throw new BaseClassException(
                accessException.getMessage() + DSCConstants.ERROR500);
    } catch (Exception e)
    {
      logger.error(var.append(e.getMessage()).toString());
      throw new BaseClassException(e.getMessage());
    }
    return count;
  }
  
  /**
   * Method to update alert details
   * 
   * @param actualAlertId
   * @param alertStatus
   * @param userid
   * @return
   * @throws BaseClassException
   */
  public int updateAlert(int actualAlertId , String alertStatus , String userid)
            throws BaseClassException
  {
    logger.info(
              ":::::::::::::::::::::: updateAlert repository ::::::::::::::::::::::::");
    Date today = new java.util.Date();
    long t = today.getTime();
    int rslt = 0;
    StringBuilder var = new StringBuilder();
    var = var.append(DSCConstants.ERROR);
    try
    {
      rslt = jdbcTemplate.update(DSCConstants.UPDATE_ACTUAL_ALERT, new Object[]
      { alertStatus, new java.sql.Date(t), userid, userid, actualAlertId });
    } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
    {
      logger.error(var.append(cannotGetJdbcConnectionException.getMessage())
                .toString());
      throw new BaseClassException(cannotGetJdbcConnectionException.getMessage()
                + DSCConstants.ERROR500);
    } catch (DataAccessException accessException)
    {
      logger.error(var.append(accessException.getMessage()).toString());
      throw new BaseClassException(
                accessException.getMessage() + DSCConstants.ERROR500);
    } catch (Exception e)
    {
      logger.error(var.append(e.getMessage()).toString());
      throw new BaseClassException(e.getMessage());
    }
    return rslt;
  }
  
  
  
  /**
   * Method to get alert usermapping list
   * 
   * @param contractCategory
   * @param userid
   * @return
   * @throws Exception
   */
  public List<UserAlertMapping> getAlertUserMappingList(
            String contractCategory , String userid) throws BaseClassException
  {
    List<UserAlertMapping> userAlertMappings = null;
    StringBuilder var = new StringBuilder();
    var = var.append(DSCConstants.ERROR);
    logger.info(
              ":::::::::::::::::::::: getAlertUserMappingList repository ::::::::::::::::::::::::");
    try
    {
      userAlertMappings = jdbcTemplate.query(DSCConstants.USERMAP_SELECT_QUERY,
                new Object[]
                { contractCategory, userid },
                new BeanPropertyRowMapper<UserAlertMapping>(
                          UserAlertMapping.class));
    } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
    {
      logger.error(var.append(cannotGetJdbcConnectionException.getMessage())
                .toString());
      throw new BaseClassException(cannotGetJdbcConnectionException.getMessage()
                + DSCConstants.ERROR500);
    } catch (DataAccessException accessException)
    {
      logger.error(var.append(accessException.getMessage()).toString());
      throw new BaseClassException(
                accessException.getMessage() + DSCConstants.ERROR500);
    } catch (Exception e)
    {
      logger.error(var.append(e.getMessage()).toString());
      throw new BaseClassException(e.getMessage());
    }
    return userAlertMappings;
  }
  
  /**
   * Method to update the alert user mapping details
   * 
   * @param userAlertMapping
   * @param usermappingId
   * @param contractCategory
   * @param userid
   * @return
   * @throws BaseClassException
   */
  public int updateAlertUserMapping(UserAlertMapping userAlertMapping ,
             String contractCategory , String userid)
            throws BaseClassException
  {
    Date today = new java.util.Date();
    long t = today.getTime();
    int rsult = 0;
    StringBuilder var = new StringBuilder();
    var = var.append(DSCConstants.ERROR);
    try
    {
      logger.info(
                ":::::::::::::::::::::: updateAlertUserMapping ::::::::::::::::::::::::");
      rsult = jdbcTemplate.update(DSCConstants.USERMAP_UPDATE_QUERY,
                new Object[]
                { userAlertMapping.getWeb(), userAlertMapping.getEmail(),
                        userAlertMapping.getSms(),
                        userAlertMapping.getAlertId(), userid,
                        new java.sql.Date(t), contractCategory, userAlertMapping.getUserMappingId(),
                        userid });
    } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
    {
      logger.error(var.append(cannotGetJdbcConnectionException.getMessage())
                .toString());
      throw new BaseClassException(cannotGetJdbcConnectionException.getMessage()
                + DSCConstants.ERROR500);
    } catch (DataAccessException accessException)
    {
      logger.error(var.append(accessException.getMessage()).toString());
      throw new BaseClassException(
                accessException.getMessage() + DSCConstants.ERROR500);
    } catch (Exception e)
    {
      logger.error(var.append(e.getMessage()).toString());
      throw new BaseClassException(e.getMessage());
    }
    return rsult;
  }
  
}
