/*
 * IUserProfile.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.service;

import java.util.List;

import com.cargill.customerfacing.dscportal.domain.UserConfig;
import com.cargill.customerfacing.dscportal.domain.UserProfile;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;

public interface IUserProfile
{
    
    public List<UserConfig> getUserConfig(String contractCategory ,
                        String userid) throws BaseClassException;
    
    public int updateUserConfig(UserConfig userConfig ,
                        String contractCategory , String userid)
                        throws BaseClassException;
    
    public UserProfile insertUserProfile(UserProfile userProfile ,
                        String userid) throws BaseClassException;
    
    public int updateUserProfile(UserProfile userProfile , String userid)
                        throws BaseClassException;
    
}
