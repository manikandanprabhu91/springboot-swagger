/*
 * BaseClassException.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cargill.customerfacing.dscportal.domain.DSCConstants;
import com.cargill.customerfacing.dscportal.domain.ResponseGateway;

public class BaseClassException extends Exception
{
  
  private static final long serialVersionUID = 1L;
  
  private Exception exception;
  
  private static final ResponseGateway gateway = new ResponseGateway();
  
  public Exception getException()
  {
    return exception;
  }
  
  public BaseClassException(String errorCode , String errorMessage ,
            String errorOrgin , Exception exception)
  {
    super("Error occurred in " + errorOrgin + " with Error code: " + errorCode
              + " Error detail: " + errorMessage, exception);
    this.exception = exception;
  }
  
  public BaseClassException(String errorCode , String errorMessage)
  {
    super("Error code: " + errorCode + " Error detail: " + errorMessage);
  }
  
  public BaseClassException(String errorMessage)
  {
    super("Error detail: " + errorMessage);
  }
  
  public static ResponseEntity<ResponseGateway> catchException(
            String errorMessage)
  {
    if (errorMessage != null)
    {
      gateway.setStatusCode(DSCConstants.CODE500);
      gateway.setStatus(DSCConstants.SERVERERROR);
    }else {
        gateway.setStatusCode(DSCConstants.CODE404);
        gateway.setStatus(DSCConstants.NORESULT);
    }
    return new ResponseEntity<>(gateway, HttpStatus.valueOf(500));
  }
  
}
