package com.cargill.customerfacing.dscportal.domain;

public class ActualAlert extends BaseModel
{
  
  private int actualAlertId;
  private String customerId;
  private int alertId;
  private String actualMessage;
  private int contractId;
  private int paymentId;
  private int invoiceId;
  private String contractCategory;
  private String receivedOnDate;
  
  public int getActualAlertId()
  {
    return actualAlertId;
  }
  public void setActualAlertId(int actualAlertId)
  {
    this.actualAlertId = actualAlertId;
  }
  public String getCustomerId()
  {
    return customerId;
  }
  public void setCustomerId(String customerId)
  {
    this.customerId = customerId;
  }
  public int getAlertId()
  {
    return alertId;
  }
  public void setAlertId(int alertId)
  {
    this.alertId = alertId;
  }
  public String getActualMessage()
  {
    return actualMessage;
  }
  public void setActualMessage(String actualMessage)
  {
    this.actualMessage = actualMessage;
  }
  public int getContractId()
  {
    return contractId;
  }
  public void setContractId(int contractId)
  {
    this.contractId = contractId;
  }
  public int getPaymentId()
  {
    return paymentId;
  }
  public void setPaymentId(int paymentId)
  {
    this.paymentId = paymentId;
  }
  public int getInvoiceId()
  {
    return invoiceId;
  }
  public void setInvoiceId(int invoiceId)
  {
    this.invoiceId = invoiceId;
  }
public String getContractCategory()
{
    return contractCategory;
}
public void setContractCategory(String contractCategory)
{
    this.contractCategory = contractCategory;
}
public String getReceivedOnDate()
{
    return receivedOnDate;
}
public void setReceivedOnDate(String receivedOnDate)
{
    this.receivedOnDate = receivedOnDate;
}
  
  
}
