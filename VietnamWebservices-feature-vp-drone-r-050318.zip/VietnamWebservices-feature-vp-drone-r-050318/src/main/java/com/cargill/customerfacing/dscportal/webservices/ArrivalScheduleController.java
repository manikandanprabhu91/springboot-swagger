/*
 * ArrivalScheduleController.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.webservices;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cargill.customerfacing.dscportal.domain.ArrivalSchedule;
import com.cargill.customerfacing.dscportal.domain.DSCConstants;
import com.cargill.customerfacing.dscportal.domain.ResponseGateway;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.region.factory.RegionFactoryService;

@RestController
@EnableAutoConfiguration
@RequestMapping(value = "/api/dxo/dsc/v1/auth")
public class ArrivalScheduleController
{
    
    private Logger logger = LoggerFactory.getLogger(ArrivalScheduleController.class);
    
    @Autowired
    RegionFactoryService regionFactoryService;
    
    private ResponseGateway gateway;
    
    /**
     * Method to get arrival schedule list
     * 
     * @param arrivalScheduleId
     * @param contractCategory
     * @param userid
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/arrivalScheduleList", method = RequestMethod.GET, produces = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> getArrivalScheduleList(
                        @RequestParam("contractId")
                        int contractId ,
                        @RequestParam("contractCategory")
                        String contractCategory , @RequestParam("userid")
                        String userid,@RequestParam(value = "basiscode" , required=false)
                        String basiscode) throws BaseClassException
    {
        logger.info(":::::::::: getArrivalScheduleList :::::::::::::::");
        ResponseEntity<ResponseGateway> responseGateway = null;
        gateway = new ResponseGateway();
        List<ArrivalSchedule> arrivalSchedules = null;
        try
        {
            if(basiscode == null) {
                basiscode = "";
            }
            arrivalSchedules = regionFactoryService
                                .getArrivalSchedule(contractCategory)
                                .getArrivalScheduleList(contractId,
                                                    userid,basiscode);
            if (arrivalSchedules != null && !arrivalSchedules.isEmpty())
            {
                responseGateway = gateway.buildResponse(arrivalSchedules, DSCConstants.SUCCESS, "", DSCConstants.CODE200, "");
            } else
            {
                responseGateway = gateway.buildResponse(arrivalSchedules, DSCConstants.FAIL, DSCConstants.NORESULT, DSCConstants.CODE200, DSCConstants.F101);
            }
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to insert arrival schedule details
     * 
     * @param arrivalSchedule
     * @param contractId
     * @param contractCategory
     * @param userid
     * @return
     */
    @RequestMapping(value = "/arrivalSchedule", method = RequestMethod.POST, produces = DSCConstants.APPLICATION_JSON, consumes = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> insertArrivalSchedule(@RequestBody
    ArrivalSchedule arrivalSchedule , @RequestParam("contractCategory")
    String contractCategory , @RequestParam("userid")
    String userid) throws BaseClassException
    {
        logger.info(":::::::::: insertArrivalSchedule :::::::::::::::");
        gateway = new ResponseGateway();
        ResponseEntity<ResponseGateway> responseGateway = null;
        ArrivalSchedule schedule = null;
        try
        {
            schedule = regionFactoryService
                                .getArrivalSchedule(contractCategory)
                                .insertArrivalSchedule(arrivalSchedule, userid,contractCategory);
            if (schedule.getResult() > 0)
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.SUCCESS, DSCConstants.SUCCESS_SAVE, DSCConstants.CODE200, String.valueOf(schedule.getNextval()));
            }else if (schedule.getResult() < 0)
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.ARRIVAL_ERROR, DSCConstants.CODE200, DSCConstants.F204);
            } else
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.NOTUPDATED, DSCConstants.CODE200, DSCConstants.F102); 
            }
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to update MarketInformation details
     * 
     * @param contract
     * @param contractCategory
     */
    @RequestMapping(value = "/updateArrivalSchedule", method = RequestMethod.PATCH, produces = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> updateArrivalSchedule(@RequestBody
    ArrivalSchedule arrivalSchedule , @RequestParam("contractCategory")
    String contractCategory , @RequestParam("userid")
    String userid) throws BaseClassException
    {
        logger.info(":::::::::: updateArrivalSchedule :::::::::::::::");
        gateway = new ResponseGateway();
        ResponseEntity<ResponseGateway> responseGateway = null;
        int updatestatus = 0;
        try
        {
            updatestatus = regionFactoryService
                                .getArrivalSchedule(contractCategory)
                                .updateArrivalSchedule(arrivalSchedule, userid,contractCategory);
            if (updatestatus > 0)
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.SUCCESS, DSCConstants.SUCCESS_UPDATE, DSCConstants.CODE200, String.valueOf(arrivalSchedule.getArrivalScheduleId()));
            } else
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.NOTUPDATED, DSCConstants.CODE200, DSCConstants.F102); 
            }
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to delete arrival schedule details
     * 
     * @param contractId
     * @param arrivalScheduleId
     * @param contractCategory
     * @return
     * @throws BaseClassException
     */
    @RequestMapping(value = "/arrivalSchedule", method = RequestMethod.DELETE, produces = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> deleteArrivalSchedule(
                        @RequestParam("contractId")
                        int contractId , @RequestParam("arrivalScheduleId")
                        int arrivalScheduleId ,
                        @RequestParam("contractCategory")
                        String contractCategory) throws BaseClassException
    {
        logger.info(":::::::::: deleteArrivalSchedule :::::::::::::::");
        ResponseEntity<ResponseGateway> responseGateway = null;
        gateway = new ResponseGateway();
        int deletestatus = 0;
        try
        {
            deletestatus = regionFactoryService
                                .getArrivalSchedule(contractCategory)
                                .deleteArrivalSchedule(arrivalScheduleId,
                                                    contractId);
            if (deletestatus > 0)
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.SUCCESS, DSCConstants.SUCCESS_DELETE, DSCConstants.CODE200, String.valueOf(contractId));
            } else
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.NOTUPDATED, DSCConstants.CODE200, DSCConstants.F102); 
            }
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
        }
        return responseGateway;
    }
}
