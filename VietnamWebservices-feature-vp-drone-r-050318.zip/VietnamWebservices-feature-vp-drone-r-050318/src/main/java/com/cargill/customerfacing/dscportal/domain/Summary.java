package com.cargill.customerfacing.dscportal.domain;

public class Summary
{
    private Long totalWeightTruck;
    private Long totalWeightBarge;
    private Long totalWeight;
    
    public Long getTotalWeightTruck()
    {
        return totalWeightTruck;
    }
    public void setTotalWeightTruck(Long totalWeightTruck)
    {
        this.totalWeightTruck = totalWeightTruck;
    }
    public Long getTotalWeightBarge()
    {
        return totalWeightBarge;
    }
    public void setTotalWeightBarge(Long totalWeightBarge)
    {
        this.totalWeightBarge = totalWeightBarge;
    }
    public Long getTotalWeight()
    {
        return totalWeight;
    }
    public void setTotalWeight(Long totalWeight)
    {
        this.totalWeight = totalWeight;
    }
    
//    public Summary() {
//        
//    }
//    
    public Summary(Long totalWeightBarge,Long totalWeightTruck,Long totalWeight) {
        this.totalWeightBarge = totalWeightBarge;
        this.totalWeightTruck = totalWeightTruck;
        this.totalWeight = totalWeight;
    }
    
    
    
}
