package com.cargill.customerfacing.dscportal.domain;

public class BaseModel
{
  
}
