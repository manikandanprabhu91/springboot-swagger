/*
 * ContractController.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.webservices;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cargill.customerfacing.dscportal.domain.Commodity;
import com.cargill.customerfacing.dscportal.domain.Contract;
import com.cargill.customerfacing.dscportal.domain.Customer;
import com.cargill.customerfacing.dscportal.domain.DSCConstants;
import com.cargill.customerfacing.dscportal.domain.ResponseGateway;
import com.cargill.customerfacing.dscportal.domain.Status;
import com.cargill.customerfacing.dscportal.domain.User;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.region.factory.RegionFactoryService;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@EnableAutoConfiguration
@RequestMapping(value = "/api/dxo/dsc/v1/auth")
public class ContractController
{
    
    private Logger logger = LoggerFactory.getLogger(ContractController.class);
    
    @Autowired
    RegionFactoryService regionFactoryService;
    
    //@Autowired
    RestAPIHandler apiHandler;
    
    
    private ResponseGateway gateway;
    
    private User user;
    
    /**
     * This method is used to get contract list
     * 
     * @param contractType
     * @param contractStatus
     * @param contractCategory
     * @param userid
     * @return
     * @throws BaseClassException
     */
    @ApiResponses(value =
    { @ApiResponse(code = 200, message = "Successfully retrieved list"),
                    @ApiResponse(code = 401, message = "You are not authorized to view the resource"),
                    @ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
                    @ApiResponse(code = 404, message = DSCConstants.ERRORNOTFOUND) })
    @RequestMapping(value = "/contractList", method = RequestMethod.GET, produces = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> getContractList(
                        @RequestParam(value ="contractType",required=false)
                        String contractType , @RequestParam(value ="contractStatus",required=false)
                        String contractStatus ,
                        @RequestParam("contractCategory")
                        String contractCategory , @RequestParam("userid")
                        String userid , @RequestParam(value = "searchCriteria",required=false)
                        String searchCriteria , @RequestParam(value ="startindex",required=false)
                        Integer startindex , @RequestParam(value ="limit",required=false)
                        Integer limit) throws BaseClassException
    {
        gateway = new ResponseGateway();
        logger.info(":::::::::: getContractList :::::::::::::::");
        ResponseEntity<ResponseGateway> responseGateway = null;
        List<Contract> contract = null;
        try
        {
            if(contractType == null) {
                contractType = "";
            }
            if(contractStatus == null) {
                contractStatus = "";
            }
            if(searchCriteria == null) {
                searchCriteria = "";
            }
            if(startindex == null) {
                startindex = 0;
            }
            if(limit == null) {
                limit = 0;
            }
            contract = regionFactoryService.getContractService(contractCategory)
                                .getContractlist(contractType, contractStatus,
                                                    contractCategory, userid,
                                                    searchCriteria, startindex,
                                                    limit);
            
            if (contract != null && !contract.isEmpty())
            {
                responseGateway = gateway.buildResponse(contract, DSCConstants.SUCCESS, "", DSCConstants.CODE200, "");
            } else
            {
                responseGateway = gateway.buildResponse(contract, DSCConstants.FAIL, DSCConstants.NORESULT, DSCConstants.CODE200, DSCConstants.F101);
            }
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * 
     * @param contractType
     * @param contractStatus
     * @param contractCategory
     * @param userid
     * @param searchCriteria
     * @return
     * @throws BaseClassException
     */
    @RequestMapping(value = "/contractTotalCount", method = RequestMethod.GET, produces = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> getContractTotal(
                        @RequestParam(value ="contractType",required=false)
                        String contractType , @RequestParam(value ="contractStatus",required=false)
                        String contractStatus ,
                        @RequestParam("contractCategory")
                        String contractCategory , @RequestParam("userid")
                        String userid , @RequestParam(value = "searchCriteria",required=false)
                        String searchCriteria) throws BaseClassException
    {
        gateway = new ResponseGateway();
        logger.info(":::::::::: getContractList :::::::::::::::");
        ResponseEntity<ResponseGateway> responseGateway = null;
        int count = 0;
        try
        {
            if(contractType == null) {
                contractType = "";
            }
            if(contractStatus == null) {
                contractStatus = "";
            }
            if(searchCriteria == null) {
                searchCriteria = "";
            }
            count = regionFactoryService.getContractService(contractCategory)
                                .getContractTotal(contractType, contractStatus,
                                                    contractCategory, userid,
                                                    searchCriteria);
            
            if (count > 0)
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.SUCCESS,"", DSCConstants.CODE200, String.valueOf(count));
            } else
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.NORESULT, DSCConstants.CODE200, DSCConstants.F101);
            }
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * This method to get contract details by passing contract id
     * 
     * @param cakNo
     * @param contractCategory
     * @return
     */
    @RequestMapping(value = "/contractByCakNO", method = RequestMethod.GET, produces = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> contractById(
                        @RequestParam("contractId")
                        int contractId , @RequestParam("contractCategory")
                        String contractCategory , @RequestParam("userid")
                        String userid) throws BaseClassException
    {
        logger.info(":::::::::: contractById :::::::::::::::");
        gateway = new ResponseGateway();
        ResponseEntity<ResponseGateway> responseGateway = null;
        List<Contract> contract = null;
        try
        {
            contract = regionFactoryService.getContractService(contractCategory)
                                .getContract(contractId, contractCategory,
                                                    userid);
            if (contract != null && !contract.isEmpty())
            {
                responseGateway = gateway.buildResponse(contract, DSCConstants.SUCCESS, "", DSCConstants.CODE200, "");
            } else
            {
                responseGateway = gateway.buildResponse(contract, DSCConstants.FAIL, DSCConstants.NORESULT, DSCConstants.CODE200, DSCConstants.F101);
            }
            
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to insert contract details
     * 
     * @param contract
     * @param contractCategory
     */
    @RequestMapping(value = "/contract", method = RequestMethod.POST, produces = DSCConstants.APPLICATION_JSON, consumes = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> insertContract(@RequestBody
    Contract contract , @RequestParam("contractCategory")
    String contractCategory , @RequestParam("userid")
    String userid) throws BaseClassException
    {
        logger.info(":::::::::: insertContract :::::::::::::::");
        Contract contractinsert = null;
        boolean flag = false;
        gateway = new ResponseGateway();
        ResponseEntity<ResponseGateway> responseGateway = null;
        try
        {
            if (!contract.getCustomerId().isEmpty()
                                && contract.getContractPrice() != null)
            {
                flag = true;
            }
            
            if (flag)
            {
                contractinsert = regionFactoryService
                                    .getContractService(contractCategory)
                                    .insertContract(contract, userid,
                                                        contractCategory);
                if (contractinsert.getResult() > 0)
                {
                    responseGateway = gateway.buildResponse(null, DSCConstants.SUCCESS, DSCConstants.SUCCESS_SAVE, DSCConstants.CODE200, String.valueOf(contractinsert.getMaxCount()));
                } else if (contractinsert.getResult() < 0)
                {
                    responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.CAKNOERROR, DSCConstants.CODE200, DSCConstants.F201);
                } else
                {
                    responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.NOTUPDATED, DSCConstants.CODE200, DSCConstants.F102); 
                }
                
            } else
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.MANDATORY, DSCConstants.CODE200, DSCConstants.F103);
            }
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to update contract details
     * 
     * @param contract
     * @param contractCategory
     */
    @RequestMapping(value = "/updateContract", method = RequestMethod.PATCH, produces = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> updateContract(
                        @RequestParam("contractId")
                        int contractId , @RequestBody
                        Contract contract , @RequestParam("contractCategory")
                        String contractCategory , @RequestParam("userid")
                        String userid) throws BaseClassException
    {
        logger.info(":::::::::: updateContract :::::::::::::::");
        int updatestatus = 0;
        Contract oldContract = null;
        gateway = new ResponseGateway();
        ResponseEntity<ResponseGateway> responseGateway = null;
        try
        {
            List contractList = regionFactoryService
                                .getContractService(contractCategory)
                                .getContract(contractId, contractCategory,
                                                    userid);
            if(contractList != null && !contractList.isEmpty()) {
            
            oldContract = setContractValues((Contract) contractList.get(0), contract.getStatusId(),
                                contractCategory, contractId);
            
            updatestatus = regionFactoryService
                                .getContractService(contractCategory)
                                .updateContract(oldContract, contractId,
                                                    userid);
            }
            
            
            if (updatestatus > 0)
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.SUCCESS, DSCConstants.SUCCESS_UPDATE, DSCConstants.CODE200, String.valueOf(contractId));
            } else
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.NOTUPDATED, DSCConstants.CODE200, DSCConstants.F102); 
            }
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to set existing contract values
     * 
     * @param oldContract
     * @param statusId
     * @param contractId
     * @param contractCategory
     * @return
     */
    private Contract setContractValues(Contract oldContract , String statusId ,
                        String contractCategory , int contractId)
    {
        if (oldContract != null)
        {
            oldContract.setStatusId(statusId);
            oldContract.setCommodity(oldContract.getCommodity());
            oldContract.setQuantity(oldContract.getQuantity());
            oldContract.setReceived(oldContract.getReceived());
            oldContract.setBalanceStock(oldContract.getBalanceStock());
            oldContract.setContractTypeId(oldContract.getContractTypeId());
            oldContract.setTendered(oldContract.getTendered());
            oldContract.setBasis(oldContract.getBasis());
            oldContract.setStorageTerms(oldContract.getStorageTerms());
            oldContract.setTolarance(oldContract.getTolarance());
            oldContract.setUnitPrice(oldContract.getUnitPrice());
            oldContract.setPackageType(oldContract.getPackageType());
            oldContract.setShipPeriod(oldContract.getShipPeriod());
            oldContract.setContractPrice(oldContract.getContractPrice());
            oldContract.setDestination(oldContract.getDestination());
            oldContract.setFinalWeightAt(oldContract.getFinalWeightAt());
            oldContract.setCargoOrigin(oldContract.getCargoOrigin());
            oldContract.setCurrency(oldContract.getCurrency());
            oldContract.setPaymentTerms(oldContract.getPaymentTerms());
            oldContract.setErpContractStatus(
                                oldContract.getErpContractStatus());
            oldContract.setCakDate(oldContract.getCakDate());
            oldContract.setCakNo(oldContract.getCakNo());
            oldContract.setContractCategory(contractCategory);
            oldContract.setContractId(contractId);
            oldContract.setCustomerId(oldContract.getCustomerId());
            oldContract.setExpirationDate(oldContract.getExpirationDate());
            oldContract.setInTransitQuantity(
                                oldContract.getInTransitQuantity());
            oldContract.setCustomerName(oldContract.getCustomerName());
        }
        return oldContract;
    }
    
    /**
     * Method to delete contract
     * 
     * @param contractId
     * @param contractCategory
     * @param userid
     * @return
     * @throws BaseClassException
     */
    @RequestMapping(value = "/contract", method = RequestMethod.DELETE, produces = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> deleteContract(
                        @RequestParam("contractId")
                        int contractId , @RequestParam("contractCategory")
                        String contractCategory , @RequestParam("userid")
                        String userid) throws BaseClassException
    {
        logger.info(":::::::::: deleteContract :::::::::::::::");
        int deletestaus = 0;
        gateway = new ResponseGateway();
        ResponseEntity<ResponseGateway> responseGateway = new ResponseEntity<>(
                            gateway, HttpStatus.OK);
        try
        {
            deletestaus = regionFactoryService
                                .getContractService(contractCategory)
                                .deleteContract(contractId, userid);
            if (deletestaus > 0)
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.SUCCESS, DSCConstants.SUCCESS_DELETE, DSCConstants.CODE200, String.valueOf(contractId));
            } else
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.NOTUPDATED, DSCConstants.CODE200, DSCConstants.F102); 
            }
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to get status list
     * 
     * @param screen
     * @param contractCategory
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/statusList", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody
    ResponseEntity<ResponseGateway> getStatusList(@RequestParam("screen")
    String screen , @RequestParam("contractCategory")
    String contractCategory) throws BaseClassException
    {
        logger.info(":::::::::: getStatusList :::::::::::::::");
        gateway = new ResponseGateway();
        ResponseEntity<ResponseGateway> responseGateway =null;
        List<Status> status = null;
        try
        {
            status = regionFactoryService.getContractService(contractCategory)
                                .getStatusList(screen);
            if (status != null && !status.isEmpty())
            {
                responseGateway = gateway.buildResponse(status, DSCConstants.SUCCESS, "", DSCConstants.CODE200, "");
               
            } else
            {
                responseGateway = gateway.buildResponse(status, DSCConstants.FAIL, DSCConstants.NORESULT, DSCConstants.CODE200, DSCConstants.F101);
            }
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to get customer list
     * 
     * @param contractCategory
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/customerList", method = RequestMethod.GET, produces = DSCConstants.APPLICATION_JSON)
    public @ResponseBody
    ResponseEntity<ResponseGateway> getCustomerList(
                        @RequestParam("contractCategory")
                        String contractCategory) throws BaseClassException
    {
        logger.info(":::::::::: getCustomerList :::::::::::::::");
        gateway = new ResponseGateway();
        List<Customer> customer = new ArrayList<Customer>();
        ResponseEntity<ResponseGateway> responseGateway = null;
        
        try
        {
            user = new User();
            if(!user.isCustomerUser()) {
            apiHandler = new RestAPIHandler();
            String customerList = apiHandler.callRestEndpoint(DSCConstants.BZAPI_ACCOUNTS, user);
            
            logger.info(":::::::::: APIHandler :::::::::::::::"+ customerList);
            
            JSONObject jsonObject = new JSONObject(customerList);
            JSONArray jsonArray = jsonObject.getJSONArray("accounts");
            if(jsonArray != null) {
            for (int index = 0; index < jsonArray.length(); index++) {
                JSONObject accountJsonAttr = (JSONObject) jsonArray.get(index);
                if (accountJsonAttr != null) {
                    JSONObject jsonIdentifierObj = accountJsonAttr.getJSONObject("identifier");
                    if (jsonIdentifierObj != null) {
                    String account_code = (String) jsonIdentifierObj.get("account_code");
                    String account_name = (String) jsonIdentifierObj.get("account_name");
                    Customer customerObj = new Customer();
                    customerObj.setCustomerCode(account_code);
                    customerObj.setCustomerName(account_name);
                    customer.add(customerObj);
                    }
                }
            }
            }
            }
            if (customer != null && !customer.isEmpty())
            {
                responseGateway = gateway.buildResponse(customer, DSCConstants.SUCCESS, "", DSCConstants.CODE200, "");
            } else
            {
                responseGateway = gateway.buildResponse(customer, DSCConstants.FAIL, DSCConstants.NORESULT, DSCConstants.CODE200, DSCConstants.F101);
            }
        } catch (Exception e)
        {
            logger.error(":::::::::: getCustomerList :::::::::::::::"+ e.getMessage());
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * 
     * @param contractCategory
     * @return
     * @throws BaseClassException
     */
    @RequestMapping(value = "/commodityproducts", method = RequestMethod.GET, produces = DSCConstants.APPLICATION_JSON)
    public @ResponseBody
    ResponseEntity<ResponseGateway> commodityproductsList(
                        @RequestParam("contractCategory")
                        String contractCategory) throws BaseClassException
    {
        logger.info(":::::::::: commodityproductsList :::::::::::::::");
        gateway = new ResponseGateway();
        List<Commodity> commodity = new ArrayList<Commodity>();
        ResponseEntity<ResponseGateway> responseGateway = null;
        
        try
        {
            user = new User();
            if(!user.isCustomerUser()) {
            apiHandler = new RestAPIHandler();
            String commodityList = apiHandler.callRestEndpoint(DSCConstants.BZAPI_ACCOUNTS, user);
            
            logger.info(":::::::::: APIHandler :::::::::::::::"+ commodityList);
            
            JSONObject jsonObject = new JSONObject(commodityList);
            JSONArray jsonArray = jsonObject.getJSONArray("commodity_products");
            if(jsonArray != null) {
            for (int index = 0; index < jsonArray.length(); index++) {
                JSONObject accountJsonAttr = (JSONObject) jsonArray.get(index);
                if (accountJsonAttr != null) {
                    JSONObject jsonIdentifierObj = accountJsonAttr.getJSONObject("product");
                    if (jsonIdentifierObj != null) {
                    String product_code = (String) jsonIdentifierObj.get("product_code");
                    String product_name = (String) jsonIdentifierObj.get("product_name");
                    Commodity commodityObj = new Commodity();
                    commodityObj.setProductCode(product_code);
                    commodityObj.setProductName(product_name);
                    commodity.add(commodityObj);
                    }
                }
            }
            }
            }
            if (commodity != null && !commodity.isEmpty())
            {
                responseGateway = gateway.buildResponse(commodity, DSCConstants.SUCCESS, "", DSCConstants.CODE200, "");
            } else
            {
                responseGateway = gateway.buildResponse(commodity, DSCConstants.FAIL, DSCConstants.NORESULT, DSCConstants.CODE200, DSCConstants.F101);
            }
        } catch (Exception e)
        {
            logger.error(":::::::::: getCustomerList :::::::::::::::"+ e.getMessage());
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
        }
        return responseGateway;
    }
}
