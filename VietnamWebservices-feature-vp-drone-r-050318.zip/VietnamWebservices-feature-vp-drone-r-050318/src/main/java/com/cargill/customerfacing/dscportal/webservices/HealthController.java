/*
 * HealthController.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.webservices;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value = "/api/dxo/dsc/v1/auth")
public class HealthController
{
  
  /**
   * Health check method
   * 
   * @return
   */
  @RequestMapping("/health")
  public String healthcheck()
  {
    return "index.html";
  }
}
