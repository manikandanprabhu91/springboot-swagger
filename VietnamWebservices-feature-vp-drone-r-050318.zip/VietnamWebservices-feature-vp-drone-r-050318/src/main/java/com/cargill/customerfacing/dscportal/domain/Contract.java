/*
 * Contract.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.domain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel
public class Contract extends BaseModel
{
    @ApiModelProperty(value = "The application-specific cakNo")
    private String cakNo;
    private String cakDate;
    @ApiModelProperty(value = "The application-specific commodity")
    private String commodity;
    @ApiModelProperty(value = "The application-specific quantity")
    private int quantity;
    private int received;
    private int balanceStock;
    private int contractTypeId;
    @ApiModelProperty(value = "The application-specific contractType")
    private String contractType;
    private String customerId;
    private String contractStatus;
    private String statusId;
    private String contractCategory;
    private String basis;
    private int tendered;
    private String destination;
    private String finalWeightAt;
    private String cargoOrigin;
    private String currency;
    private String paymentTerms;
    private Integer contractPrice;
    private int unitPrice;
    private int tolarance;
    private String shipPeriod;
    private String packageType;
    private String storageTerms;
    private int contractId;
    private int erpContractStatus;
    private int days;
    private int shipmentCount;
    private String customerName;
    private String expirationDate;
    private int notificationCount;
    private int inTransitQuantity;
    private int result;
    private int maxCount;
    private int approvedQuantity;
    
    public int getResult()
    {
        return result;
    }
    public void setResult(int result)
    {
        this.result = result;
    }
    public int getMaxCount()
    {
        return maxCount;
    }
    public void setMaxCount(int maxCount)
    {
        this.maxCount = maxCount;
    }
    public int getContractId()
    {
        return contractId;
    }
    public void setContractId(int contractId)
    {
        this.contractId = contractId;
    }
    public String getCakNo()
    {
        return cakNo;
    }
    public void setCakNo(String cakNo)
    {
        this.cakNo = cakNo;
    }
    public String getCakDate()
    {
        return cakDate;
    }
    public void setCakDate(String cakDate)
    {
        this.cakDate = cakDate;
    }
    public String getCommodity()
    {
        return commodity;
    }
    public void setCommodity(String commodity)
    {
        this.commodity = commodity;
    }
    public int getQuantity()
    {
        return quantity;
    }
    public void setQuantity(int quantity)
    {
        this.quantity = quantity;
    }
    public int getReceived()
    {
        return received;
    }
    public void setReceived(int received)
    {
        this.received = received;
    }
    public int getBalanceStock()
    {
        return balanceStock;
    }
    public void setBalanceStock(int balanceStock)
    {
        this.balanceStock = balanceStock;
    }
    public String getContractType()
    {
        return contractType;
    }
    public void setContractType(String contractType)
    {
        this.contractType = contractType;
    }
    public String getCustomerId()
    {
        return customerId;
    }
    public void setCustomerId(String customerId)
    {
        this.customerId = customerId;
    }
    public String getContractStatus()
    {
        return contractStatus;
    }
    public void setContractStatus(String contractStatus)
    {
        this.contractStatus = contractStatus;
    }
    public int getContractTypeId()
    {
        return contractTypeId;
    }
    public void setContractTypeId(int contractTypeId)
    {
        this.contractTypeId = contractTypeId;
    }
    public String getStatusId()
    {
        return statusId;
    }
    public void setStatusId(String statusId)
    {
        this.statusId = statusId;
    }
    public String getContractCategory()
    {
        return contractCategory;
    }
    public void setContractCategory(String contractCategory)
    {
        this.contractCategory = contractCategory;
    }
    public String getBasis()
    {
        return basis;
    }
    public void setBasis(String basis)
    {
        this.basis = basis;
    }
    public int getTendered()
    {
        return tendered;
    }
    public void setTendered(int tendered)
    {
        this.tendered = tendered;
    }
    public String getDestination()
    {
        return destination;
    }
    public void setDestination(String destination)
    {
        this.destination = destination;
    }
    public String getCurrency()
    {
        return currency;
    }
    public void setCurrency(String currency)
    {
        this.currency = currency;
    }
    
    public String getPaymentTerms()
    {
        return paymentTerms;
    }
    public void setPaymentTerms(String paymentTerms)
    {
        this.paymentTerms = paymentTerms;
    }
    public int getTolarance()
    {
        return tolarance;
    }
    public void setTolarance(int tolarance)
    {
        this.tolarance = tolarance;
    }
    public String getShipPeriod()
    {
        return shipPeriod;
    }
    public void setShipPeriod(String shipPeriod)
    {
        this.shipPeriod = shipPeriod;
    }
    public String getFinalWeightAt()
    {
        return finalWeightAt;
    }
    public void setFinalWeightAt(String finalWeightAt)
    {
        this.finalWeightAt = finalWeightAt;
    }
    public String getCargoOrigin()
    {
        return cargoOrigin;
    }
    public void setCargoOrigin(String cargoOrigin)
    {
        this.cargoOrigin = cargoOrigin;
    }
    public Integer getContractPrice()
    {
        return contractPrice;
    }
    public void setContractPrice(Integer contractPrice)
    {
        this.contractPrice = contractPrice;
    }
    public int getUnitPrice()
    {
        return unitPrice;
    }
    public void setUnitPrice(int unitPrice)
    {
        this.unitPrice = unitPrice;
    }
    public String getStorageTerms()
    {
        return storageTerms;
    }
    public void setStorageTerms(String storageTerms)
    {
        this.storageTerms = storageTerms;
    }
    public int getDays()
    {
        return days;
    }
    public void setDays(int days)
    {
        this.days = days;
    }
    public int getShipmentCount()
    {
        return shipmentCount;
    }
    public void setShipmentCount(int shipmentCount)
    {
        this.shipmentCount = shipmentCount;
    }
    public String getCustomerName()
    {
        return customerName;
    }
    public void setCustomerName(String customerName)
    {
        this.customerName = customerName;
    }
    public String getExpirationDate()
    {
        return expirationDate;
    }
    public void setExpirationDate(String expirationDate)
    {
        this.expirationDate = expirationDate;
    }
    public int getNotificationCount()
    {
        return notificationCount;
    }
    public void setNotificationCount(int notificationCount)
    {
        this.notificationCount = notificationCount;
    }
    public int getApprovedQuantity()
    {
        return approvedQuantity;
    }
    public void setApprovedQuantity(int approvedQuantity)
    {
        this.approvedQuantity = approvedQuantity;
    }
    public String getPackageType()
    {
        return packageType;
    }
    public void setPackageType(String packageType)
    {
        this.packageType = packageType;
    }
    public int getErpContractStatus()
    {
        return erpContractStatus;
    }
    public void setErpContractStatus(int erpContractStatus)
    {
        this.erpContractStatus = erpContractStatus;
    }
    public int getInTransitQuantity()
    {
        return inTransitQuantity;
    }
    public void setInTransitQuantity(int inTransitQuantity)
    {
        this.inTransitQuantity = inTransitQuantity;
    }
    
}
