/*
 * PaymentController.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.webservices;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.List;

import javax.imageio.ImageIO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cargill.customerfacing.dscportal.domain.ApprovedQuantity;
import com.cargill.customerfacing.dscportal.domain.DSCConstants;
import com.cargill.customerfacing.dscportal.domain.Payment;
import com.cargill.customerfacing.dscportal.domain.ResponseGateway;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.region.factory.RegionFactoryService;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.LuminanceSource;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.Result;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;

@RestController
@EnableAutoConfiguration
@RequestMapping(value = "/api/dxo/dsc/v1/auth")
public class PaymentController
{
    
    private Logger logger = LoggerFactory.getLogger(PaymentController.class);
    
    @Autowired
    RegionFactoryService regionFactoryService;
    
    private ResponseGateway gateway;
    
//    @Autowired
//    private AmazonS3Wrapper amazonClient;
    
    /**
     * Method to get payment list
     * 
     * @param contractId
     * @param contractCategory
     * @param userid
     * @return
     */
    @RequestMapping(value = "/paymentList", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ResponseGateway> getPaymentList(
                        @RequestParam("contractId")
                        int contractId , @RequestParam("contractCategory")
                        String contractCategory , @RequestParam("userid")
                        String userid) throws BaseClassException
    {
        logger.info(":::::::::: getPaymentList :::::::::::::::");
        gateway = new ResponseGateway();
        List<Payment> payments = null;
        ResponseEntity<ResponseGateway> responseGateway = null;
        try
        {
            payments = regionFactoryService.getPaymentService(contractCategory)
                                .getPaymentList(contractId, userid);
            if (payments != null && !payments.isEmpty())
            {
                responseGateway = gateway.buildResponse(payments,
                                    DSCConstants.SUCCESS, "",
                                    DSCConstants.CODE200, "");
            } else
            {
                responseGateway = gateway.buildResponse(payments,
                                    DSCConstants.FAIL, DSCConstants.NORESULT,
                                    DSCConstants.CODE200, DSCConstants.F101);
            }
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR,
                                DSCConstants.SERVERERROR, DSCConstants.CODE500,
                                DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to insert payment details
     * 
     * @param payment
     * @param contractCategory
     * @param userid
     * @return
     */
    @RequestMapping(value = "/payment", method = RequestMethod.POST, produces = DSCConstants.APPLICATION_JSON, consumes = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> insertPayment(@RequestBody
    Payment payment , @RequestParam("contractCategory")
    String contractCategory , @RequestParam("userid")
    String userid)
    {
        logger.info(":::::::::: insertPayment :::::::::::::::");
        Payment paymentstatus = null;
        gateway = new ResponseGateway();
        ResponseEntity<ResponseGateway> responseGateway = null;
        try
        {
            paymentstatus = regionFactoryService
                                .getPaymentService(contractCategory)
                                .insertPayment(payment, userid);
            if (paymentstatus.getResult() > 0)
            {
                responseGateway = gateway.buildResponse(null,
                                    DSCConstants.SUCCESS,
                                    DSCConstants.SUCCESS_SAVE,
                                    DSCConstants.CODE200,
                                    String.valueOf(paymentstatus.getNextval()));
            } else
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.FAIL,
                                    DSCConstants.NOTUPDATED,
                                    DSCConstants.CODE200, DSCConstants.F102);
            }
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR,
                                DSCConstants.SERVERERROR, DSCConstants.CODE500,
                                DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to update payment details
     * 
     * @param payment
     * @param contractId
     * @param flag
     * @param status
     * @param contractCategory
     * @param paymentID
     * @param userid
     * @return
     */
    @RequestMapping(value = "/updatePayment", method = RequestMethod.PATCH, produces = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> updatePayment(@RequestBody
    Payment payment , @RequestParam("contractCategory")
    String contractCategory , @RequestParam("userid")
    String userid)
    {
        logger.info(":::::::::: updatePayment :::::::::::::::");
        int updatestatus = 0;
        gateway = new ResponseGateway();
        ResponseEntity<ResponseGateway> responseGateway = null;
        try
        {
            updatestatus = regionFactoryService
                                .getPaymentService(contractCategory)
                                .updatePayment(payment, userid,contractCategory);
            if (updatestatus > 0)
            {
                responseGateway = gateway.buildResponse(null,
                                    DSCConstants.SUCCESS,
                                    DSCConstants.SUCCESS_UPDATE,
                                    DSCConstants.CODE200,
                                    String.valueOf(payment.getPaymentId()));
            } else
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.FAIL,
                                    DSCConstants.NOTUPDATED,
                                    DSCConstants.CODE200, DSCConstants.F102);
            }
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR,
                                DSCConstants.SERVERERROR, DSCConstants.CODE500,
                                DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to delete payment details
     * 
     * @param contractId
     * @param contractCategory
     * @param paymentID
     * @param userid
     * @return
     * @throws BaseClassException
     */
    @RequestMapping(value = "/payment", method = RequestMethod.DELETE, produces = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> deletePayment(
                        @RequestParam("contractId")
                        int contractId , @RequestParam("contractCategory")
                        String contractCategory , @RequestParam("paymentId")
                        int paymentID , @RequestParam("userid")
                        String userid) throws BaseClassException
    {
        logger.info(":::::::::: deletePayment :::::::::::::::");
        int deletestatus = 0;
        gateway = new ResponseGateway();
        ResponseEntity<ResponseGateway> responseGateway = null;
        try
        {
            deletestatus = regionFactoryService
                                .getPaymentService(contractCategory)
                                .deletePayment(contractId, paymentID, userid);
            if (deletestatus > 0)
            {
                responseGateway = gateway.buildResponse(null,
                                    DSCConstants.SUCCESS,
                                    DSCConstants.SUCCESS_DELETE,
                                    DSCConstants.CODE200,
                                    String.valueOf(contractId));
            } else
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.FAIL,
                                    DSCConstants.NOTUPDATED,
                                    DSCConstants.CODE200, DSCConstants.F102);
            }
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR,
                                DSCConstants.SERVERERROR, DSCConstants.CODE500,
                                DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Insert record in approved qty table for given contractid
     * 
     * @param approvedQuantity
     * @param contractCategory
     * @param userid
     */
    @RequestMapping(value = "/updateApprovedQuantity", method = RequestMethod.POST, produces = DSCConstants.APPLICATION_JSON, consumes = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> updateApprovedQuantity(@RequestBody
    ApprovedQuantity approvedQuantity , @RequestParam("contractCategory")
    String contractCategory , @RequestParam("userid")
    String userid)
    {
        logger.info(":::::::::: updateApprovedQuantity :::::::::::::::");
        ApprovedQuantity insertstatus = null;
        gateway = new ResponseGateway();
        ResponseEntity<ResponseGateway> responseGateway = null;
        try
        {
            insertstatus = regionFactoryService
                                .getPaymentService(contractCategory)
                                .updateApprovedQuantity(approvedQuantity,
                                                    userid, contractCategory);
            if (insertstatus.getResult() > 0)
            {
                responseGateway = gateway.buildResponse(null,
                                    DSCConstants.SUCCESS,
                                    DSCConstants.SUCCESS_SAVE,
                                    DSCConstants.CODE200,
                                    String.valueOf(insertstatus
                                                        .getTotalContractQTY()));
            } else if (insertstatus.getResult() < 0)
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.FAIL,
                                    DSCConstants.APPROVEDQTY_ERROR,
                                    DSCConstants.CODE200, DSCConstants.F202);
            } else
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.FAIL,
                                    DSCConstants.NOTUPDATED,
                                    DSCConstants.CODE200, DSCConstants.F102);
            }
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR,
                                DSCConstants.SERVERERROR, DSCConstants.CODE500,
                                DSCConstants.E100);
        }
        return responseGateway;
    }
    
//    @RequestMapping(value="/upload", method=RequestMethod.POST)
//    public @ResponseBody String uploadPayment(@RequestParam("file") MultipartFile file) {
//      return amazonClient.uploadFile(file);
//    }

@RequestMapping(value = "/qrCodeReader", method = RequestMethod.POST, consumes = "multipart/form-data")
    public ResponseEntity<String> getQRCodeImage(@RequestPart("file") MultipartFile file)
    {
        String message = "";
        try
        {
            BufferedImage bufferedImg = ImageIO.read(file.getInputStream());
            LuminanceSource source = new BufferedImageLuminanceSource(
                                bufferedImg);
            BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));
            
            Result result = new MultiFormatReader().decode(bitmap);
            
            System.out.println("Barcode Format: " + result.getBarcodeFormat());
            System.out.println("Content: " + result.getText());
            message = "BarcodeFormat" + result.getBarcodeFormat() + "End"
                                + "Text " + result.getText() + "TextEnd";
            return ResponseEntity.status(HttpStatus.OK).body(message);
        } catch (Exception e)
        {
            message = "FAIL to upload " + file.getName() + "!";
            return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
                                .body(message);
        }
    }
    
}
