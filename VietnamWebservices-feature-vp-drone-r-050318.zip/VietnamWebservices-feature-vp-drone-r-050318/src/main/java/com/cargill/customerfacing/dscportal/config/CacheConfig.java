/*
 * CacheConfig.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.config;

import com.google.common.cache.CacheBuilder;
import org.springframework.cache.Cache;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.guava.GuavaCache;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.TimeUnit;

@Configuration
@EnableCaching
public class CacheConfig
{
    public static final String CACHE_ONE = "cacheOne";
    public static final String CACHE_TWO = "cacheTwo";
    public static final String CACHE_THREE = "cacheThree";
    public static final String CACHE_FOUR = "cacheFour";
    public static final String CACHE_FIVE = "cacheFive";
    public static final String CACHE_SIX = "cacheSix";
    public static final String CACHE_SEVEN = "cacheSeven";
    public static final String CACHE_EIGHT = "cacheEight";
    public static final String CACHE_NINE = "cacheNine";
    public static final String CACHE_TEN = "cacheTEN";
    public static final String CACHE_STATIC = "cache-static";
    public static final String CACHE_STATIC_CROPS = "cache-static-crops";
    
    @Bean
    public Cache cacheOne()
    {
        return new GuavaCache(CACHE_ONE, CacheBuilder.newBuilder()
                            .expireAfterWrite(10, TimeUnit.MINUTES).build());
    }
    
    @Bean
    public Cache cacheTwo()
    {
        return new GuavaCache(CACHE_TWO, CacheBuilder.newBuilder()
                            .expireAfterWrite(60, TimeUnit.SECONDS).build());
    }
    
    @Bean
    public Cache cacheThree()
    {
        return new GuavaCache(CACHE_THREE, CacheBuilder.newBuilder()
                            .expireAfterWrite(60, TimeUnit.SECONDS).build());
    }
    
    @Bean
    public Cache cacheFour()
    {
        return new GuavaCache(CACHE_FOUR, CacheBuilder.newBuilder()
                            .expireAfterWrite(60, TimeUnit.SECONDS).build());
    }
    
    @Bean
    public Cache cacheFive()
    {
        return new GuavaCache(CACHE_FIVE, CacheBuilder.newBuilder()
                            .expireAfterWrite(60, TimeUnit.SECONDS).build());
    }
    
    @Bean
    public Cache cacheSix()
    {
        return new GuavaCache(CACHE_SIX, CacheBuilder.newBuilder()
                            .expireAfterWrite(60, TimeUnit.SECONDS).build());
    }
    
    @Bean
    public Cache cacheSeven()
    {
        return new GuavaCache(CACHE_SEVEN, CacheBuilder.newBuilder()
                            .expireAfterWrite(60, TimeUnit.SECONDS).build());
    }
    
    @Bean
    public Cache cacheEight()
    {
        return new GuavaCache(CACHE_EIGHT, CacheBuilder.newBuilder()
                            .expireAfterWrite(60, TimeUnit.SECONDS).build());
    }
    
    @Bean
    public Cache cacheNine()
    {
        return new GuavaCache(CACHE_NINE, CacheBuilder.newBuilder()
                            .expireAfterWrite(60, TimeUnit.SECONDS).build());
    }
    
    @Bean
    public Cache cacheTen()
    {
        return new GuavaCache(CACHE_TEN, CacheBuilder.newBuilder()
                            .expireAfterWrite(60, TimeUnit.SECONDS).build());
    }
    
    @Bean
    public Cache cacheStatic()
    {
        return new GuavaCache(CACHE_STATIC, CacheBuilder.newBuilder()
                            .expireAfterWrite(60, TimeUnit.HOURS).build());
    }
    
    @Bean
    public Cache cacheStaticCrops()
    {
        return new GuavaCache(CACHE_STATIC_CROPS, CacheBuilder.newBuilder()
                            .expireAfterWrite(60, TimeUnit.HOURS).build());
    }
    
}