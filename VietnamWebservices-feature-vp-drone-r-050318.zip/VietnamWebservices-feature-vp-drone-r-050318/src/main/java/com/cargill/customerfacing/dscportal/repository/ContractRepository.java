/*
 * ContractRepository.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */

package com.cargill.customerfacing.dscportal.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;

import com.cargill.customerfacing.dscportal.domain.Contract;
import com.cargill.customerfacing.dscportal.domain.Customer;
import com.cargill.customerfacing.dscportal.domain.DSCConstants;
import com.cargill.customerfacing.dscportal.domain.Payment;
import com.cargill.customerfacing.dscportal.domain.Status;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;

@Repository
public class ContractRepository
{
    
    private static Logger logger = LoggerFactory
                        .getLogger(ContractRepository.class);
    
    @Autowired
    JdbcTemplate jdbcTemplate;
    
    /**
     * This method is used to get contract by Id
     * 
     * @param cakNo
     * @param contractCategory
     * @return
     * @throws BaseClassException
     */
    public List<Contract> getContract(int contractId , String contractCategory ,
                        String userid) throws BaseClassException
    {
        logger.info(":::::::::::::::::::::: getContract repository ::::::::::::::::::::::::");
        List<Contract> contract = null;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            logger.info(":::::::::::::::::::::: contractBYID inside ::::::::::::::::::::::::");
            contract = jdbcTemplate.query(
                                DSCConstants.CONTRACTQUERY_BYID, new Object[]
                                { contractId, contractCategory,  userid },
                                new BeanPropertyRowMapper<Contract>(
                                                    Contract.class));
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage());
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return contract;
    }
    
    /**
     * This method is used to get status list
     * 
     * @param screen
     * @return
     * @throws Exception
     */
    public List<Status> getStatusList(String screen) throws BaseClassException
    {
        logger.info(":::::::::::::::::::::: getStatusList repository ::::::::::::::::::::::::");
        List<Status> status = null;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            status = jdbcTemplate.query(DSCConstants.STATUS_LIST, new Object[]
            { screen }, new BeanPropertyRowMapper<Status>(Status.class));
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return status;
    }
    
    /**
     * This method is used to insert record in contract and payment tables
     * 
     * @param contract
     * @param userid
     * @return
     * @throws BaseClassException
     */
    @SuppressWarnings(
    { "unchecked" })
    public Contract insertContract(Contract contract , String  userid ,
                        String contractCategory) throws BaseClassException
    {
        //Contract resultset = null;
        Date today = new java.util.Date();
        long t = today.getTime();
        int contracttypeId = 1;
        String statuscode = "";
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        int nextval = 0;
        int pynextval = 0;
        int insertStatus = 0;
        logger.info(":::::::::::::::::::::: insertContract repository ::::::::::::::::::::::::");
        try
        {
            int count = jdbcTemplate.queryForObject(DSCConstants.CAKNO_CHK,
                                new Object[]
                                { contract.getCakNo(),
                                                contract.getContractTypeId(),
                                                contractCategory },
                                Integer.class);
            if (count == 0)
            {
                nextval = jdbcTemplate.queryForObject(
                                    DSCConstants.CONTRACT_NEXTVAL, new Object[]
                                    {}, Integer.class);
                if (contracttypeId == contract.getContractTypeId())
                {
                    logger.info(":::::::::::::::::::::: insertContract into db repository ::::::::::::::::::::::::");
                    insertStatus = jdbcTemplate.update(
                                        DSCConstants.CONTRACT_INSERT_QUERY,
                                        new Object[]
                                        { nextval, contract.getCakNo(),
                                                        contract.getCakDate(),
                                                        contract.getCommodity(),
                                                        contract.getQuantity(),
                                                        contracttypeId,
                                                        contract.getCustomerId(),
                                                        "USGN", userid,
                                                        new java.sql.Date(t),
                                                        userid,
                                                        new java.sql.Date(t),
                                                        "Y", contractCategory,
                                                        contract.getTendered(),
                                                        contract.getBasis(),
                                                        contract.getStorageTerms(),
                                                        contract.getTolarance(),
                                                        contract.getUnitPrice(),
                                                        contract.getPackageType(),
                                                        contract.getShipPeriod(),
                                                        contract.getContractPrice(),
                                                        contract.getDestination(),
                                                        contract.getFinalWeightAt(),
                                                        contract.getCargoOrigin(),
                                                        contract.getCurrency(),
                                                        contract.getPaymentTerms(),
                                                        contract.getReceived(),
                                                        contract.getBalanceStock(),
                                                        contract.getErpContractStatus(),
                                                        (!contract.getExpirationDate().isEmpty() ?  contract.getExpirationDate() : contract.getCakDate() ),
                                                        contract.getInTransitQuantity(),contract.getCustomerName()});
                                        
                    contract.setMaxCount(nextval);
                }
                
                if (insertStatus > 0)
                {
                    logger.info(":::::::::::::::::::::: pay status in insert repository ::::::::::::::::::::::::");
                    Payment paystatus = jdbcTemplate.queryForObject(
                                        DSCConstants.GET_PAYMENT_STATUSTYPE,
                                        new BeanPropertyRowMapper<Payment>(
                                                            Payment.class),
                                        new Object[]
                                        { DSCConstants.NOT_PAID});
                    if (paystatus != null)
                    {
                        statuscode = paystatus.getStatusCode();
                        
                        pynextval = jdbcTemplate.queryForObject(
                                            DSCConstants.PAYMENT_NEXTVAL, new Object[]
                                            {}, Integer.class);
                        
                        contract.setResult(jdbcTemplate.update(
                                            DSCConstants.PAYMENT_INSERT_QUERY,
                                            new Object[]
                                            { pynextval,statuscode, new java.sql.Date(t),
                                                            ((contract.getUnitPrice())
                                                                                * (contract.getQuantity())),
                                                             "",  userid,
                                                            new java.sql.Date(t),
                                                            userid,
                                                            new java.sql.Date(t),
                                                            "Y",
                                                            contract.getMaxCount(),"","","","00:00" }));
                    }
                }
            } else
            {
                contract.setResult(-1);
            }
            
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return contract;
    }
    
    /**
     * This method is used to get contract list
     * 
     * @param contractCategory
     * @param contractType
     * @param contractStatus
     * @return
     */
    public List<Contract> getContractlist(String contractType ,
                        String contractStatus , String contractCategory ,
                        String userid , String searchCriteria , int startindex ,
                        int limit) throws BaseClassException
    {
        List<Contract> contractlist = null;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        int index = 0;
        logger.info(":::::::::::::::::::::: getContractlist repository ::::::::::::::::::::::::");
            StringBuilder query = new StringBuilder();
            
            query.append(DSCConstants.CONTRACT_SELECT_ALL);
            
            if (!contractStatus.equalsIgnoreCase("all") && !contractStatus.isEmpty())
            {
                query.append(DSCConstants.CONTRACT_STATUS);
            }
            
            if (!contractType.equalsIgnoreCase("all") &&  !contractType.isEmpty()) {
                query.append(DSCConstants.CONTRACT_TYPE);
            }
            
            if (!searchCriteria.isEmpty()) {
                query.append(DSCConstants.SEARCH_CRITERI_CONTRACT);
            }
            
            
            
            query.append(DSCConstants.CONTRACT_GROUPBY);
            
            if(limit > 0) {
                query.append(DSCConstants.QUERY_LIMIT_APPEND); 
            }
            try
            {
            PreparedStatementSetter pss = new PreparedStatementSetter() {
                public void setValues(PreparedStatement preparedStatement) throws SQLException {
                    int i = 0;
                    i++;
                    preparedStatement.setString(i, userid);
                    i++;
                    preparedStatement.setString(i, userid);
                    i++;
                    preparedStatement.setString(i, contractCategory);
                    if (!contractStatus.equalsIgnoreCase("all") && !contractStatus.isEmpty())
                    { 
                        i++;
                        preparedStatement.setString(i, contractStatus);
                    }
                    
                    if (!contractType.equalsIgnoreCase("all") && !contractType.isEmpty())
                    {
                        i++;
                        preparedStatement.setString(i, contractType);
                    }
                    
                    if (!searchCriteria.isEmpty())
                    {
                        i++;
                        preparedStatement.setString(i, searchCriteria.toUpperCase().concat("%"));
                        i++;
                        preparedStatement.setString(i, searchCriteria.toUpperCase().concat("%"));
                    }
                    
                    if(limit > 0)
                    {
                        int offset = (startindex == 0) ? 0 : startindex - 1;
                        i++;
                        preparedStatement.setInt(i, limit);
                        i++;
                        preparedStatement.setInt(i, offset);
                    }
                  
                }
              };
                    
                    contractlist = jdbcTemplate.query(query.toString(), pss,
                                        new BeanPropertyRowMapper<Contract>(
                                                            Contract.class));
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return contractlist;
    }
    
    /**
     * 
     * @param contractType
     * @param contractStatus
     * @param contractCategory
     * @param userid
     * @param searchCriteria
     * @return
     * @throws BaseClassException
     */
    public int getContractTotal(String contractType ,
                        String contractStatus , String contractCategory ,
                        String userid , String searchCriteria ) throws BaseClassException
    {
        List<Contract> contractlist = null;
        int count = 0;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        logger.info(":::::::::::::::::::::: getContractTotal repository ::::::::::::::::::::::::");
            StringBuilder query = new StringBuilder();
            
            query.append(DSCConstants.CONTRACT_SELECT_COUNT);
            query.append(DSCConstants.CONTRACT_SELECT_ALL);
            
            if (!contractStatus.equalsIgnoreCase("all") && !contractStatus.isEmpty())
            {
                query.append(DSCConstants.CONTRACT_STATUS);
            }
            
            if (!contractType.equalsIgnoreCase("all") &&  !contractType.isEmpty()) {
                query.append(DSCConstants.CONTRACT_TYPE);
            }
            
            if (!searchCriteria.isEmpty()) {
                query.append(DSCConstants.SEARCH_CRITERI_CONTRACT);
            }
            
            query.append(DSCConstants.CONTRACT_GROUPBY);
            query.append(DSCConstants.CONTRACT_END_COUNT);
            try
            {
            PreparedStatementSetter pss = new PreparedStatementSetter() {
                public void setValues(PreparedStatement preparedStatement) throws SQLException {
                    int i = 0;
                    i++;
                    preparedStatement.setString(i, userid);
                    i++;
                    preparedStatement.setString(i, userid);
                    i++;
                    preparedStatement.setString(i, contractCategory);
                    if (!contractStatus.equalsIgnoreCase("all") && !contractStatus.isEmpty())
                    { 
                        i++;
                        preparedStatement.setString(i, contractStatus);
                    }
                    
                    if (!contractType.equalsIgnoreCase("all") && !contractType.isEmpty())
                    {
                        i++;
                        preparedStatement.setString(i, contractType);
                    }
                    
                    if (!searchCriteria.isEmpty())
                    {
                        i++;
                        preparedStatement.setString(i, searchCriteria.toUpperCase().concat("%"));
                        i++;
                        preparedStatement.setString(i, searchCriteria.toUpperCase().concat("%"));
                    }
                }
              };
                    
              contractlist = jdbcTemplate.query(query.toString(), pss,
                                        new BeanPropertyRowMapper<Contract>(
                                                            Contract.class));
              for(Contract c:contractlist)
              count =  c.getMaxCount();
            
              
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return count;
    }
    
    
    /**
     * This method is used to update contract and payment table details
     * 
     * @param contract
     * @param cakNo
     */
    public int updateContract(Contract contract , int contractId ,
                        String userid) throws BaseClassException
    {
        Date today = new java.util.Date();
        long t = today.getTime();
        int contractTotalAmt = 0;
        double paymentTotalAmt = 0;
        String statuscode = "";
        double amttoupdate = 0;
        int rsult = 0;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        logger.info(":::::::::::::::::::::: updateContract ::::::::::::::::::::::::");
        int updateStatus = 0;
        try
        {
            updateStatus = jdbcTemplate.update(
                                DSCConstants.CONTRACT_UPDATE_QUERY, new Object[]
                                { contract.getCommodity(),
                                                contract.getQuantity(),
                                                contract.getReceived(),
                                                contract.getBalanceStock(),
                                                contract.getContractTypeId(),
                                                contract.getStatusId(),
                                                contract.getTendered(),
                                                contract.getBasis(), userid,
                                                new java.sql.Date(t),
                                                contract.getStorageTerms(),
                                                contract.getTolarance(),
                                                contract.getUnitPrice(),
                                                contract.getPackageType(),
                                                contract.getShipPeriod(),
                                                contract.getContractPrice(),
                                                contract.getDestination(),
                                                contract.getFinalWeightAt(),
                                                contract.getCargoOrigin(),
                                                contract.getCurrency(),
                                                contract.getPaymentTerms(),
                                                contract.getErpContractStatus(),
                                                contract.getExpirationDate(),
                                                contract.getInTransitQuantity(),contract.getCustomerName(),
                                                contractId,
                                                contract.getCustomerId(),
                                                contract.getContractCategory(),
                                                userid});
            if (updateStatus > 0)
            {
                List<Contract> totalamt = jdbcTemplate.query(
                                    DSCConstants.CONTRACT_TOTAL_AMT,
                                    new BeanPropertyRowMapper<Contract>(
                                                        Contract.class),
                                    new Object[]
                                    { contractId });
                logger.info(":::::::::::::::::::::: get contracttypeid value repository ::::::::::::::::::::::::");
                for (Contract type : totalamt)
                {
                    contractTotalAmt = (type.getQuantity()
                                        * type.getUnitPrice());
                }
                
                Payment paytotalamt = jdbcTemplate.queryForObject(
                                    DSCConstants.PAYMENT_TOTAL_AMT,
                                    new BeanPropertyRowMapper<Payment>(
                                                        Payment.class),
                                    new Object[]
                                    { contractId });
                logger.info(":::::::::::::::::::::: get contracttypeid value repository ::::::::::::::::::::::::");
                if (paytotalamt != null)
                {
                    paymentTotalAmt = paytotalamt.getPaymentAmount();
                }
                
                Payment paystatus = jdbcTemplate.queryForObject(
                                    DSCConstants.GET_PAYMENT_STATUSTYPE,
                                    new BeanPropertyRowMapper<Payment>(
                                                        Payment.class),
                                    new Object[]
                                    {DSCConstants.NOT_PAID });
                if (paystatus != null)
                {
                    statuscode = paystatus.getStatusCode();
                }
                
                if (contractTotalAmt < paymentTotalAmt)
                {
                    amttoupdate = paymentTotalAmt - ((paymentTotalAmt)
                                        - (contractTotalAmt));
                    rsult = jdbcTemplate.update(DSCConstants.CONTRACT_DIFF,
                                        new Object[]
                                        { amttoupdate,  userid,
                                                        new java.sql.Date(t),
                                                        statuscode,
                                                        contractId });
                } else if (contractTotalAmt > paymentTotalAmt)
                {
                    amttoupdate = paymentTotalAmt + ((contractTotalAmt)
                                        - (paymentTotalAmt));
                    rsult = jdbcTemplate.update(DSCConstants.CONTRACT_DIFF,
                                        new Object[]
                                        { amttoupdate,  userid,
                                                        new java.sql.Date(t),
                                                        statuscode,
                                                        contractId });
                }else {
                    if(contractTotalAmt == paymentTotalAmt)  {
                        rsult =1;
                    }
                }
            }
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return rsult;
    }
    
    /**
     * This method is used to delete particular contract
     * 
     * @param contractId
     * @param userid
     */
    public int deleteContract(int contractId , String userid)
                        throws BaseClassException
    {
        Date today = new java.util.Date();
        long t = today.getTime();
        int rsult = 0;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            rsult = jdbcTemplate.update(DSCConstants.CONTRACT_DELETE_QUERY,
                                new Object[]
                                { new java.sql.Date(t), contractId, userid });
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return rsult;
    }
    
    /**
     * This method is used to get customer list
     * 
     * @param contractCategory
     * @return
     * @throws Exception
     */
    public List<Customer> getCustomerList(String contractCategory)
                        throws BaseClassException
    {
        logger.info(":::::::::::::::::::::: getCustomerList repository ::::::::::::::::::::::::");
        List<Customer> customers = null;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            customers = jdbcTemplate.query(DSCConstants.CUSTOMER_LIST,
                                new Object[]
                                { contractCategory },
                                new BeanPropertyRowMapper<Customer>(
                                                    Customer.class));
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return customers;
    }
}
