/*
 * MarketInformationController.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.webservices;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cargill.customerfacing.dscportal.domain.DSCConstants;
import com.cargill.customerfacing.dscportal.domain.MarketInformation;
import com.cargill.customerfacing.dscportal.domain.ResponseGateway;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.region.factory.RegionFactoryService;

@RestController
@EnableAutoConfiguration
@RequestMapping(value = "/api/dxo/dsc/v1/auth")
public class MarketInformationController
{
    
    private Logger logger = LoggerFactory.getLogger(MarketInformationController.class);
    
    @Autowired
    RegionFactoryService regionFactoryService;
    
    private ResponseGateway gateway;
    
    /**
     * Method to get market info list
     * 
     * @param marketId
     * @param contractCategory
     * @param userid
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/marketInfoList", method = RequestMethod.GET, produces = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> getMarketInfoList(
                        @RequestParam("contractCategory")
                        String contractCategory , @RequestParam("userid")
                        String userid) throws BaseClassException
    {
        logger.info(":::::::::: getMarketInfoList :::::::::::::::");
        gateway = new ResponseGateway();
        List<MarketInformation> marketInformations = null;
        ResponseEntity<ResponseGateway> responseGateway = null;
        try
        {
            marketInformations = regionFactoryService
                                .getMarketInfoService(contractCategory)
                                .getMarketInfoList(contractCategory);
            if (marketInformations != null && !marketInformations.isEmpty())
            {
                responseGateway = gateway.buildResponse(marketInformations, DSCConstants.SUCCESS, "", DSCConstants.CODE200, "");
            } else
            {
                responseGateway = gateway.buildResponse(marketInformations, DSCConstants.FAIL, DSCConstants.NORESULT, DSCConstants.CODE200, DSCConstants.F101);
            }
        } catch (Exception e)
        {
           responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to insert market info details
     * 
     * @param marketInformation
     * @param contractCategory
     * @param userid
     * @return
     */
    @RequestMapping(value = "/marketInformation", method = RequestMethod.POST, produces = DSCConstants.APPLICATION_JSON, consumes = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> insertMarketInformation(@RequestBody
    MarketInformation marketInformation , @RequestParam("contractCategory")
    String contractCategory , @RequestParam("userid")
    String userid) throws BaseClassException
    {
        logger.info(":::::::::: insertMarketInformation :::::::::::::::");
        gateway = new ResponseGateway();
        ResponseEntity<ResponseGateway> responseGateway = null;
        MarketInformation insertstaus = null;
        try
        {
            insertstaus = regionFactoryService
                                .getMarketInfoService(contractCategory)
                                .insertMarketInformation(marketInformation,
                                                    userid, contractCategory);
            if (insertstaus.getResult() > 0)
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.SUCCESS, DSCConstants.SUCCESS_SAVE, DSCConstants.CODE200, String.valueOf(insertstaus.getNextval()));
            } else
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.NOTUPDATED, DSCConstants.CODE200, DSCConstants.F102); 
            }
        } catch (Exception e)
        {
           responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to update market info details
     * 
     * @param cakNo
     * @param contract
     * @param contractCategory
     */
    @RequestMapping(value = "/updateMarketInformation", method = RequestMethod.PATCH, produces = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> updateMarketInformation(@RequestBody
                        MarketInformation marketInformation ,
                        @RequestParam("contractCategory")
                        String contractCategory , @RequestParam("userid")
                        String userid) throws BaseClassException
    {
        logger.info(":::::::::: updateMarketInformation :::::::::::::::");
        gateway = new ResponseGateway();
        ResponseEntity<ResponseGateway> responseGateway = null;
        int updatestatus = 0;
        try
        {
            updatestatus = regionFactoryService
                                .getMarketInfoService(contractCategory)
                                .updateMarketInformation(marketInformation,
                                                     userid,
                                                    contractCategory);
            if (updatestatus > 0)
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.SUCCESS, DSCConstants.SUCCESS_UPDATE, DSCConstants.CODE200, String.valueOf(marketInformation.getMarketId()));
            } else
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.NOTUPDATED, DSCConstants.CODE200, DSCConstants.F102); 
            }
        } catch (Exception e)
        {
           responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to delete market info details
     * 
     * @param marketId
     * @param contractCategory
     * @param userid
     * @return
     * @throws BaseClassException
     */
    @RequestMapping(value = "/marketInformation", method = RequestMethod.DELETE, produces = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> deleteMarketInformation(
                        @RequestParam("marketId")
                        int marketId , @RequestParam("contractCategory")
                        String contractCategory , @RequestParam("userid")
                        String userid) throws BaseClassException
    {
        logger.info(":::::::::: deleteMarketInformation :::::::::::::::");
        ResponseEntity<ResponseGateway> responseGateway = null;
        gateway = new ResponseGateway();
        int deletestatus = 0;
        try
        {
            deletestatus = regionFactoryService
                                .getMarketInfoService(contractCategory)
                                .deleteMarketInformation(marketId, userid);
            if (deletestatus > 0)
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.SUCCESS, DSCConstants.SUCCESS_UPDATE, DSCConstants.CODE200, String.valueOf(marketId));
            } else
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.NOTUPDATED, DSCConstants.CODE200, DSCConstants.F102); 
            }
        } catch (Exception e)
        {
           responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
        }
        return responseGateway;
    }
    
}
