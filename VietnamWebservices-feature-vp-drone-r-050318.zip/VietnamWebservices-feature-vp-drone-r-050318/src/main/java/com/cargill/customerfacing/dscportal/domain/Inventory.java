/*
 * Inventory.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.domain;

public class Inventory extends BaseModel
{
    private String cargo;
    private String vehicleType;
    private String vehicleNo;
    private String timeInDate;
    private double weightIn;
    private String timeOutDate;
    private double weightOut;
    private String packing;
    private String mode;
    private String location;
    private int pickUpId;
    private String contractType;
    private String remarks;
    private int contractId;
    private int netWeight;
    private double totalWeight;
    private String cakNo;
    private String etaDate;
    private int inventoryId;
    private int result;
    private int nextval;
    private float deliveredVolume;
    private String timeInTime;
    private String timeOutTime;
    private String etaTime;
    private String customerName;
    
    
    public String getCargo()
    {
        return cargo;
    }
    public void setCargo(String cargo)
    {
        this.cargo = cargo;
    }
    public String getVehicleType()
    {
        return vehicleType;
    }
    public void setVehicleType(String vehicleType)
    {
        this.vehicleType = vehicleType;
    }
    public String getVehicleNo()
    {
        return vehicleNo;
    }
    public void setVehicleNo(String vehicleNo)
    {
        this.vehicleNo = vehicleNo;
    }
    public double getWeightIn()
    {
        return weightIn;
    }
    public void setWeightIn(double weightIn)
    {
        this.weightIn = weightIn;
    }
    public double getWeightOut()
    {
        return weightOut;
    }
    public void setWeightOut(double weightOut)
    {
        this.weightOut = weightOut;
    }
    public String getPacking()
    {
        return packing;
    }
    public void setPacking(String packing)
    {
        this.packing = packing;
    }
    public String getMode()
    {
        return mode;
    }
    public void setMode(String mode)
    {
        this.mode = mode;
    }
    public String getLocation()
    {
        return location;
    }
    public void setLocation(String location)
    {
        this.location = location;
    }
    public int getPickUpId()
    {
        return pickUpId;
    }
    public double getTotalWeight()
    {
        return totalWeight;
    }
    public void setTotalWeight(double totalWeight)
    {
        this.totalWeight = totalWeight;
    }
    public void setPickUpId(int pickUpId)
    {
        this.pickUpId = pickUpId;
    }
    public String getContractType()
    {
        return contractType;
    }
    public void setContractType(String contractType)
    {
        this.contractType = contractType;
    }
    public String getRemarks()
    {
        return remarks;
    }
    public void setRemarks(String remarks)
    {
        this.remarks = remarks;
    }
    public int getContractId()
    {
        return contractId;
    }
    public void setContractId(int contractId)
    {
        this.contractId = contractId;
    }
    public int getNetWeight()
    {
        return netWeight;
    }
    public void setNetWeight(int netWeight)
    {
        this.netWeight = netWeight;
    }
    public String getCakNo()
    {
        return cakNo;
    }
    public void setCakNo(String cakNo)
    {
        this.cakNo = cakNo;
    }
    public int getInventoryId()
    {
        return inventoryId;
    }
    public void setInventoryId(int inventoryId)
    {
        this.inventoryId = inventoryId;
    }
    public int getResult()
    {
        return result;
    }
    public void setResult(int result)
    {
        this.result = result;
    }
    public int getNextval()
    {
        return nextval;
    }
    public void setNextval(int nextval)
    {
        this.nextval = nextval;
    }
    public float getDeliveredVolume()
    {
        return deliveredVolume;
    }
    public void setDeliveredVolume(float deliveredVolume)
    {
        //this.deliveredVolume = decimalFormat.format(deliveredVolume);
        this.deliveredVolume = deliveredVolume;
    }
    public String getTimeInDate()
    {
        return timeInDate;
    }
    public void setTimeInDate(String timeInDate)
    {
        this.timeInDate = timeInDate;
    }
    public String getTimeOutDate()
    {
        return timeOutDate;
    }
    public void setTimeOutDate(String timeOutDate)
    {
        this.timeOutDate = timeOutDate;
    }
    public String getEtaDate()
    {
        return etaDate;
    }
    public void setEtaDate(String etaDate)
    {
        this.etaDate = etaDate;
    }
    public String getTimeInTime()
    {
        return timeInTime;
    }
    public void setTimeInTime(String timeInTime)
    {
        this.timeInTime = timeInTime;
    }
    public String getTimeOutTime()
    {
        return timeOutTime;
    }
    public void setTimeOutTime(String timeOutTime)
    {
        this.timeOutTime = timeOutTime;
    }
    public String getEtaTime()
    {
        return etaTime;
    }
    public void setEtaTime(String etaTime)
    {
        this.etaTime = etaTime;
    }
    public String getCustomerName()
    {
        return customerName;
    }
    public void setCustomerName(String customerName)
    {
        this.customerName = customerName;
    }
   
    
}
