/*
 * SetUpAlert.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.domain;

public class SetUpAlert extends BaseModel
{
  
  private int alertCode;
  private String description;
  private String web;
  private String message;
  private int alertId;
  private String userId;
  private int result;
  private int nextval;
  private String alertCategory;
  private String receivedDate;
  private String statusWeb;
  
  
  public int getAlertCode()
  {
    return alertCode;
  }
  public void setAlertCode(int alertCode)
  {
    this.alertCode = alertCode;
  }
  public String getDescription()
  {
    return description;
  }
  public void setDescription(String description)
  {
    this.description = description;
  }
  public String getWeb()
  {
    return web;
  }
  public void setWeb(String web)
  {
    this.web = web;
  }
  public String getMessage()
  {
    return message;
  }
  public void setMessage(String message)
  {
    this.message = message;
  }
  public int getAlertId()
  {
    return alertId;
  }
  public void setAlertId(int alertId)
  {
    this.alertId = alertId;
  }
  public String getUserId()
  {
    return userId;
  }
  public void setUserId(String userId)
  {
    this.userId = userId;
  }
public int getResult()
{
    return result;
}
public void setResult(int result)
{
    this.result = result;
}
public int getNextval()
{
    return nextval;
}
public void setNextval(int nextval)
{
    this.nextval = nextval;
}
public String getAlertCategory()
{
    return alertCategory;
}
public void setAlertCategory(String alertCategory)
{
    this.alertCategory = alertCategory;
}
public String getReceivedDate()
{
    return receivedDate;
}
public void setReceivedDate(String receivedDate)
{
    this.receivedDate = receivedDate;
}
public String getStatusWeb()
{
    return statusWeb;
}
public void setStatusWeb(String statusWeb)
{
    this.statusWeb = statusWeb;
}
  
}
