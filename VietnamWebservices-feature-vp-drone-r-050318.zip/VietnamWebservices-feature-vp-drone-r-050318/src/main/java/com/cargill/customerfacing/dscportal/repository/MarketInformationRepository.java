/*
 * MarketInformationRepository.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.repository;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cargill.customerfacing.dscportal.domain.DSCConstants;
import com.cargill.customerfacing.dscportal.domain.MarketInformation;
import com.cargill.customerfacing.dscportal.domain.Status;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;

@Repository
public class MarketInformationRepository
{
    
    private static Logger logger = LoggerFactory
                        .getLogger(MarketInformationRepository.class);
    
    @Autowired
    JdbcTemplate jdbcTemplate;
    
    /**
     * Method to insert market info details
     * 
     * @param marketInformation
     * @param userid
     * @return
     * @throws BaseClassException
     */
    public MarketInformation insertMarketInformation(MarketInformation marketInformation ,
                        String userid , String contractCategory)
                        throws BaseClassException
    {
        Date today = new java.util.Date();
        long t = today.getTime();
        int nextval = 0;
        logger.info(":::::::::::::::::::::: insertMarketInformation repository ::::::::::::::::::::::::");
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            nextval = jdbcTemplate.queryForObject(
                                DSCConstants.MARKETINFO_NEXTVAL, new Object[]
                                {}, Integer.class);
            
            marketInformation.setResult(jdbcTemplate.update(DSCConstants.MARKETINFO_INSERT_QUERY,
                                new Object[]
                                { nextval,marketInformation.getHeading(),
                                                marketInformation.getDetails(),
                                                marketInformation.getStatus(),
                                                userid, new java.sql.Date(t),
                                                userid, new java.sql.Date(t),
                                                "Y", contractCategory }));
            
            if(marketInformation.getResult() > 0) {
                marketInformation.setNextval(nextval);
            }
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return marketInformation;
    }
    
    /**
     * Method to update market info details
     * 
     * @param marketInformation
     * @param marketId
     * @param userid
     * @return
     * @throws BaseClassException
     */
    public int updateMarketInformation(MarketInformation marketInformation ,
                         String userid , String contractCategory)
                        throws BaseClassException
    {
        logger.info(":::::::::::::::::::::: updateMarketInformation repository ::::::::::::::::::::::::");
        Date today = new java.util.Date();
        long t = today.getTime();
        int result = 0;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            result = jdbcTemplate.update(DSCConstants.MARKETINFO_UPDATE_QUERY,
                                new Object[]
                                { marketInformation.getHeading(),
                                                marketInformation.getDetails(),
                                                marketInformation.getStatus(),
                                                userid, new java.sql.Date(t),
                                                marketInformation.getMarketId(), contractCategory });
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return result;
    }
    
    /**
     * Method to delete market info details
     * 
     * @param marketId
     * @param userid
     * @return
     * @throws BaseClassException
     */
    public int deleteMarketInformation(int marketId , String userid)
                        throws BaseClassException
    {
        logger.info(":::::::::::::::::::::: deleteMarketInformation repository ::::::::::::::::::::::::");
        Date today = new java.util.Date();
        long t = today.getTime();
        int result = 0;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            result = jdbcTemplate.update(DSCConstants.MARKETINFO_DELETE_QUERY,
                                new Object[]
                                { new java.sql.Date(t), userid, marketId });
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return result;
    }
    
    /**
     * Method to get market info list
     * 
     * @param marketId
     * @param userid
     * @return
     * @throws Exception
     */
    public List<MarketInformation> getMarketInfoList(String contractCategory)
                        throws BaseClassException
    {
        List<MarketInformation> marketInformations = null;
        logger.info(":::::::::::::::::::::: getMarketInfoList repository ::::::::::::::::::::::::");
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            marketInformations = jdbcTemplate.query(
                                DSCConstants.MARKETINFOGET_QUERY, new Object[]
                                { contractCategory },
                                new BeanPropertyRowMapper<MarketInformation>(
                                                    MarketInformation.class));
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return marketInformations;
    }
    
}
