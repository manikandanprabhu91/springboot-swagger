package com.cargill.customerfacing.dscportal.token;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.filter.OncePerRequestFilter;

import com.cargill.customerfacing.dscportal.domain.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.oauth2.sdk.ParseException;
import com.okta.jwt.JoseException;
import com.okta.jwt.Jwt;
import com.okta.jwt.JwtHelper;
import com.okta.jwt.JwtVerifier;

public class TokenAuthenticationFilter extends OncePerRequestFilter {

	private final Log logger = LogFactory.getLog(this.getClass());

	private TokenHelper tokenHelper;
	@Autowired
	User userObj;

	public TokenAuthenticationFilter(TokenHelper tokenHelper) {
		this.tokenHelper = tokenHelper;

	}

	@SuppressWarnings("unused")
	@Override
	public void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		System.out.println("Inside TokenAuthenticatiion Filter");

		String jwtString = tokenHelper.getToken(request);
		String user = "";
		try {
			JwtVerifier jwtVerifier = new JwtHelper().setIssuerUrl(TokenConstants.ISSUER_URL)
					.setAudience(TokenConstants.AUDIENCE).setConnectionTimeout(1000).setReadTimeout(1000)
					.setClientId(TokenConstants.CLIENT_ID).build();

			Jwt jwt = jwtVerifier.decodeAccessToken(jwtString);
			Map claims = jwt.getClaims();
			if (claims.get("groups") == null || claims.get("groups").equals("")) {
				response.setStatus(401);
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Token is not valid.");

			} else {
				String json = new ObjectMapper().writeValueAsString(claims);
				//request.setAttribute("userdetails", json);
				userObj = getUserObject(json);
				userObj.setAccessToken(jwtString);
				request.setAttribute("user", userObj);
				chain.doFilter(request, response);
			}
		} catch (ParseException | JoseException e) {
			logger.error(e.getMessage());
			response.setStatus(406);
			response.sendError(HttpServletResponse.SC_NOT_ACCEPTABLE, "Token has Expired.");
		}

	}

	public static User getUserObject(String json) {

		json = "{ message:[" + json + "] }";
		User userObj = new User(json, false);
		try {
			List<String> groupString = new ArrayList<String>();

			String userid = "";
			JSONObject jsonObject = new JSONObject(json);
			JSONArray jsonArray = jsonObject.getJSONArray("message");
			
			for (int index = 0; index < jsonArray.length(); index++) {
				JSONObject userIdJsonAttr = (JSONObject) jsonArray.get(index);
				if (userIdJsonAttr != null) {
					userid = userIdJsonAttr.getString("sub");
					JSONArray jsonArrayGroup = userIdJsonAttr.getJSONArray("groups");
					for (int index1 = 0; index1 < jsonArrayGroup.length(); index1++) {
						String group = (String) jsonArrayGroup.get(index1);
						groupString.add(group);
						//Checking if the user is a customer user based on teh Okta groups and setting the flag
						if("DXP_DSC_CUSTOMER".equals(group))
						{
						    userObj.setCustomerUser(true);
						}
					}
				}
			}
			userObj.setUserId(userid);
			userObj.setRoles(groupString);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userObj;
	}

}