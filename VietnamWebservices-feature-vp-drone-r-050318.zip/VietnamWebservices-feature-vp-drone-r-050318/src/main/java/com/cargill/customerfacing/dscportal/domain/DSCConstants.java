/*
 * DSCConstants.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.domain;

public final class DSCConstants
{
    
    private DSCConstants()
    {
        
    }
       
    
    public static final String APPLICATION_JSON = "application/json";
    public static final String MULTIPART_FORMDATA = "multipart/form-data";
    public static final String APPLICATION_PDF = "application/pdf";
    
    public static final String BZAPI_ACCOUNTS = "accounts";
    public static final String BZAPI_COMMODITY = "commodityproducts";
    public static final String BZAPI_URL = "https://api-d.dev.dev-cglcloud.com/casc/v1";
    
    public static final String VIETNAM = "VNGOSC";
    public static final String ERROR404 = "Not found-400";
    public static final String ERROR500 = "JDBC connection Issue-500";
    public static final String ERRORNOTFOUND = "The resource you were trying to reach is not found";
    public static final String NORESULT = "No Results Found";
    public static final String CODE404 = "404";
    public static final String NOTUPDATED = "Please provide valid input!.";
    public static final String CAKNOERROR = "Cak No Already Exist!.";
    public static final String MANDATORY = "Required mandatory data.[eg, customerId,contractTypeId,expirationDate]";
    public static final String CODE500 = "500";
    public static final String CODE200 = "200";
    public static final String SERVERERROR = "Internal Server Error";
    public static final String SIGNED = "Signed";
    public static final String UNSIGNED = "Unsigned";
    public static final String COMPLETED = "Completed";
    public static final String ALL = "All";
    public static final String SUCCESS_UPDATE = "Successfully updated";
    public static final String SUCCESS_SAVE = "Successfully saved";
    public static final String SUCCESS_DELETE ="Successfully deleted";
    public static final String VERIFYING = "Verifying";
    public static final String EDIT = "Edit";
    public static final String NPD = "NPD";
    public static final String SIGHTED = "Sighted";
    public static final String ERROR = "Error:";
    public static final String SUCCESS = "Success";
    public static final String FAIL = "Fail";
    public static final String F101 = "F101";
    public static final String E100 = "E100";
    public static final String F201 = "F201";
    public static final String F102 = "F102";
    public static final String F103 = "F103";
    public static final String F202 = "F202";
    public static final String F203 = "F203";
    public static final String F204 = "F204";
    public static final String APPROVEDQTY_ERROR = "Total approved quantity exceeds contract volume";
    public static final String ARRIVAL_ERROR = "Total Vessel Arrival quantity exceeds contract approved quantity ";
    public static final String VESSEL_APPROVEDQTY_ERROR = "Total pickup schedule quantity exceeds arrival approved quantity ";
    public static final String CONTRACT_STATUS = " and s.description=? ";
    public static final String CONTRACT_TYPE = " and ct.contract_type=? ";
    public static final String SEARCH_CRITERI_CONTRACT = " and UPPER(c.commodity) LIKE ? or UPPER(c.cak_no) LIKE ? ";
    public static final String SEARCH_CRITERIA_INVENTORY = " and UPPER(vehicle_no) LIKE ? or UPPER(location) LIKE ? or UPPER(inv.cak_no) LIKE ? or UPPER(cargo) LIKE ? or UPPER(c.customer_name) LIKE ?";
    public static final String NOT_PAID = "Not Paid";
    
    public static final String USER_JOIN_QUERY =  " join user_profile as userprof on (c.customer_id=userprof.customer_id and user_id=?) ";
    
    public static final String UNIVERSAL_SECURITY_QUERY =  " and inv.contract_id in (select c.contract_id from contract c join user_profile as userprof on (c.customer_id=userprof.customer_id and user_id=?)) ";
    public static final String UNIVERSAL_SECURITY_QUERYFORCONTRACT =  " and c.contract_id in (select c.contract_id from contract c join user_profile as userprof on (c.customer_id=userprof.customer_id and user_id=?)) ";
    
    public static final String CORRELATED_QRY = " (select count(status_web) as notificationCount from actual_alert as aa join actual_alert_usermapping as am on (aa.actual_alert_id = am.actual_alert_id and am.actual_user_id=? and "
                        + " am.web='Y' and am.status_web='Open') where (aa.contract_id=c.contract_id and aa.contract_category=c.contract_category) )  from contract as c  "
                        + " left outer join arrival_schedule as arr on (c.contract_id=arr.contract_id and eta_date > current_date) ";
    
    // Contract
    public static final String GET_CONTRACTTYPEID = "select contract_type_id from contract_type where contract_type ='service' and contract_category=?";
    public static final String CONTRACTQUERY_BYID = "select c.contract_id,c.cak_no,c.cak_date,c.commodity,c.quantity,c.received,c.balance_stock,c.contract_type_id as contractTypeId,ct.contract_type as contractType,c.customer_id,c.customer_name,s.description as contractstatus,c.status_id as statusId,c.contract_category as contractcategory,c.basis,c.tendered_input as tendered,"
                        + " c.storage_terms,c.tolarance,c.unit_price,c.package_type as packagetype,c.ship_period,c.contract_price,c.destination,c.final_weightat,c.cargo_origin,c.currency,c.payment_terms,c.expiration_date,c.intransit_quantity,c.approvedQuantity,c.erp_contract_status as erpContractstatus "
                        + " from contract as c "
                        //+ " left outer join customer as cus on (c.customer_id = cus.customer_id and c.active_flag=cus.active_flag and c.contract_category=cus.contract_category)"
                        + " join contract_type as ct on (c.contract_type_id=ct.contract_type_id and c.contract_category=ct.contract_category) "
                        + " join status as s on (c.status_id=s.status_type) "
                        + " where c.contract_id=? and s.screen='contract' and c.contract_category=? and c.created_user=? and c.active_flag='Y'";
    public static final String CONTRACT_SELECT_COUNT = " select count(1) as maxCount from ( ";
    public static final String CONTRACT_SELECT_ALL = "select c.cak_no,c.cak_date,c.contract_id,c.commodity,c.quantity,c.received,c.balance_stock,c.contract_type_id as contractTypeId,s.description as contractstatus,ct.contract_type as contractType,c.customer_id,c.customer_name,c.status_id as statusId,c.contract_category as contractcategory,c.basis,c.tendered_input as tendered,c.storage_terms,c.tolarance,c.unit_price,c.package_type as packagetype,c.ship_period,c.contract_price,c.destination,c.final_weightat,c.cargo_origin,c.currency,c.payment_terms,count(eta_date) as shipmentCount,coalesce((ETA_DATE - current_date), 0) as days,c.expiration_date,c.intransit_quantity,c.approvedQuantity,c.erp_contract_status as erpContractstatus,"
                        + CORRELATED_QRY
                       // + " left outer join customer as cus on (c.customer_id = cus.customer_id and c.active_flag=cus.active_flag and c.contract_category=cus.contract_category)"
                        + " left outer join contract_type as ct on (c.contract_type_id=ct.contract_type_id and c.contract_category=ct.contract_category) "
                        + " left outer join status as s on (c.status_id=s.status_type) "
                        + " join user_profile as userprof on (c.customer_id=userprof.customer_id and user_id=?) "
                        + " where c.active_flag='Y' and c.contract_category=? ";
    
    public static final String CONTRACT_GROUPBY = " group by c.cak_no,c.cak_date,c.contract_id,c.commodity,c.quantity,c.received,c.balance_stock,c.customer_id,c.customer_name,c.status_id,c.contract_category,c.basis,"
                        + " c.tendered_input,c.storage_terms, c.tolarance,c.unit_price,c.package_type,c.ship_period,c.contract_price,c.destination,c.final_weightat,c.cargo_origin,c.currency,"
                        + " c.payment_terms,(eta_date - current_date), c.expiration_date,c.intransit_quantity,c.approvedQuantity,c.contract_type_id,c.erp_contract_status,ct.contract_type,s.description "
                        + " order by c.expiration_date ASC ";
    public static final String CONTRACT_END_COUNT = ") contractlist";
    public static final String CONTRACT_INSERT_QUERY = "insert into contract(contract_id,cak_no,cak_date,commodity,quantity,contract_type_id,customer_id,status_id,created_user,created_date,modified_user,modified_date,active_flag,contract_category,tendered_input,basis,storage_terms,tolarance,unit_price,package_type,ship_period,contract_price,destination,final_weightat,cargo_origin,currency,payment_terms,received,balance_stock,erp_contract_status,expiration_date,intransit_quantity,approvedQuantity,customer_name) values (?,?,TO_DATE(?,'YYYY-MM-DD'),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,TO_DATE(?,'YYYY-MM-DD'),?,0,?)";
    public static final String CONTRACT_UPDATE_QUERY = "update contract set commodity=?,quantity=?,received=?,balance_stock=?,contract_type_id=?,status_id=?,tendered_input=?,basis=?,modified_user=?,modified_date=?,storage_terms=?,tolarance=?,unit_price=?,package_type=?,ship_period=?,contract_price=?,destination=?,final_weightat=?,cargo_origin=?,currency=?,payment_terms=?,erp_contract_status=?,expiration_date=TO_DATE(?,'YYYY-MM-DD'),intransit_quantity=?,customer_name=? where contract_id=? and customer_id=? and contract_category=? and created_user=? and active_flag='Y'";
    public static final String CONTRACT_DELETE_QUERY = "update contract set active_flag='N',modified_date=? where contract_id=? and created_user=?";
    public static final String CONTRACT_INSERTED_VALUE = "select * from contract where cak_no=? and contract_type_id=? and active_flag='Y' and contract_category =?";
    public static final String CAKNO_CHK = "select COUNT(*) from contract where lower(cak_no)=lower(?) and contract_type_id=? and active_flag='Y' and contract_category =?";
    public static final String CONTRACT_NEXTVAL = "select nextval('contract_contract_id_seq')";
    public static final String CONTRACT_QUANTITY = "select quantity,approvedQuantity from contract where contract_id=? and active_flag='Y' and contract_category=?";
    public static final String CONTRACT_UPDATE_APPQTY = " update contract set approvedQuantity = ?,modified_user=?,modified_date=? where contract_id=? and active_flag='Y'";
    public static final String QUERY_LIMIT_APPEND = " LIMIT ? OFFSET ?";
    public static final String CUSTOMER_VALUE = "select customer_id from contract where contract_id=? and active_flag='Y'";
    public static final String CONTRACT_DIFF_DAYS = "select expiration_date::date - current_date::date as days,contract_id,contract_category,cak_no,customer_id  from contract where active_flag='Y' and expiration_date::date - current_date::date "
                       + "in (select rule_days from alert_scheduler where screen='contract' and active_flag='Y')";
    // Payment
    public static final String GET_PAYMENT_STATUSTYPE = "select status_type as statuscode from status where screen='payment' and description=?";
    public static final String PAYMENT_SELECT_QUERY = "select description as paymentStatus,payment_date,payment_amount,filename,payment_id,contract_id,bank_name,branch_name,transaction_ref,to_char( time, 'HH24:MI') as time from payment as p join status as s on (p.status=s.status_type) where contract_id=? and p.active_flag='Y'";
    public static final String PAYMENT_INSERT_QUERY = "insert into payment(payment_id,status,payment_date,payment_amount,filename,created_user,created_date,modified_user,modified_date,active_flag,contract_id,bank_name,branch_name,transaction_ref,time) values (?,?,TO_DATE(?,'YYYY-MM-DD'),?,?,?,?,?,?,?,?,?,?,?,TO_TIMESTAMP(?, 'HH24:MI'))";
    public static final String PAYMENT_UPDATE_QUERY = "update payment set status=(select status_type from status where description=? and screen='payment'),modified_user=?,modified_date=? where contract_id=? and active_flag='Y' and payment_id=?";
    public static final String PAYMENT_UPDATE_DATE_QUERY = "update payment set payment_date=to_date(?, 'YYYY-MM-DD'),modified_user=?,modified_date=? where contract_id=? and active_flag='Y' and payment_id=?";
    public static final String PAYMENT_DELETE_QUERY = "delete from payment where contract_id=? and payment_id=?";
    public static final String INSERT_APPROVED_QUANTITY = "insert into approved_quantity(contract_id,approved_qty,created_user,created_date,modified_user,modified_date) values (?,?,?,?,?,?)";
    public static final String CONTRACT_TOTAL_AMT = "select quantity,unit_price from contract where active_flag='Y' and contract_id=?";
    public static final String PAYMENT_TOTAL_AMT = "select coalesce(sum(payment_amount),0) as amount from payment where active_flag='Y' and contract_id=?";
    public static final String CONTRACT_DIFF = "update payment set payment_amount=?,modified_user=?,modified_date=? where status =? and contract_id=? and active_flag='Y';";
    public static final String PAYMENT_DIFF = "select payment_amount,payment_id from payment where status='NPD' and contract_id=? and active_flag='Y'";
    public static final String SELECT_PAYID = "select * from payment where active_flag='Y' and contract_id=? and payment_id=?";
    public static final String PAYMENT_NEXTVAL = "select nextval('payment_payment_id_seq')";
    public static final String PAYMENT_DATE_EQUALS = "SELECT pay.payment_id,pay.contract_id,c.contract_category,c.customer_id FROM payment as pay join contract as c on (pay.contract_id=c.contract_id and pay.active_flag=c.active_flag) " 
                        + " where payment_date = current_date and pay.active_flag='Y'";
    // Status
    public static final String STATUS_LIST = "select * from status where screen=?";
    public static final String STATUS_GET = "select sum(approved_qty) as approvedQty,approved_qty_id as approvedquantityid,contract_id from approved_quantity where contract_id=? group by approvedquantityid,contract_id";
    // PickUp
    public static final String PICKUP_INSERT_QUERY = "insert into pickup_schedule (pickup_id,contract_id,pickupdate,pickup_time,approvedpickupdate,approvedpickup_time,filename,pickup_qty,arrival_schedule_id,created_user,created_date,modified_user,modified_date,active_flag,status,authorization_number) values (?,?,to_date(?,'YYYY-MM-DD'),TO_TIMESTAMP(?, 'HH24:MI'),to_date(?,'YYYY-MM-DD'),TO_TIMESTAMP(?, 'HH24:MI'),?,?,?,?,?,?,?,'Y',?,?)";
    public static final String PICKUP_GET_ALL = "select pickup_id as pickUpId,contract_id,pickupdate as pickUpDate,approvedpickupdate as approvedPickUpDate,filename as fileName,pickup_qty as pickUpQty,arrival_schedule_id ,status,authorization_number,"
                        + " to_char( pickup_time, 'HH24:MI') as pickUpTime,to_char( approvedpickup_time, 'HH24:MI') as approvedPickUpTime"
                        + " from pickup_schedule where contract_id=? and active_flag='Y'";
    public static final String PICKUP_BYID = "select * from pickup_schedule where contract_id=? and active_flag='Y' and pickup_id=?";
    public static final String PICKUP_DELETE = "update pickup_schedule set active_flag='N',modified_date=?,modified_user=? where contract_id=? and pickup_id=?";
    public static final String UPDATE_PICKUP = "update pickup_schedule set status=?,pickup_qty=?,pickupdate=to_date(?, 'YYYY-MM-DD'),pickup_time=TO_TIMESTAMP(?, 'HH24:MI'),modified_date=?,modified_user=? where contract_id=? and pickup_id=? and active_flag='Y'";
    public static final String UPDATE_PICKUP_STATUS = "update pickup_schedule set status=?,pickup_qty=?,approvedpickupdate=now(),approvedpickup_time=now(),modified_date=?,modified_user=? where pickup_id=? and active_flag='Y'";
    public static final String PICKUP_STATUSINDB = "select status from pickup_schedule where contract_id=? and active_flag='Y' and pickup_id=?";
    public static final String PICKUP_COMPARE_TOTALQTY ="select arr.approvedquantity as arrivalTotalQty,sum(coalesce(ps.pickup_qty,0)) as pickUpQty from arrival_schedule as arr left outer join  pickup_schedule as ps on" 
                                + " (arr.contract_id=ps.contract_id and arr.arrival_schedule_id=ps.arrival_schedule_id) where arr.contract_id =? and arr.arrival_schedule_id=? group by arr.approvedquantity";
    public static final String PICKUP_COMPARE_TOTALQTY_UPDATE ="select arr.approvedquantity as arrivalTotalQty,sum(coalesce(ps.pickup_qty,0)) as pickUpQty from arrival_schedule as arr left outer join  pickup_schedule as ps on" 
                        + " (arr.contract_id=ps.contract_id and arr.arrival_schedule_id=ps.arrival_schedule_id and ps.pickup_id != ?) where arr.contract_id =? and arr.arrival_schedule_id=? group by arr.approvedquantity";
    public static final String PICKUP_NEXTVAL = "select nextval('pickup_schedule_pickup_id_seq')";
    public static final String DOWNLOAD_QRCODE= "select a.commodity as commodity,c.cak_no as cakNo,a.approvedquantity as approvedQuantity from pickup_schedule p "
                                              + " left outer join arrival_schedule a on (p.arrival_schedule_id=a.arrival_schedule_id and p.contract_id=a.contract_id) "
                                              + " left outer join contract c on (c.contract_id=p.contract_id and c.active_flag=p.active_flag) where p.pickup_id=? and p.contract_id=? and p.active_flag='Y' ";
    // Market Info
    public static final String MARKETINFO_INSERT_QUERY = "insert into market_information (market_id,heading,details,status,created_user,created_date,modified_user,modified_date,active_flag,contract_category) values (?,?,?,?,?,?,?,?,?,?)";
    public static final String MARKETINFO_UPDATE_QUERY = "update market_information set heading=?,details=?,status=?,modified_user=?,modified_date=? where market_id=? and active_flag='Y' and contract_category=?";
    public static final String MARKETINFO_DELETE_QUERY = "update market_information set active_flag='N',modified_date=?,modified_user=? where market_id=?";
    public static final String MARKETINFOGET_QUERY = "select * from market_information where active_flag='Y' and  contract_category=?";
    public static final String MARKETINFO_TEST_VALUE = "select market_id from market_information where contract_category=? and created_user='TEST' and active_flag='Y'";
    public static final String MARKETINFO_NEXTVAL = "select nextval('market_information_market_id_seq')";
    // Arrival Schedule
    public static final String ARRIVALSCHDULE_INSERT_QUERY = "insert into arrival_schedule (arrival_schedule_id,commodity,approvedQuantity,tendered,shipment_period,vessel_name,warehouse,eta_date,eta_time,created_user,created_date,modified_user,modified_date,contract_id,delivery_basis,arrival_sequence) values (?,?,?,?,?,?,?,TO_DATE(?,'YYYY-MM-DD'),TO_TIMESTAMP(?, 'HH24:MI'),?,?,?,?,?,?,(select coalesce(max(arrival_sequence),0) + 1  as arrseq from arrival_schedule where contract_id=?))";
    public static final String ARRIVAL_SCHDL_SELECT_QUERY = " select arr.arrival_schedule_id,arrival_sequence,to_char( eta_time, 'HH24:MI') as eta_time,arr.commodity,arr.approvedQuantity,arr.tendered,arr.shipment_period,arr.vessel_name,arr.warehouse as wareHouse"
                                                    + " ,arr.eta_date,arr.contract_id,delivery_basis as deliveryBasiscode,basis_desc as deliveryBasis,pks.pickup_id as pickUpId,pks.pickupdate as pickUpDate,pks.approvedpickupdate as approvedPickUpDate,pks.filename as fileName, "
                                                    + " coalesce(pks.pickup_qty,0) as pickupQty,pks.status,pks.authorization_number as authorizationNumber,to_char( pickup_time, 'HH24:MI') as pickUpTime,to_char( approvedpickup_time, 'HH24:MI') as approvedPickUpTime "
                                                    + " from arrival_schedule as arr "
                                                    + " left outer join deliverybasis on (basis_code = arr.delivery_basis) "
                                                    + " left outer join pickup_schedule as pks on (arr.contract_id=pks.contract_id and arr.arrival_schedule_id=pks.arrival_schedule_id and pks.active_flag='Y') "
                                                    + " where arr.contract_id=? order by arr.arrival_schedule_id,arrival_sequence ";
    public static final String ARRIVAL_SCHDL_SELECT_QUERY_WITHKEY = "select to_char( eta_time, 'HH24:MI') as eta_time,commodity,approvedQuantity,tendered,shipment_period,vessel_name,warehouse,eta_date,arrival_schedule_id,contract_id,"
                        + " delivery_basis  as deliveryBasiscode ,basis_desc as deliveryBasis,arrival_sequence"
                        + " from arrival_schedule"
                        + " left outer join deliverybasis on (basis_code = delivery_basis) "
                        + " where contract_id=? and UPPER(delivery_basis) LIKE ?";
    public static final String ARRIVAL_SCHDL_UPDATE_QUERY = "update arrival_schedule set commodity=?,approvedQuantity=?,tendered=?,shipment_period=?,vessel_name=?,warehouse=?,eta_date=TO_DATE(?,'YYYY-MM-DD'),eta_time=TO_TIMESTAMP(?, 'HH24:MI'),modified_user=?,modified_date=?,delivery_basis=? where contract_id =? and arrival_schedule_id=?";
    public static final String ARRIVAL_SCHDL_DELETE_QUERY = "delete from arrival_schedule where arrival_schedule_id=? and contract_id=?";
    public static final String ARRIVAL_COMPARE_TOTALQTY = " select c.approvedquantity as contractTotalQty,sum(coalesce(arr.approvedquantity,0))  as approvedQuantity from contract as c left outer join  arrival_schedule as arr on (c.contract_id=arr.contract_id) "
                                                            + " where c.contract_id=? and c.contract_category=? and c.active_flag='Y' group by c.approvedquantity";
    public static final String ARRIVAL_NEXTVAL = "select nextval('arrival_schedule_arrival_schedule_id_seq')";
    // Invoice
    public static final String INVOICE_SELECT_QUERY = "select inv.invoice_no,inv.invoice_id,inv.invoice_date,inv.invoice_amount,inv.commodity_name,inv.contract_id,inv.commodity_qty,inv.filename,c.customer_name"
                                + " from invoice as inv left outer join contract c on (inv.contract_id=c.contract_id) where 1=1 ";
    public static final String INVOICE_MONTHYEAR_QUERY = " and extract(month from invoice_date)=? and extract(year from invoice_date)=? ";
    public static final String INVOICE_INSERT_QUERY = "insert into invoice (invoice_id,invoice_no,invoice_date,commodity_qty,invoice_amount,commodity_name,filename,contract_id,created_user,created_date,modified_user,modified_date) VALUES (?, ?, TO_DATE(?,'YYYY-MM-DD'), ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    public static final String INVOICE_UPDATE_QUERY = "update invoice set invoice_no=?,invoice_date=TO_DATE(?,'YYYY-MM-DD'),commodity_qty=?,invoice_amount=?,commodity_name=?,modified_user=?,modified_date=?  where invoice_id=? and contract_id=?";
    public static final String INVOICE_NEXTVAL = "select nextval('invoice_invoice_id_seq')";
    public static final String INVOICE_ORDERBY_APPEND = " order by invoice_date ";
    public static final String ASCDESC = " desc";
    public static final String INVOICE_DELETE_QUERY = "delete from invoice where invoice_id=?";
    public static final String INVOICE_ID_APPEND = " and invoice_id = ?";
    public static final String CUSTOMER_NAME_APPEND = " and upper(c.customer_name) like ?";
    public static final Integer PAYMENT_SIGHTED_CODE = 101;
    public static final Integer PICKUP_ADD_CODE = 201;
    public static final Integer PICKUP_DENIED_CODE = 202;
    public static final Integer PICKUP_APPROVED_CODE = 203;
    // Customer
    public static final String CUSTOMER_LIST = "select * from customer where contract_category=? and active_flag='Y'";
    // Inventory
    public static final String INVENTORY_SELECT_QUERY = "select cargo,remarks,vehicle_type,vehicle_no,time_in_date,weight_in,time_out_date,weight_out,total_weight,packing,mode,location,pickup_id," 
                         + " inv.cak_no,inv.inventory_id,inv.contract_id,net_weight,eta_date,delivered_volume,to_char( time_in_time, 'HH24:MI') as time_in_time," 
                         + " to_char( time_out_time, 'HH24:MI') as time_out_time,to_char( eta_time, 'HH24:MI') as eta_time,c.customer_name "
                         + " from inventory"
                         + " inv left outer join contract c on (inv.contract_id=c.contract_id and inv.active_flag = c.active_flag) "
                         + " where inv.active_flag='Y'";
    public static final String INVENTORY_INSERT_QUERY = "insert into inventory(inventory_id,cargo,vehicle_type,vehicle_no,time_in_date,time_in_time,weight_in,time_out_date,time_out_time,weight_out,total_weight,packing,mode,location,pickup_id,cak_no,remarks,contract_id,created_user,created_date,modified_user,modified_date,active_flag,net_weight,eta_date,eta_time,delivered_volume) values(?,?,?,?,TO_DATE(?,'YYYY-MM-DD'),TO_TIMESTAMP(?, 'HH24:MI'),?,TO_DATE(?,'YYYY-MM-DD'),TO_TIMESTAMP(?, 'HH24:MI'),?,?,?,?,?,?,?,?,?,?,?,?,?,'Y',?,TO_DATE(?,'YYYY-MM-DD'),TO_TIMESTAMP(?, 'HH24:MI'),?)";
    public static final String INVENTORY_UPDATE_QUERY = "update inventory set cargo=?,vehicle_type=?,vehicle_no=?,time_in_date=TO_DATE(?,'YYYY-MM-DD'),time_in_time=TO_TIMESTAMP(?, 'HH24:MI'),weight_in=?,time_out_date=TO_DATE(?,'YYYY-MM-DD'),time_out_time=TO_TIMESTAMP(?, 'HH24:MI'),weight_out=?,total_weight=?,packing=?,mode=?,location=?,pickup_id=?,cak_no=?,remarks=?,modified_user=?,modified_date=?,net_weight=?,eta_date=TO_DATE(?,'YYYY-MM-DD'),eta_time=TO_TIMESTAMP(?, 'HH24:MI'),delivered_volume=? where inventory_id=? and active_flag='Y'";
    public static final String INVENTORY_NEXTVAL = "select nextval('inventory_inventory_id_seq')";
    public static final String CONTRACTID_APPEND = " and inv.contract_id = ?";
    public static final String CUSTOMERID_APPEND = " and inv.contract_id in (select contract_id from contract where customer_id = ?)";
    public static final String INVENTORY_ID_APPEND = " and inventory_id = ?";
    public static final String INVENTORY_ORDERBY_APPEND = " order by time_in_date ";
    public static final String INVENTORY_ORDERBY_INQUERY = " order by ";
    public static final String INVENTORY_SUMMARY = "select lower(vehicle_type) as vehicle_type,sum(coalesce(net_weight,0)) as net_weight from inventory "
                        + " inv left outer join contract c on (inv.contract_id=c.contract_id) "
                        + " where 1=1 and lower(vehicle_type) in ('truck','barge') ";
    public static final String INVENTORY_SUMMARY_GRBY = " group by lower(vehicle_type),net_weight";
    public static final String INVENTORY_SUMMARY_ORBY = " order by vehicle_type asc ";
    public static final String INVENTORY_DELETEUPDATE_QUERY = "update inventory set active_flag='N',modified_date=?,modified_user=? where inventory_id=?";
    // alert
    public static final String ACTUAL_ALERT_COUNT = "select count(1) as result from ( ";
    public static final String ACTUAL_ALERT_SELECT_QUERY = "select a.actual_title as description, a.actual_message as message, a.actual_alert_id as alertid,s.alert_category,received_date,s.alert_code,s.web,au.actual_user_id as userId,au.status_web"
                        + " from actual_alert as a"
                        + " join actual_alert_usermapping as au on (a.actual_alert_id=au.actual_alert_id) "
                        + " join setup_alert s on (s.alert_id=a.alert_id and a.contract_category=s.contract_category) "
                        + " where s.contract_category=? and au.actual_user_id=? and au.status_web != 'Delete' ";
    public static final String ACTUAL_ALERT_COUNT_END = " and  au.status_web = 'Open' and alert_category='Red' )  alertlist";
    public static final String AUTODELETE = "select contract_category,customer_id,a.actual_alert_id from actual_alert a left outer join actual_alert_usermapping aa on (a.actual_alert_id=aa.actual_alert_id ) "
                            + " where received_date::date - current_date::date  = 30 and aa.status_web='Read' group by contract_category,customer_id,a.actual_alert_id";
    public static final String DELETE_AA_USERMAPP = "delete from actual_alert_usermapping where actual_alert_id=?";
    public static final String DELETE_ACTUAL_ALERT = "delete from actual_alert where actual_alert_id=?";
    public static final String INSERT_ACTUAL_ALERT_USERMAP = "INSERT INTO actual_alert_usermapping(actual_alert_id, actual_user_id, web, email, sms, status_web, status_email, status_sms, created_user, created_date, modified_user, modified_date) "
                        + " select aa.actual_alert_id, au.user_id, au.web, au.email, au.sms ,'Open' as status_web,'N' as status_email,'N' as status_sms,aa.created_user as created_user,now() as created_date,aa.modified_user as modified_user,"
                        + " now() as created_date from setup_alert sa inner join alert_user_mapping au on sa.alert_id=au.alert_id inner join user_profile prof on prof.user_id = au.user_id join "
                        + " actual_alert as aa on (aa.customer_id=prof.customer_id and aa.alert_id=sa.alert_id) where sa.alert_code = ? and au.web='Y' and au.contract_category=? "
                        + " and prof.customer_id=? and aa.contract_id=? and aa.payment_id=? and aa.invoice_id=?";
    public static final String UPDATE_ACTUAL_ALERT = "update actual_alert_usermapping set status_web=?,modified_date=?,modified_user=? where actual_user_id=? and actual_alert_id=?";
    public static final String GET_ALERTID = "select * from setup_alert where alert_code=? and web='Y' and contract_category=?";
    public static final String INSERT_ACTUAL_ALERT = "INSERT INTO actual_alert(actual_alert_id,customer_id, alert_id ,actual_title,actual_message, contract_id, payment_id, invoice_id, created_user, created_date, modified_user, modified_date, contract_category,received_date) VALUES (?,?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?,TO_DATE(?,'YYYY-MM-DD'));";
    public static final String PAYMENT_REMINDING_SELECT_QUERY = "select prof.user_id from payment as pay inner join contract as cont on pay.contract_id=cont.contract_id and pay.active_flag=cont.active_flag  inner join user_profile as prof on cont.customer_id=prof.customer_id where cont.active_flag='Y' and pay.payment_id=?";
    public static final String PAYMENTREMINDING_INSERT = "insert into actual_alert (actual_user_id, alert_id, message, web, email, sms ,created_user,created_date,modified_user,modified_date,contract_category,status) values (?,?,'N','Y','N','N',?,?,?,?,?,'Unsigned')";
    public static final String ALERT_CODE = "select alert_id from setup_alert where alert_code=?";
    //user profile
    public static final String CUST_PROFILE_SELECT_QUERY = "select * from user_profile where customer_id =?";
    public static final String USER_PROFILE_UPDATE_QUERY = "update user_profile set user_id=?, email=?, cargill_user=?, customer_id=? , modified_user=?, modified_date=? WHERE active_flag=? and user_profile_id=?";
    public static final String USER_PROFILE_NEXTVAL = "select nextval('user_profile_user_profile_id_seq')";
    public static final String USER_PROFILE_INSERT_QUERY = "insert into user_profile(user_profile_id, user_id, email, active_flag, cargill_user, created_user, created_date, modified_user, modified_date, customer_id) "
                            + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    public static final String STATUS_SELECT_QUERY = "select * from status where status_id =?";
    public static final String STATUS_INSERT_QUERY = "insert into status(status_id,status_type,description) values(?,?,?)";
    public static final String SERVICE_CONTRACTS_SELECT_QUERY = "select * from service_contracts where cak_no =?";
    public static final String PAYMENT_SELECT_DOWNLOAD_QUERY = "select filename from pickup_schedule where cak_no=?";
    public static final String ACTUAL_ALERT_NEXTVAL = "select nextval('actual_alert_actual_alert_id_seq')";
    // User Profile
    public static final String USERCONFIG_SELECT_QUERY = "select * from user_config as c join user_profile as p on (c.user_id=p.user_id) where c.user_id=? and p.active_flag='Y' and c.f_active='Y' and contract_category=?";
    public static final String USERCONFIG_UPDATE_QUERY = "update user_config set screen_id=?,section_id=?,attribute_id=?,attribute_value=?,modified_user=?,modified_date=? where user_config_id=? and user_id=? and f_active='Y' and contract_category=?";
    // User Alert Mapping
    public static final String USERMAP_SELECT_QUERY = "select * from alert_user_mapping where contract_category=? and web='Y' and user_id=? and active_flag='Y'";
    public static final String USERMAP_UPDATE_QUERY = "update alert_user_mapping set web=?,email=?,sms=?,alert_id=?,modified_user=?,modified_date=? where contract_category=? and alert_user_mapping_id=? and active_flag='Y' and user_id=?";
}
