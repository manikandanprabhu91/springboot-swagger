/*
 * IInventory.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.service;

import java.util.List;

import com.cargill.customerfacing.dscportal.domain.Inventory;
import com.cargill.customerfacing.dscportal.domain.Summary;
import com.cargill.customerfacing.dscportal.domain.User;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;

public interface IInventory
{
    
    public List<Inventory> getInventoryList(int contractId , String customerId ,
                        int inventoryId , String contractCategory ,
                        User user,int limit,int offset,String searchCriteria,String sortby,String direction) throws BaseClassException;
    
    public Inventory insertInventory(int contractId , Inventory inventory ,
                        String userid) throws BaseClassException;
    
    public int updateInventory(Inventory inventory , String userid)
                        throws BaseClassException;

    public List<Summary> getSummaryAndTotalInventory(String contractCategory ,
                        User user,String searchCriteria,int contractId) throws BaseClassException;

    public int deleteInventory(int inventoryId , String userid) throws BaseClassException;
    
}
