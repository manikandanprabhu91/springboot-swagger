/*
 * Customer.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.domain;

public class Customer extends BaseModel
{
  
  private String customerId;
  private String customerCode;
  private String customerName;
  private String contractCategory;
  
  public String getCustomerId()
  {
    return customerId;
  }
  public void setCustomerId(String customerId)
  {
    this.customerId = customerId;
  }
  public String getCustomerName()
  {
    return customerName;
  }
  public void setCustomerName(String customerName)
  {
    this.customerName = customerName;
  }
  public String getContractCategory()
  {
    return contractCategory;
  }
  public void setContractCategory(String contractCategory)
  {
    this.contractCategory = contractCategory;
  }
public String getCustomerCode()
{
    return customerCode;
}
public void setCustomerCode(String customerCode)
{
    this.customerCode = customerCode;
}
  
}
