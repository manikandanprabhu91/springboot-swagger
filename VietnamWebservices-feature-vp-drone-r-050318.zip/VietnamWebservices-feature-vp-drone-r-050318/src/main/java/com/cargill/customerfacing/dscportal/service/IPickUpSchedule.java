/*
 * IPickUpSchedule.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.service;

import java.util.List;

import com.cargill.customerfacing.dscportal.domain.ArrivalSchedule;
import com.cargill.customerfacing.dscportal.domain.PickUpSchedule;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;

public interface IPickUpSchedule
{
  
  public PickUpSchedule insertPickUpSchedule(PickUpSchedule pickUpSchedule , String userid,String contractCategory)
            throws BaseClassException;
  
  public List<PickUpSchedule> getPickUpScheduleList(int contractId ,
            String userid) throws BaseClassException;
  
  public List<PickUpSchedule> getPickUpScheduleBYID(int contractId , int pickupId)
            throws BaseClassException;
  
  public int updatePickUpSchedule(PickUpSchedule pickUpSchedule ,
            int contractId , String userid,String contractCategory) throws BaseClassException;
  
  public int deletePickUpSchedule(int contractId , String userid , int pickupid)
            throws BaseClassException;

 public ArrivalSchedule generateQRCode(int contractId , int pickUpId) throws BaseClassException;
}
