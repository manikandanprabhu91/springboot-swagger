package com.cargill.customerfacing.dscportal.token;

public class TokenConstants {
	public static final String ISSUER_URL ="https://cargillcustomer-qa.oktapreview.com/oauth2/default"  ;
	public static final String AUDIENCE = "api://default";
	public static final String CLIENT_ID = "0oaeasizkxLpLJOVu0h7"; 
}
