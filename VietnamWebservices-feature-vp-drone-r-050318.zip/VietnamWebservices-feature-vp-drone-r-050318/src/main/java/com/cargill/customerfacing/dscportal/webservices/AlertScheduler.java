package com.cargill.customerfacing.dscportal.webservices;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.cargill.customerfacing.dscportal.domain.ActualAlert;
import com.cargill.customerfacing.dscportal.domain.Contract;
import com.cargill.customerfacing.dscportal.domain.DSCConstants;
import com.cargill.customerfacing.dscportal.domain.Payment;
import com.cargill.customerfacing.dscportal.domain.SetUpAlert;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.repository.AlertNotificationRepository;

@Component
public class AlertScheduler
{
    @Autowired
    JdbcTemplate jdbcTemplate;
    
    @Autowired
    AlertNotificationRepository alertNotificationRepository;
    
    private static Logger logger = LoggerFactory
                        .getLogger(AlertScheduler.class);
    
//    @Scheduled(cron = �"0 0 0 * * *") //everyday
    //@Scheduled(cron = "*/10 * * * * *")
    /**
     * 
     * @throws BaseClassException
     */
    public void contractExpiryAlert() throws BaseClassException{
        logger.info("********************Scheduled task running contractExpiryAlert***********************");
        try {
       List<Contract> contract = jdbcTemplate.query(
                            DSCConstants.CONTRACT_DIFF_DAYS,
                            new BeanPropertyRowMapper<Contract>(
                                                Contract.class));
       if(contract != null) {
           for(Contract c:contract) {
               SetUpAlert alert = alertNotificationRepository.setupAlert(2, c.getContractCategory(), c.getCustomerId(), "scheduler", c.getContractId(), 0, 0,Integer.parseInt(c.getCakNo()));
               logger.info("********************Scheduled task running contractExpiryAlert***********************");
               if(alert!=null && alert.getResult()>0) {
                   logger.info("********************Scheduled task Successfully executed contractExpiryAlert***********************");
               }
           }
           
       }
    }catch(Exception e){
        logger.info("********************Scheduled task error***********************"+e.getMessage());
    }
    }
    
    /**
     * 
     * @throws BaseClassException
     */
//  @Scheduled(cron = �"0 0 0 * * *") //everyday
    public void paymentDue() throws BaseClassException{
        logger.info("********************Scheduled task running paymentDue***********************");
        try {
        List<Payment> payment = jdbcTemplate.query(
                            DSCConstants.PAYMENT_DATE_EQUALS,
                            new BeanPropertyRowMapper<Payment>(
                                                Payment.class));
        if(payment != null) {
            for(Payment pay:payment) {
                SetUpAlert alert = alertNotificationRepository.setupAlert(104, pay.getContractCategory(), pay.getCustomerId(), "scheduler", 0, pay.getPaymentId(), 0,0);
                logger.info("********************Scheduled task running paymentDue***********************");
                if(alert!=null && alert.getResult()>0) {
                    logger.info("********************Scheduled task Successfully executed paymentDue***********************");
                }
            }
        }
        }catch(Exception e){
            logger.info("********************Scheduled task error paymentDue***********************"+e.getMessage());
        }
    }
    
    /**
     * 
     * @throws BaseClassException
     */
//  @Scheduled(cron = �"0 0 0 * * *") //everyday
   // @Scheduled(cron = "*/10 * * * * *")
    public void autoDelete() throws BaseClassException{
        logger.info("********************Scheduled task running autoDelete***********************");
        int rsult= 0;
        int rsult1= 0;
        try {
        List<ActualAlert> actual = jdbcTemplate.query(
                            DSCConstants.AUTODELETE,
                            new BeanPropertyRowMapper<ActualAlert>(
                                                ActualAlert.class));
        if(actual != null) {
            for(ActualAlert actualalert:actual) {
                rsult = jdbcTemplate.update(DSCConstants.DELETE_AA_USERMAPP,
                                    new Object[]
                                    { actualalert.getActualAlertId() });
                if(rsult > 0) {
                    logger.info("********************autoDelete - >AA USERMAP DELETED FOR AALERTID***********************"+actualalert.getActualAlertId());
                    rsult1 = jdbcTemplate.update(DSCConstants.DELETE_ACTUAL_ALERT,
                                        new Object[]
                                        { actualalert.getActualAlertId() });  
                    if(rsult1 >0) {
                        logger.info("********************autoDelete - >AA DELETED FOR AALERTID***********************"+actualalert.getActualAlertId());
                    }
                }
            }
        }
    }catch(Exception e){
        logger.info("********************Scheduled task error autoDelete***********************"+e.getMessage());
    }
    }
}
