/*
 * InventoryRepository.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;

import com.cargill.customerfacing.dscportal.domain.DSCConstants;
import com.cargill.customerfacing.dscportal.domain.Inventory;
import com.cargill.customerfacing.dscportal.domain.Summary;
import com.cargill.customerfacing.dscportal.domain.User;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;

@Repository
public class InventoryRepository
{
    
    private static Logger logger = LoggerFactory
                        .getLogger(InventoryRepository.class);
    
    @Autowired
    JdbcTemplate jdbcTemplate;
    
    /**
     * Method to get inventory list
     * 
     * @param contractId
     * @param customerId
     * @param inventoryId
     * @param contractCategory
     * @param userid
     * @return
     * @throws Exception
     */
    public List<Inventory> getInventoryList(int contractId , String customerId ,
                        int inventoryId , String contractCategory ,
                        User user , int limit , int index,String searchCriteria,String sortby,String direction)
                        throws BaseClassException
    {
        List<Inventory> inventories = null;
        logger.info(":::::::::::::::::::::: getInventoryList repository ::::::::::::::::::::::::");
        StringBuilder var = new StringBuilder();
        var.append(DSCConstants.ERROR);
        boolean isCustomerUser = user.isCustomerUser();
        
        
        StringBuilder query = new StringBuilder();
        
        query.append(DSCConstants.INVENTORY_SELECT_QUERY);
        
        if (contractId != 0)
        {
            query.append(DSCConstants.CONTRACTID_APPEND);
        }
        
        if (!customerId.isEmpty())
        {
            query.append(DSCConstants.CUSTOMERID_APPEND);
        }
        
        if (inventoryId != 0)
        {
            query.append(DSCConstants.INVENTORY_ID_APPEND);
        }
        
        if(isCustomerUser)
        {
            query.append(DSCConstants.UNIVERSAL_SECURITY_QUERY);
        }
        
        if (!searchCriteria.isEmpty()) {
            query.append(DSCConstants.SEARCH_CRITERIA_INVENTORY);
        }
        
        String mappedColumn = orderByColumnMap(sortby);
        if(mappedColumn.isEmpty()) {
            query.append(DSCConstants.INVENTORY_ORDERBY_APPEND);
        }else {
            query.append(DSCConstants.INVENTORY_ORDERBY_INQUERY);
            query.append(mappedColumn);
        }
        
        if(direction.isEmpty()) {
            query.append(DSCConstants.ASCDESC);  
        }else {
            query.append(" "+direction);  
        }
        
        if(limit > 0)
        {           
            query.append(DSCConstants.QUERY_LIMIT_APPEND);
        }
        
        try
        {
           
        
            PreparedStatementSetter pss = new PreparedStatementSetter() {
                public void setValues(PreparedStatement preparedStatement) throws SQLException {
                    int i = 0;
                    if (contractId != 0)
                    {
                        i++;
                        preparedStatement.setInt(i, contractId);
                    }
                    
                    if (!customerId.isEmpty())
                    {
                        i++;
                        preparedStatement.setString(i, customerId);
                    }
                    
                    if (inventoryId != 0)
                    {
                        i++;
                        preparedStatement.setInt(i, inventoryId);
                    }
                    
                    if(isCustomerUser)
                    {
                        i++;
                        preparedStatement.setString(i, user.getUserId());
                    }
                    
                    if (!searchCriteria.isEmpty())
                    {
                        i++;
                        preparedStatement.setString(i, "%"+searchCriteria.toUpperCase().concat("%"));
                        i++;
                        preparedStatement.setString(i, "%"+searchCriteria.toUpperCase().concat("%"));
                        i++;
                        preparedStatement.setString(i, "%"+searchCriteria.toUpperCase().concat("%"));
                        i++;
                        preparedStatement.setString(i, "%"+searchCriteria.toUpperCase().concat("%"));
                        i++;
                        preparedStatement.setString(i, "%"+searchCriteria.toUpperCase().concat("%"));
                    }
                    
                    if(limit > 0)
                    {
                        int offset = (index == 0) ? 0 : index - 1;
                        i++;
                        preparedStatement.setInt(i, limit);
                        i++;
                        preparedStatement.setInt(i, offset);
                    }
                  
                }
              };
            
            inventories = jdbcTemplate.query(query.toString(), pss,
                                new BeanPropertyRowMapper<Inventory>(
                                                    Inventory.class));
            
      
            
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return inventories;
    }
    
    public String orderByColumnMap(String sortby) {
        
        String mappedColumn = "";
        if(!sortby.isEmpty()) {
        if(sortby.equalsIgnoreCase("weightOut")) {
            mappedColumn = "weight_out";
        }else if(sortby.equalsIgnoreCase("vehicleNumber")) {
            mappedColumn = "vehicle_no";
        }else if(sortby.equalsIgnoreCase("packaging")) {
            mappedColumn = "packing";
        }else if(sortby.equalsIgnoreCase("vehicleType")) {
            mappedColumn = "vehicle_type";
        }else if(sortby.equalsIgnoreCase("location")) {
            mappedColumn = "location";
        }else if(sortby.equalsIgnoreCase("remarks")) {
            mappedColumn = "remarks";
        }else if(sortby.equalsIgnoreCase("weightIn")) {
            mappedColumn = "weight_in";
        }else if(sortby.equalsIgnoreCase("netWeight")) {
            mappedColumn = "net_weight";
        }else if(sortby.equalsIgnoreCase("deliveredVolume")) {
            mappedColumn = "delivered_volume";
        }else if(sortby.equalsIgnoreCase("timeInTime")) {
            mappedColumn = "time_in_time";
        }else if(sortby.equalsIgnoreCase("timeOutTime")) {
            mappedColumn = "time_out_time";
        }else if(sortby.equalsIgnoreCase("etaTime")) {
            mappedColumn = "eta_time";
        }else {
            mappedColumn = "";
        }
        }
        else {
            mappedColumn = "";
        }
        return mappedColumn;
    }
    
    /**
     * Method to insert inventory details
     * 
     * @param contractId
     * @param inventory
     * @param userid
     * @return
     * @throws Exception
     */
    public Inventory insertInventory(int contractId , Inventory inventory ,
                        String userid) throws BaseClassException
    {
        Date today = new java.util.Date();
        long t = today.getTime();
        int nextval = 0;
        logger.info(":::::::::::::::::::::: insertInventory repository ::::::::::::::::::::::::");
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            nextval = jdbcTemplate.queryForObject(
                                DSCConstants.INVENTORY_NEXTVAL, new Object[]
                                {}, Integer.class);
                                
            inventory.setResult(jdbcTemplate.update(
                                DSCConstants.INVENTORY_INSERT_QUERY,
                                new Object[]
                                { nextval, inventory.getCargo(),
                                                inventory.getVehicleType(),
                                                inventory.getVehicleNo(),
                                                inventory.getTimeInDate(),
                                                inventory.getTimeInTime(),
                                                inventory.getWeightIn(),
                                                inventory.getTimeOutDate(),
                                                inventory.getTimeOutTime(),
                                                inventory.getWeightOut(),
                                                inventory.getTotalWeight(),
                                                inventory.getPacking(),
                                                inventory.getMode(),
                                                inventory.getLocation(),
                                                inventory.getPickUpId(),
                                                inventory.getCakNo(),
                                                inventory.getRemarks(),
                                                contractId, userid,
                                                new java.sql.Date(t), userid,
                                                new java.sql.Date(t),
                                                inventory.getNetWeight(),
                                                inventory.getEtaDate(),
                                                inventory.getEtaTime(),
                                                inventory.getDeliveredVolume() }));
            if (inventory.getResult() > 0)
            {
                inventory.setNextval(nextval);
            }
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return inventory;
    }
    
    /**
     * Method to update inventory details
     * 
     * @param contractId
     * @param inventoryId
     * @param inventory
     * @param userid
     * @return
     * @throws BaseClassException
     */
    public int updateInventory(Inventory inventory , String userid)
                        throws BaseClassException
    {
        Date today = new java.util.Date();
        long t = today.getTime();
        int rsult = 0;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            logger.info(":::::::::::::::::::::: updateInventory repository ::::::::::::::::::::::::");
            // old
            rsult = jdbcTemplate.update(DSCConstants.INVENTORY_UPDATE_QUERY,
                                new Object[]
                                { inventory.getCargo(),
                                                inventory.getVehicleType(),
                                                inventory.getVehicleNo(),
                                                inventory.getTimeInDate(),inventory.getTimeInTime(),
                                                inventory.getWeightIn(),
                                                inventory.getTimeOutDate(),inventory.getTimeOutTime(),
                                                inventory.getWeightOut(),
                                                inventory.getTotalWeight(),
                                                inventory.getPacking(),
                                                inventory.getMode(),
                                                inventory.getLocation(),
                                                inventory.getPickUpId(),
                                                inventory.getCakNo(),
                                                inventory.getRemarks(), userid,
                                                new java.sql.Date(t),
                                                inventory.getNetWeight(),
                                                inventory.getEtaDate(),inventory.getEtaTime(),
                                                inventory.getDeliveredVolume(),
                                                inventory.getInventoryId() });
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return rsult;
    }

    /**
     * 
     * @param contractCategory
     * @param user
     * @return
     */
    public List<Summary> getSummaryAndTotalInventory(String contractCategory ,
                        User user,String searchCriteria,int contractId) throws BaseClassException
    {
        List<Inventory> list = null;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        long total = 0;
        long totalWeightBarge = 0;
        long totalWeightTruck = 0;
        List<Summary> summary = null;
        StringBuilder query = new StringBuilder();
        try {
           
        query.append(DSCConstants.INVENTORY_SUMMARY); 
        
        if (contractId != 0)
        {
            query.append(DSCConstants.CONTRACTID_APPEND);
        }
        
        if (!searchCriteria.isEmpty()) {
            query.append(DSCConstants.SEARCH_CRITERIA_INVENTORY);
        }
        
        query.append(DSCConstants.INVENTORY_SUMMARY_GRBY); 
        query.append(DSCConstants.INVENTORY_SUMMARY_ORBY); 
        
        
        PreparedStatementSetter pss = new PreparedStatementSetter()
        {
            public void setValues(PreparedStatement preparedStatement)
                                throws SQLException
            {
                int i = 0;
                if (contractId != 0)
                {
                    i++;
                    preparedStatement.setInt(i, contractId);
                }
                
                if (!searchCriteria.isEmpty())
                {
                    i++;
                    preparedStatement.setString(i, "%"+searchCriteria.toUpperCase().concat("%"));
                    i++;
                    preparedStatement.setString(i, "%"+searchCriteria.toUpperCase().concat("%"));
                    i++;
                    preparedStatement.setString(i, "%"+searchCriteria.toUpperCase().concat("%"));
                    i++;
                    preparedStatement.setString(i, "%"+searchCriteria.toUpperCase().concat("%"));
                    i++;
                    preparedStatement.setString(i, "%"+searchCriteria.toUpperCase().concat("%"));
                }
                
            }
        };
        
        list = jdbcTemplate.query(
                            query.toString(), pss,
                            new BeanPropertyRowMapper<Inventory>(
                                                Inventory.class));
        if(list != null) {
            summary = new ArrayList<>();
            for(Inventory inv: list) {
                if(inv.getVehicleType().equalsIgnoreCase("Barge")) {
                    totalWeightBarge = (long)inv.getNetWeight();
                    total += inv.getNetWeight(); 
                }
                if(inv.getVehicleType().equalsIgnoreCase("Truck")) {
                    totalWeightTruck =  (long)inv.getNetWeight();
                    total += inv.getNetWeight(); 
                }
            }
            summary.add(new Summary(totalWeightBarge, totalWeightTruck, total));
        }
        }catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return summary;
    }
    
    /**
     * This method is used to delete update set flag'N' inventory
     * 
     * @param contractId
     * @param userid
     */
    public int deleteInventory(int inventoryId ,String userid)
                        throws BaseClassException
    {
        Date today = new java.util.Date();
        long t = today.getTime();
        int rsult = 0;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            rsult = jdbcTemplate.update(DSCConstants.INVENTORY_DELETEUPDATE_QUERY,
                                new Object[]
                                { new java.sql.Date(t),  userid,inventoryId });
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return rsult;
    }
    
}
