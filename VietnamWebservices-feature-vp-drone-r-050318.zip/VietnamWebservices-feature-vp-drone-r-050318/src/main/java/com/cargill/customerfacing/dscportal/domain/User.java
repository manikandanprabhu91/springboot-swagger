package com.cargill.customerfacing.dscportal.domain;

import java.util.List;

public class User
{
    String userId;
    boolean isCustomerUser;
    List<String> roles;
    String accessToken;
    
    public String getAccessToken()
    {
        return accessToken;
    }
    public void setAccessToken(String accessToken)
    {
        this.accessToken = accessToken;
    }
    public String getUserId()
    {
        return userId;
    }
    public void setUserId(String userId)
    {
        this.userId = userId;
    }
    public boolean isCustomerUser()
    {
        return isCustomerUser;
    }
    public void setCustomerUser(boolean isCustomerUser)
    {
        this.isCustomerUser = isCustomerUser;
    }
    public List<String> getRoles()
    {
        return roles;
    }
    public void setRoles(List<String> roles)
    {
        this.roles = roles;
    }
    
    public User( String userId, boolean isCustomerUser)
    {
        this.userId = userId;
        this.isCustomerUser = isCustomerUser;
    }
    public User()
    {
      
    }
    
}
