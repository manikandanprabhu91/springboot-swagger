/*
 * PickUpScheduleController.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.webservices;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cargill.customerfacing.dscportal.domain.ArrivalSchedule;
import com.cargill.customerfacing.dscportal.domain.DSCConstants;
import com.cargill.customerfacing.dscportal.domain.PickUpSchedule;
import com.cargill.customerfacing.dscportal.domain.ResponseGateway;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.region.factory.RegionFactoryService;

import net.glxn.qrgen.QRCode;
import net.glxn.qrgen.image.ImageType;

@RestController
@EnableAutoConfiguration
@RequestMapping(value = "/api/dxo/dsc/v1/auth")
public class PickUpScheduleController
{
  
  private Logger logger = LoggerFactory.getLogger(PickUpScheduleController.class);
  
  @Autowired
  RegionFactoryService regionFactoryService;
  
  private ResponseGateway gateway;
  
  /**
   * Method to get pickupschedule list
   * 
   * @param contractId
   * @param contractCategory
   * @param userid
   * @return
   */
  @RequestMapping(value = "/pickUpScheduleList", method = RequestMethod.GET, produces = DSCConstants.APPLICATION_JSON)
  public ResponseEntity<ResponseGateway> getPickUpScheduleList(
            @RequestParam("contractId")
            int contractId , @RequestParam("contractCategory")
            String contractCategory , @RequestParam("userid")
            String userid) throws BaseClassException
  {
    gateway = new ResponseGateway();
    logger.info(":::::::::: getPickUpScheduleList :::::::::::::::");
    List<PickUpSchedule> pickUpSchedules = null;
    ResponseEntity<ResponseGateway> responseGateway = null;
    try
    {
      pickUpSchedules = regionFactoryService
                .getPickUpScheduleService(contractCategory)
                .getPickUpScheduleList(contractId, userid);
      if (pickUpSchedules != null && !pickUpSchedules.isEmpty())
      {
          responseGateway = gateway.buildResponse(pickUpSchedules, DSCConstants.SUCCESS, "", DSCConstants.CODE200, "");
      } else
      {
        responseGateway = gateway.buildResponse(pickUpSchedules, DSCConstants.FAIL, DSCConstants.NORESULT, DSCConstants.CODE200, DSCConstants.F101);
      }
    } catch (Exception e)
    {
        responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
    }
    return responseGateway;
  }
  
  /**
   * Method to insert pickupschedule record
   * 
   * @param pickUpSchedule
   * @param contractCategory
   * @param userid
   * @return
   */
  @RequestMapping(value = "/pickUpSchedule", method = RequestMethod.POST, produces = DSCConstants.APPLICATION_JSON, consumes = DSCConstants.APPLICATION_JSON)
  public ResponseEntity<ResponseGateway> insertPickUpSchedule(@RequestBody
  PickUpSchedule pickUpSchedule , @RequestParam("contractCategory")
  String contractCategory , @RequestParam("userid")
  String userid) throws BaseClassException
  {
    gateway = new ResponseGateway();
    logger.info(":::::::::: insertPickUpSchedule :::::::::::::::");
    ResponseEntity<ResponseGateway> responseGateway = null;
    PickUpSchedule pickUpSchedule1 = null; 
    try
    {
        pickUpSchedule1 = regionFactoryService
                .getPickUpScheduleService(contractCategory)
                .insertPickUpSchedule(pickUpSchedule, userid,contractCategory);
      if (pickUpSchedule1.getResult() > 0)
      {
        responseGateway = gateway.buildResponse(null, DSCConstants.SUCCESS, DSCConstants.SUCCESS_SAVE, DSCConstants.CODE200, String.valueOf(pickUpSchedule1.getNextval()));
      } else if (pickUpSchedule1.getResult() < 0)
      {
          responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.VESSEL_APPROVEDQTY_ERROR, DSCConstants.CODE200, DSCConstants.F203);
      } else
      {
        responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.NOTUPDATED, DSCConstants.CODE200, DSCConstants.F102);
      }
    } catch (Exception e)
    {
        responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
    }
    return responseGateway;
  }
  
  /**
   * Method to get pickupschedule by id
   * 
   * @param contractId
   * @param contractCategory
   * @param pickupId
   * @return
   * @throws Exception
   */
  @RequestMapping(value = "/pickUpScheduleBYID", method = RequestMethod.GET, produces = DSCConstants.APPLICATION_JSON)
  public ResponseEntity<ResponseGateway> getPickUpScheduleBYID(
            @RequestParam("contractId")
            int contractId , @RequestParam("contractCategory")
            String contractCategory , @RequestParam("pickupid")
            int pickupId) throws BaseClassException
  {
    gateway = new ResponseGateway();
    logger.info(":::::::::: getPickUpScheduleBYID :::::::::::::::");
    ResponseEntity<ResponseGateway> responseGateway = null;
    List<PickUpSchedule> pickUpSchedule = null;
    try
    {
      pickUpSchedule = regionFactoryService
                .getPickUpScheduleService(contractCategory)
                .getPickUpScheduleBYID(contractId, pickupId);
      if (pickUpSchedule != null)
      {
        responseGateway = gateway.buildResponse(pickUpSchedule, DSCConstants.SUCCESS, "", DSCConstants.CODE200, "");
      } else
      {
          responseGateway = gateway.buildResponse(pickUpSchedule, DSCConstants.FAIL, DSCConstants.NORESULT, DSCConstants.CODE200, DSCConstants.F101);
      }
    } catch (Exception e)
    {
        responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
    }
    return responseGateway;
  }
  
  /**
   * Method to update pickupschedule details
   * 
   * @param contractId
   * @param pickUpSchedule
   * @param contractCategory
   * @param userid
   * @return
   * @throws BaseClassException
   */
  @RequestMapping(value = "/updatePickUpSchedule", method = RequestMethod.PATCH, produces = DSCConstants.APPLICATION_JSON)
  public ResponseEntity<ResponseGateway> updatePickUpSchedule(
            @RequestParam("contractId")
            int contractId , @RequestBody
            PickUpSchedule pickUpSchedule , @RequestParam("contractCategory")
            String contractCategory , @RequestParam("userid")
            String userid) throws BaseClassException
  {
    gateway = new ResponseGateway();
    ResponseEntity<ResponseGateway> responseGateway = null;
    int updatestaus = 0;
    try
    {
      logger.info(":::::::::: updatePickUpSchedule :::::::::::::::");
      updatestaus = regionFactoryService
                .getPickUpScheduleService(contractCategory)
                .updatePickUpSchedule(pickUpSchedule, contractId, userid,contractCategory);
      if (updatestaus > 0)
      {
          responseGateway = gateway.buildResponse(null, DSCConstants.SUCCESS, DSCConstants.SUCCESS_UPDATE, DSCConstants.CODE200, String.valueOf(pickUpSchedule.getPickUpId()));
      }else if (updatestaus < 0)
      {
          responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.VESSEL_APPROVEDQTY_ERROR, DSCConstants.CODE200, DSCConstants.F203);
      } else
      {
          responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.NOTUPDATED, DSCConstants.CODE200, DSCConstants.F102); 
      }
    } catch (Exception e)
    {
        responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
    }
    return responseGateway;
  }
  
  /**
   * Method to delete pickupschedule details
   * 
   * @param contractId
   * @param contractCategory
   * @param userid
   * @param pickupid
   * @return
   * @throws BaseClassException
   */
  @RequestMapping(value = "/pickUpSchedule", method = RequestMethod.DELETE, produces = DSCConstants.APPLICATION_JSON)
  public ResponseEntity<ResponseGateway> deletePickUpSchedule(
            @RequestParam("contractId")
            int contractId , @RequestParam("contractCategory")
            String contractCategory , @RequestParam("userid")
            String userid , @RequestParam("pickupid")
            int pickupid) throws BaseClassException
  {
    gateway = new ResponseGateway();
    ResponseEntity<ResponseGateway> responseGateway = null;
    int delstatus = 0;
    try
    {
      logger.info(":::::::::: deletePickUpSchedule :::::::::::::::");
      delstatus = regionFactoryService
                .getPickUpScheduleService(contractCategory)
                .deletePickUpSchedule(contractId, userid, pickupid);
      if (delstatus > 0)
      {
          responseGateway = gateway.buildResponse(null, DSCConstants.SUCCESS, DSCConstants.SUCCESS_UPDATE, DSCConstants.CODE200, String.valueOf(pickupid));
      } else
      {
          responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.NOTUPDATED, DSCConstants.CODE200, DSCConstants.F102); 
      }
    } catch (Exception e)
    {
        responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
    }
    return responseGateway;
  }
  
  /**
   * Method to download QR code
   * 
   * @param contractId
   * @param approvedQuantityId
   * @param response
   * @throws IOException
   */
  @RequestMapping(value = "/generateQRCode/{contractId}/{pickUpId}/{contractCategory}", method = RequestMethod.GET)
  public @ResponseBody
  void generateQRCode(@PathVariable("contractId")
  int contractId , @PathVariable("pickUpId")
  int pickUpId ,@PathVariable("contractCategory")
  String contractCategory , HttpServletResponse response) throws IOException,BaseClassException
  {
    logger.info(":::::::::: generateQRCode :::::::::::::::");
    try
    {
    ArrivalSchedule arrivalSchedule = regionFactoryService
                        .getPickUpScheduleService(contractCategory)
                        .generateQRCode(contractId, pickUpId);
    if(arrivalSchedule!=null) {
        String encodeValues = "cakNo: " + arrivalSchedule.getCakNo() + ";" + " commodity Type:"
                            + arrivalSchedule.getCommodity() + "; " + "Approved Quantity:" + arrivalSchedule.getApprovedQuantity();
    
    response.setContentType("image/png");
    response.setHeader("Content-Disposition", "inline; filename=qr-code.png");
    ByteArrayOutputStream bout = QRCode.from(encodeValues).withSize(250, 250)
              .to(ImageType.PNG).stream();
    
      OutputStream out = response.getOutputStream();
      out.write(bout.toByteArray());
      out.flush();
      out.close();
    }else {
        logger.error("arrivalSchedulelistempty");  
    }
    } catch (FileNotFoundException e)
    {
      logger.error("FileNotFoundException", e.getMessage());
    } catch (IOException e)
    {
      logger.error("IOException", e.getMessage());
    } catch (Exception e)
    {
      logger.error("Exception", e.getMessage());
    }
  }
}
