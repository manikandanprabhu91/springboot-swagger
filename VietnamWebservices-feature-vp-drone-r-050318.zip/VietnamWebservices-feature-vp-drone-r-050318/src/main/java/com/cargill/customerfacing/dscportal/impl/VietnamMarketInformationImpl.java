/*
 * VietnamMarketInformationImpl.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cargill.customerfacing.dscportal.domain.MarketInformation;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.repository.MarketInformationRepository;
import com.cargill.customerfacing.dscportal.service.IMarketInformation;

@Service
public class VietnamMarketInformationImpl implements IMarketInformation
{
    
    @Autowired
    MarketInformationRepository marketInformationRepository;
    
    @Override
    public MarketInformation insertMarketInformation(MarketInformation marketInformation ,
                        String userid , String contractCategory)
                        throws BaseClassException
    {
        return marketInformationRepository.insertMarketInformation(
                            marketInformation, userid, contractCategory);
    }
    
    @Override
    public int updateMarketInformation(MarketInformation marketInformation ,
                        String userid , String contractCategory)
                        throws BaseClassException
    {
        return marketInformationRepository.updateMarketInformation(
                            marketInformation, userid,
                            contractCategory);
        
    }
    
    @Override
    public int deleteMarketInformation(int marketId , String userid)
                        throws BaseClassException
    {
        return marketInformationRepository.deleteMarketInformation(marketId,
                            userid);
    }
    
    @Override
    public List<MarketInformation> getMarketInfoList(String contractCategory)
                        throws BaseClassException
    {
        return marketInformationRepository.getMarketInfoList(contractCategory);
    }
    
}
