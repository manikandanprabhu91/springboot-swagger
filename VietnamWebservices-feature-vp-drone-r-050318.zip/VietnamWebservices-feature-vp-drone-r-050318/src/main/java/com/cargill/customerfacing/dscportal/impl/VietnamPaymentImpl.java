/*
 * VietnamPaymentImpl.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cargill.customerfacing.dscportal.domain.ApprovedQuantity;
import com.cargill.customerfacing.dscportal.domain.Payment;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.repository.PaymentRepository;
import com.cargill.customerfacing.dscportal.service.IPaymentService;

@Service
public class VietnamPaymentImpl implements IPaymentService
{
    
    @Autowired
    PaymentRepository paymentRepository;
    
    @Override
    public List<Payment> getPaymentList(int contractId , String userid)
                        throws BaseClassException
    {
        return paymentRepository.getPaymentList(contractId, userid);
    }
    
    @Override
    public Payment insertPayment(Payment payment , String userid)
                        throws BaseClassException
    {
        return paymentRepository.insertPayment(payment, userid);
    }
    
    @Override
    public int updatePayment(Payment payment , String userid,String contractCategory)
                        throws BaseClassException
    {
        return paymentRepository.updatePayment(payment, userid,contractCategory);
    }
    
    @Override
    public int deletePayment(int contractId , int paymentID , String userid)
                        throws BaseClassException
    {
        return paymentRepository.deletePayment(contractId, paymentID, userid);
    }
    
    @Override
    public ApprovedQuantity updateApprovedQuantity(ApprovedQuantity approvedQuantity ,
                        String userid,String contractCategory) throws BaseClassException
    {
        return paymentRepository.updateApprovedQuantity(approvedQuantity,
                            userid,contractCategory);
    }
    
    @Override
    public ApprovedQuantity getApprovedQuantityList(int contractId)
                        throws BaseClassException
    {
        return paymentRepository.getApprovedQuantityList(contractId);
    }
}
