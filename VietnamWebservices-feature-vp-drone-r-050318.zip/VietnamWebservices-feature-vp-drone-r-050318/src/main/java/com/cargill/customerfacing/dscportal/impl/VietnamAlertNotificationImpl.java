/*
 * VietnamAlertNotificationImpl.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cargill.customerfacing.dscportal.domain.SetUpAlert;
import com.cargill.customerfacing.dscportal.domain.UserAlertMapping;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.repository.AlertNotificationRepository;
import com.cargill.customerfacing.dscportal.service.IAlertNotification;

@Service
public class VietnamAlertNotificationImpl implements IAlertNotification
{
    
    @Autowired
    AlertNotificationRepository alertNotificationRepository;
    
    @Override
    public SetUpAlert setupAlert(int alertCode , String contractCategory ,
                        String customerId , String userid , int contractId ,
                        int paymentId , int invoiceId,int addon) throws BaseClassException
    {
        return alertNotificationRepository.setupAlert(alertCode,
                            contractCategory, customerId, userid, contractId,
                            paymentId, invoiceId,addon);
    }
    
    @Override
    public List<SetUpAlert> getAlertList(String contractCategory ,
                        String userId,
                        int limit, int offset) throws BaseClassException
    {
        return alertNotificationRepository.getAlertList(contractCategory,
                            userId,
                            limit, offset);
    }
    
    @Override
    public int getAlertCount(String contractCategory ,
                        String userId) throws BaseClassException
    {
        return alertNotificationRepository.getAlertCount(contractCategory,
                            userId);
    }
    
    @Override
    public int updateAlert(int actualAlertId , String alertStatus ,
                        String userid) throws BaseClassException
    {
        return alertNotificationRepository.updateAlert(actualAlertId,
                            alertStatus, userid);
    }
    
    @Override
    public List<UserAlertMapping> getAlertUserMappingList(
                        String contractCategory , String userId)
                        throws BaseClassException
    {
        return alertNotificationRepository
                            .getAlertUserMappingList(contractCategory, userId);
    }
    
    @Override
    public int updateAlertUserMapping(UserAlertMapping userAlertMapping ,
                         String contractCategory ,
                        String userid) throws BaseClassException
    {
        return alertNotificationRepository.updateAlertUserMapping(
                            userAlertMapping, contractCategory,
                            userid);
    }
}
