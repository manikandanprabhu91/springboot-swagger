/*
 * VietnamInvoiceImpl.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cargill.customerfacing.dscportal.domain.Invoice;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.repository.InvoiceRepository;
import com.cargill.customerfacing.dscportal.service.IInvoice;
import com.cargill.customerfacing.dscportal.domain.User;

@Service
public class VietnamInvoiceImpl implements IInvoice
{
  
  @Autowired
  InvoiceRepository invoiceRepository;
  
  public List<Invoice> getInvoiceList(int contractId , String userid,String customerId,
                      String customerName,int invoiceId,int limit,int offset,int month,int year,String direction)
            throws BaseClassException
  {
    return invoiceRepository.getInvoiceList(contractId, userid, customerId,customerName, invoiceId,limit,offset,month,year,direction);
  }
  
  public Invoice insertInvoice( Invoice invoice , String userid)
            throws BaseClassException
  {
    return invoiceRepository.insertInvoice(invoice, userid);
  }
  
  public int updateInvoice(Invoice invoice , String userid)
            throws BaseClassException
  {
    return invoiceRepository.updateInvoice(invoice, userid);
  }
  
  public int deleteInvoice(int invoiceId , String userid) throws BaseClassException {
      return invoiceRepository.deleteInvoice(invoiceId, userid);
  }
  
}
