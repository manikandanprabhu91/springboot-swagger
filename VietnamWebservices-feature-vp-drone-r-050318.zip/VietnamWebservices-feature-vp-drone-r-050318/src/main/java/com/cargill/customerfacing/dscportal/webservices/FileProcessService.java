//package com.cargill.customerfacing.dscportal.webservices;
//
//import java.io.IOException;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RequestPart;
//import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.multipart.MultipartFile;
//
//import com.cargill.customerfacing.dscportal.wrapper.AmazonS3Wrapper;
//
///**
// * This class is used to read/write/delete(Upload and download the file) the file from the AWS S3 bucket.
// * @author m160511 (Manikandan Prabhu D)
// *
// */
//@RestController
//@EnableAutoConfiguration
//@RequestMapping(value = "/api/dxo/dsc/v1/auth")
//public class FileProcessService {
//
//	@Autowired
//	private AmazonS3Wrapper amazonClient;
//	
//    /**
//     * This method is used to uploading the file to AWS S3 bucket.
//     * @param file
//     * @return message
//     */
//	@RequestMapping(value="/upload", method=RequestMethod.POST)
//	public @ResponseBody String uploadFile(@RequestParam("file") MultipartFile file) {
//		return amazonClient.uploadFile(file);
//	}
//	
//	/**
//	 * This method is used to download the file from the AWS S3 bucket.
//	 * @param key
//	 * @return byte array
//	 * @throws IOException
//	 */
//	@RequestMapping(value = "/download", method=RequestMethod.GET)
//	public ResponseEntity<byte[]> download(@RequestParam String key) throws IOException {
//		return amazonClient.download(key);
//	}
//	
//	/**
//	 * This method is used to delete the file from AWS S3 bucket.
//	 * @param fileUrl
//	 * @return
//	 */
//	@RequestMapping(value="/delete", method=RequestMethod.DELETE)
//	public @ResponseBody String deleteFile(@RequestPart(value = "url") String fileUrl) {
//		return amazonClient.deleteFileFromS3Bucket(fileUrl);
//	}
//
//}
