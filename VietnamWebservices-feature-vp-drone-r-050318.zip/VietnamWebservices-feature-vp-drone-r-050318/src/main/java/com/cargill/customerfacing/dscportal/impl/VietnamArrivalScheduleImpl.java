/*
 * VietnamArrivalScheduleImpl.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cargill.customerfacing.dscportal.domain.ArrivalSchedule;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.repository.ArrivalScheduleRepository;
import com.cargill.customerfacing.dscportal.service.IArrivalSchedule;

@Service
public class VietnamArrivalScheduleImpl implements IArrivalSchedule
{
    
    @Autowired
    ArrivalScheduleRepository arrivalScheduleRepository;
    
    @Override
    public ArrivalSchedule insertArrivalSchedule(ArrivalSchedule arrivalSchedule ,
                        String userid,String contractCategory) throws BaseClassException
    {
        return arrivalScheduleRepository.insertArrivalSchedule(arrivalSchedule,
                            userid,contractCategory);
    }
    
    @Override
    public int updateArrivalSchedule(ArrivalSchedule arrivalSchedule ,
                        String userid,String contractCategory) throws BaseClassException
    {
        return arrivalScheduleRepository.updateArrivalSchedule(arrivalSchedule,
                            userid,contractCategory);
    }
    
    @Override
    public int deleteArrivalSchedule(int arrivalScheduleId , int contractId)
                        throws BaseClassException
    {
        return arrivalScheduleRepository.deleteArrivalSchedule(
                            arrivalScheduleId, contractId);
    }
    
    @Override
    public List<ArrivalSchedule> getArrivalScheduleList(int contractId ,
                        String userid, String basiscode) throws BaseClassException
    {
        return arrivalScheduleRepository
                            .getArrivalScheduleList(contractId, userid,basiscode);
    }
}
