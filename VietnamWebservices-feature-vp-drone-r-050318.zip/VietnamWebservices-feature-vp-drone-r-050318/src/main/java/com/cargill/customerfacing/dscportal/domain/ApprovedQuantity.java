/*
 * ApprovedQuantity.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.domain;

public class ApprovedQuantity extends BaseModel
{
  
  private int approvedQuantityId;
  private int approvedQty;
  private int contractId;
  private int result;
  private int totalContractQTY;
  
  public int getApprovedQuantityId()
  {
    return approvedQuantityId;
  }
  public void setApprovedQuantityId(int approvedQuantityId)
  {
    this.approvedQuantityId = approvedQuantityId;
  }
  
  public int getApprovedQty()
  {
    return approvedQty;
  }
  public void setApprovedQty(int approvedQty)
  {
    this.approvedQty = approvedQty;
  }
  public int getContractId()
  {
    return contractId;
  }
  public void setContractId(int contractId)
  {
    this.contractId = contractId;
  }
public int getResult()
{
    return result;
}
public void setResult(int result)
{
    this.result = result;
}
public int getTotalContractQTY()
{
    return totalContractQTY;
}
public void setTotalContractQTY(int totalContractQTY)
{
    this.totalContractQTY = totalContractQTY;
}
  
}
