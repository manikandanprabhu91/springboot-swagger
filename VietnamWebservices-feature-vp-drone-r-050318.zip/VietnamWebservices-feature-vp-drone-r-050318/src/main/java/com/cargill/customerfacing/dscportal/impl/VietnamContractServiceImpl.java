/*
 * VietnamContractServiceImpl.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cargill.customerfacing.dscportal.domain.Contract;
import com.cargill.customerfacing.dscportal.domain.Customer;
import com.cargill.customerfacing.dscportal.domain.Status;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.repository.ContractRepository;
import com.cargill.customerfacing.dscportal.service.IContractService;

@Service
public class VietnamContractServiceImpl implements IContractService
{
    
    @Autowired
    ContractRepository contractRepository;
    
    @Override
    public List<Contract> getContractlist(String contractType ,
                        String contractStatus , String contractCategory ,
                        String userid , String searchCriteria , int startindex ,
                        int limit) throws BaseClassException
    {
        return contractRepository.getContractlist(contractType, contractStatus,
                            contractCategory, userid, searchCriteria,
                            startindex, limit);
    }
    
    @Override
    public int getContractTotal(String contractType , String contractStatus ,
                        String contractCategory , String userid ,
                        String searchCriteria) throws BaseClassException{
        return contractRepository.getContractTotal(contractType, contractStatus,
                            contractCategory, userid, searchCriteria);
    }
    
    @Override
    public List<Contract> getContract(int contractId , String contractCategory ,
                        String userid) throws BaseClassException
    {
        return contractRepository.getContract(contractId, contractCategory,
                            userid);
    }
    
    @Override
    public Contract insertContract(Contract contract , String userid ,
                        String contractCategory) throws BaseClassException
    {
        return contractRepository.insertContract(contract, userid,
                            contractCategory);
    }
    
    @Override
    public int updateContract(Contract contract , int contractId ,
                        String userid) throws BaseClassException
    {
        return contractRepository.updateContract(contract, contractId, userid);
    }
    
    @Override
    public int deleteContract(int contractId , String userid)
                        throws BaseClassException
    {
        return contractRepository.deleteContract(contractId, userid);
    }
    
    @Override
    public List<Status> getStatusList(String screen) throws BaseClassException
    {
        return contractRepository.getStatusList(screen);
    }
    
    @Override
    public List<Customer> getCustomerList(String contractCategory)
                        throws BaseClassException
    {
        return contractRepository.getCustomerList(contractCategory);
    }
}
