/*
 * VietnamPickUpScheduleImpl.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cargill.customerfacing.dscportal.domain.ArrivalSchedule;
import com.cargill.customerfacing.dscportal.domain.PickUpSchedule;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.repository.PickUpScheduleRepository;
import com.cargill.customerfacing.dscportal.service.IPickUpSchedule;

@Service
public class VietnamPickUpScheduleImpl implements IPickUpSchedule
{
  
  @Autowired
  PickUpScheduleRepository pickUpScheduleRepository;
  
  @Override
  public PickUpSchedule insertPickUpSchedule(PickUpSchedule pickUpSchedule , String userid,String contractCategory)
            throws BaseClassException
  {
    return pickUpScheduleRepository.insertPickUpSchedule(pickUpSchedule,
              userid,contractCategory);
  }
  
  @Override
  public ArrivalSchedule generateQRCode(int contractId , int pickUpId) throws BaseClassException
  {
      return pickUpScheduleRepository.generateQRCode(contractId,
                          pickUpId); 
  }
  
  @Override
  public List<PickUpSchedule> getPickUpScheduleList(int contractId ,
            String userid) throws BaseClassException
  {
    return pickUpScheduleRepository.getPickUpScheduleList(contractId, userid);
  }
  
  @Override
  public List<PickUpSchedule> getPickUpScheduleBYID(int contractId , int pickupId)
            throws BaseClassException
  {
    return pickUpScheduleRepository.getPickUpScheduleBYID(contractId, pickupId);
  }
  
  @Override
  public int updatePickUpSchedule(PickUpSchedule pickUpSchedule ,
            int contractId , String userid,String contractCategory) throws BaseClassException
  {
    return pickUpScheduleRepository.updatePickUpSchedule(pickUpSchedule,
              contractId, userid,contractCategory);
  }
  
  @Override
  public int deletePickUpSchedule(int contractId , String userid , int pickupid)
            throws BaseClassException
  {
    return pickUpScheduleRepository.deletePickUpSchedule(contractId, userid,
              pickupid);
  }
}
