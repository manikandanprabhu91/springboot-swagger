/*
 * Payment.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class Payment extends BaseModel
{
    
    private String statusDesc;
    private String paymentDate;
    private double paymentAmount;
    private String statusDescription;
    private String statusCode;
    private int contractId;
    @JsonIgnoreProperties
    private String file;
    private int paymentId;
    private String paymentStatus;
    private String flag;
    private String status;
    private String bankName;
    private String branchName;
    private String transactionRef;
    private String time;
    private int result;
    private int nextval;
    private String contractCategory;
    private String customerId;
    
    public String getPaymentDate()
    {
        return paymentDate;
    }
    public void setPaymentDate(String paymentDate)
    {
        this.paymentDate = paymentDate;
    }
    
    
    public double getPaymentAmount()
    {
        return paymentAmount;
    }
    public void setPaymentAmount(double paymentAmount)
    {
        this.paymentAmount = paymentAmount;
    }
    public int getContractId()
    {
        return contractId;
    }
    public void setContractId(int contractId)
    {
        this.contractId = contractId;
    }
    public String getFile()
    {
        return file;
    }
    public void setFile(String file)
    {
        this.file = file;
    }
    public String getStatusCode()
    {
        return statusCode;
    }
    public void setStatusCode(String statusCode)
    {
        this.statusCode = statusCode;
    }
    public int getPaymentId()
    {
        return paymentId;
    }
    public void setPaymentId(int paymentId)
    {
        this.paymentId = paymentId;
    }
    public String getPaymentStatus()
    {
        return paymentStatus;
    }
    public void setPaymentStatus(String paymentStatus)
    {
        this.paymentStatus = paymentStatus;
    }
    public String getFlag()
    {
        return flag;
    }
    public void setFlag(String flag)
    {
        this.flag = flag;
    }
    public String getStatus()
    {
        return status;
    }
    public void setStatus(String status)
    {
        this.status = status;
    }
    public String getBankName()
    {
        return bankName;
    }
    public void setBankName(String bankName)
    {
        this.bankName = bankName;
    }
    public String getBranchName()
    {
        return branchName;
    }
    public void setBranchName(String branchName)
    {
        this.branchName = branchName;
    }
    public String getTransactionRef()
    {
        return transactionRef;
    }
    public void setTransactionRef(String transactionRef)
    {
        this.transactionRef = transactionRef;
    }
    public String getTime()
    {
        return time;
    }
    public void setTime(String time)
    {
        this.time = time;
    }
    public int getResult()
    {
        return result;
    }
    public void setResult(int result)
    {
        this.result = result;
    }
    public int getNextval()
    {
        return nextval;
    }
    public void setNextval(int nextval)
    {
        this.nextval = nextval;
    }
    public String getStatusDesc()
    {
        return statusDesc;
    }
    public void setStatusDesc(String statusDesc)
    {
        this.statusDesc = statusDesc;
    }
    public String getStatusDescription()
    {
        return statusDescription;
    }
    public void setStatusDescription(String statusDescription)
    {
        this.statusDescription = statusDescription;
    }
    public String getContractCategory()
    {
        return contractCategory;
    }
    public void setContractCategory(String contractCategory)
    {
        this.contractCategory = contractCategory;
    }
    public String getCustomerId()
    {
        return customerId;
    }
    public void setCustomerId(String customerId)
    {
        this.customerId = customerId;
    }
    
}
