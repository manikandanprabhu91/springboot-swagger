/*
 * VietnamInventoryServiceImpl.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cargill.customerfacing.dscportal.domain.Inventory;
import com.cargill.customerfacing.dscportal.domain.Summary;
import com.cargill.customerfacing.dscportal.domain.User;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.repository.InventoryRepository;
import com.cargill.customerfacing.dscportal.service.IInventory;

@Service
public class VietnamInventoryServiceImpl implements IInventory
{
  
  @Autowired
  InventoryRepository inventoryRepository;
  
  public List<Inventory> getInventoryList(int contractId , String customerId ,
            int inventoryId , String contractCategory , User user,int limit,int offset,String searchCriteria,String sortby,String direction)
            throws BaseClassException
  {
    return inventoryRepository.getInventoryList(contractId, customerId,
              inventoryId, contractCategory, user,limit,offset,searchCriteria,sortby,direction);
  }
  
  public Inventory insertInventory(int contractId , Inventory inventory ,
            String userid) throws BaseClassException
  {
    return inventoryRepository.insertInventory(contractId, inventory, userid);
  }
  
  public int updateInventory(Inventory inventory , String userid) throws BaseClassException
  {
    return inventoryRepository.updateInventory(inventory, userid);
  }
  
  public List<Summary> getSummaryAndTotalInventory(String contractCategory ,
                      User user,String searchCriteria,int contractId) throws BaseClassException {
      return inventoryRepository.getSummaryAndTotalInventory(contractCategory, user,searchCriteria,contractId);
  }
  
  public int deleteInventory(int inventoryId ,
                      String userid) throws BaseClassException
            {
              return inventoryRepository.deleteInventory(inventoryId, userid);
            }
}
