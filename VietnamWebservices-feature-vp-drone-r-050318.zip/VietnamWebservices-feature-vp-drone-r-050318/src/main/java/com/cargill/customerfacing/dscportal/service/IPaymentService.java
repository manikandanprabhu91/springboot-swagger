/*
 * IPaymentService.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.service;

import java.util.List;

import com.cargill.customerfacing.dscportal.domain.ApprovedQuantity;
import com.cargill.customerfacing.dscportal.domain.Payment;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;

public interface IPaymentService
{
    
    public List<Payment> getPaymentList(int contractId , String userid)
                        throws BaseClassException;
    
    public Payment insertPayment(Payment payment , String userid)
                        throws BaseClassException;
    
    public int updatePayment(Payment payment , String userid,String contractCategory)
                        throws BaseClassException;
    
    public int deletePayment(int contractId , int paymentID , String userid)
                        throws BaseClassException;
    
    public ApprovedQuantity updateApprovedQuantity(ApprovedQuantity approvedQuantity ,
                        String userid,String contractCategory) throws BaseClassException;
    
    public ApprovedQuantity getApprovedQuantityList(int contractId)
                        throws BaseClassException;
}
