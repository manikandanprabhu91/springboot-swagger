/*
 * IArrivalSchedule.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.service;

import java.util.List;

import com.cargill.customerfacing.dscportal.domain.ArrivalSchedule;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;

public interface IArrivalSchedule
{
    
    public ArrivalSchedule insertArrivalSchedule(ArrivalSchedule arrivalSchedule ,
                        String userid,String contractCategory) throws BaseClassException;
    
    public int updateArrivalSchedule(ArrivalSchedule arrivalSchedule ,
                        String userid,String contractCategory) throws BaseClassException;
    
    public int deleteArrivalSchedule(int arrivalScheduleId , int contractId)
                        throws BaseClassException;
    
    public List<ArrivalSchedule> getArrivalScheduleList(int contractId ,
                        String userid, String basiscode) throws BaseClassException;
}
