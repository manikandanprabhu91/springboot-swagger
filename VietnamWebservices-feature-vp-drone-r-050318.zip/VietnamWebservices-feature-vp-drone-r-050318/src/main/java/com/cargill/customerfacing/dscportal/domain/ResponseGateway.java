/*
 * ResponseGateway.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.domain;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class ResponseGateway
{
  
  private String statusCode;
  private List<?> message;
  private String status;
  private String statusMessage;
  private String code;
  
  public String getStatusCode()
  {
    return statusCode;
  }
  public void setStatusCode(String statusCode)
  {
    this.statusCode = statusCode;
  }
  public List<?> getMessage()
  {
    return message;
  }
  public void setMessage(List<?> message)
  {
    this.message = message;
  }
  public String getStatus()
  {
    return status;
  }
  public void setStatus(String status)
  {
    this.status = status;
  }
 
public String getCode()
{
    return code;
}
public void setCode(String code)
{
    this.code = code;
}

public String getStatusMessage()
{
    return statusMessage;
}
public void setStatusMessage(String statusMessage)
{
    this.statusMessage = statusMessage;
}
  

public ResponseEntity<ResponseGateway> buildResponse(List<?> message, String status, String statusMessage, String statusCode, String code)
  {
      ResponseEntity<ResponseGateway> responseGateway = new ResponseEntity<>(
                          this, HttpStatus.OK);
      
          this.setStatusCode(statusCode);
          this.setStatus(status);
          this.setMessage(message);
          this.setStatusMessage(statusMessage);
          this.setCode(code);
      
          return responseGateway;
  }

}
