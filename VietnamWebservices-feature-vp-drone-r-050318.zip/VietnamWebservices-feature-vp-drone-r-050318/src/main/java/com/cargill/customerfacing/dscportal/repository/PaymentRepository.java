/*
 * PaymentRepository.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.repository;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cargill.customerfacing.dscportal.domain.ApprovedQuantity;
import com.cargill.customerfacing.dscportal.domain.Contract;
import com.cargill.customerfacing.dscportal.domain.DSCConstants;
import com.cargill.customerfacing.dscportal.domain.Payment;
import com.cargill.customerfacing.dscportal.domain.SetUpAlert;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;

@Repository
public class PaymentRepository
{
    
    private static Logger logger = LoggerFactory
                        .getLogger(PaymentRepository.class);
    
    @Autowired
    JdbcTemplate jdbcTemplate;
    
    @Autowired
    AlertNotificationRepository alertNotificationRepository;
    
    /**
     * Method to get payment list
     * 
     * @param contractId
     * @param userid
     * @return
     */
    public List<Payment> getPaymentList(int contractId , String userid)
                        throws BaseClassException
    {
        List<Payment> paymentlist = null;
        logger.info(":::::::::::::::::::::: getPaymentList repository ::::::::::::::::::::::::");
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            paymentlist = jdbcTemplate.query(DSCConstants.PAYMENT_SELECT_QUERY,
                                new Object[]
                                { contractId },
                                new BeanPropertyRowMapper<Payment>(
                                                    Payment.class));
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return paymentlist;
    }
    
    /**
     * Method to insert payment details
     * 
     * @param payment
     * @param userid
     * @return
     * @throws BaseClassException
     */
    public Payment insertPayment(Payment payment , String userid)
                        throws BaseClassException
    {
        Date today = new java.util.Date();
        long t = today.getTime();
        String statuscode = "";
        int rsult = 0;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        int nextval = 0;
        logger.info(":::::::::::::::::::::: insertPayment repository ::::::::::::::::::::::::");
        try
        {
            Payment contr = jdbcTemplate.queryForObject(
                                DSCConstants.GET_PAYMENT_STATUSTYPE,
                                new BeanPropertyRowMapper<Payment>(
                                                    Payment.class),
                                new Object[]
                                { payment.getStatusDescription() });
            if (contr != null)
            {
                // statuscode = contr.getStatusCode();
                statuscode = "VF";
            }
            logger.info(":::::::::::::::::::::: insertPayment repositoryq ::::::::::::::::::::::::");
            
            nextval = jdbcTemplate.queryForObject(DSCConstants.PAYMENT_NEXTVAL,
                                new Object[]
                                {}, Integer.class);
                                
            rsult = jdbcTemplate.update(DSCConstants.PAYMENT_INSERT_QUERY,
                                new Object[]
                                { nextval, statuscode, payment.getPaymentDate(),
                                                payment.getPaymentAmount(), "",
                                                userid, new java.sql.Date(t),
                                                userid, new java.sql.Date(t),
                                                "Y", payment.getContractId(),
                                                payment.getBankName(),
                                                payment.getBranchName(),
                                                payment.getTransactionRef(),
                                                payment.getTime() });
                                
            if (rsult == 1) // To DO : to handle when diffAmt is 0
            {
                payment.setNextval(nextval);
                Payment paytotalamt = jdbcTemplate.queryForObject(
                                    DSCConstants.PAYMENT_DIFF,
                                    new BeanPropertyRowMapper<Payment>(
                                                        Payment.class),
                                    new Object[]
                                    { payment.getContractId() });
                logger.info(":::::::::::::::::::::: get contracttypeid value repository ::::::::::::::::::::::::");
                if (paytotalamt != null)
                {
                    double differenceAmount = paytotalamt.getPaymentAmount()
                                        - payment.getPaymentAmount();
                    payment.setResult(jdbcTemplate.update(
                                        DSCConstants.CONTRACT_DIFF, new Object[]
                                        { differenceAmount, userid,
                                                        new java.sql.Date(t),
                                                        "NPD",
                                                        payment.getContractId() }));
                }
            }
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return payment;
    }
    
    /**
     * Method to update payment details
     * 
     * @param payment
     * @param contractId
     * @param flag
     * @param status
     * @param paymentID
     * @param userid
     * @return
     * @throws BaseClassException
     */
    public int updatePayment(Payment payment , String userid,String contractCategory)
                        throws BaseClassException
    {
        logger.info(":::::::::::::::::::::: updatePayment repository ::::::::::::::::::::::::");
        Date today = new java.util.Date();
        long t = today.getTime();
        int rsult = 0;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        SetUpAlert setUpAlert=null;
        try
        {
            if (payment.getFlag().equalsIgnoreCase("Edit"))
            {
                
                rsult = jdbcTemplate.update(
                                    DSCConstants.PAYMENT_UPDATE_DATE_QUERY,
                                    new Object[]
                                    { payment.getPaymentDate(), userid,
                                                    new java.sql.Date(t),
                                                    payment.getContractId(),
                                                    payment.getPaymentId() });
                                    
            } else if (payment.getFlag().equalsIgnoreCase("Sighted"))
            {
                rsult = jdbcTemplate.update(DSCConstants.PAYMENT_UPDATE_QUERY,
                                    new Object[]
                                    { payment.getStatus(), userid,
                                                    new java.sql.Date(t),
                                                    payment.getContractId(),
                                                    payment.getPaymentId() });
                if(rsult>0) {
                Contract con = jdbcTemplate.queryForObject(
                                    DSCConstants.CUSTOMER_VALUE,
                                    new BeanPropertyRowMapper<Contract>(
                                                        Contract.class),
                                    new Object[]
                                    { payment.getContractId() });
                if(con!=null) {
                                    
                    setUpAlert = alertNotificationRepository.setupAlert(DSCConstants.PAYMENT_SIGHTED_CODE,
                                    contractCategory, con.getCustomerId(), userid,
                                    payment.getContractId(), payment.getPaymentId(), 0,0);
                    rsult = setUpAlert.getResult();
                }else {
                    rsult = -1;
                }
            }
            }
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return rsult;
    }
    
    /**
     * Method to delete payment
     * 
     * @param contractId
     * @param paymentID
     * @param userid
     * @return
     * @throws BaseClassException
     */
    public int deletePayment(int contractId , int paymentID , String userid)
                        throws BaseClassException
    {
        logger.info(":::::::::::::::::::::: deletePayment repository ::::::::::::::::::::::::");
        Date today = new java.util.Date();
        long t = today.getTime();
        int rsult = 0;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            Payment payid = jdbcTemplate.queryForObject(
                                DSCConstants.SELECT_PAYID,
                                new BeanPropertyRowMapper<Payment>(
                                                    Payment.class),
                                new Object[]
                                { contractId, paymentID });
                                
            Payment paytotalamt = jdbcTemplate.queryForObject(
                                DSCConstants.PAYMENT_DIFF,
                                new BeanPropertyRowMapper<Payment>(
                                                    Payment.class),
                                new Object[]
                                { contractId });
            logger.info(":::::::::::::::::::::: get contracttypeid value repository ::::::::::::::::::::::::");
            if (payid != null)
            {
                jdbcTemplate.update(DSCConstants.CONTRACT_DIFF, new Object[]
                { (paytotalamt.getPaymentAmount() + (payid.getPaymentAmount())),
                                userid, new java.sql.Date(t), "NPD",
                                contractId });
            }
            
            rsult = jdbcTemplate.update(DSCConstants.PAYMENT_DELETE_QUERY,
                                new Object[]
                                { contractId, paymentID });
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return rsult;
    }
    
    /**
     * Method to update approved Qty
     * 
     * @param approvedQuantity
     * @param userid
     * @return
     * @throws BaseClassException
     */
    public ApprovedQuantity updateApprovedQuantity(
                        ApprovedQuantity approvedQuantity , String userid ,
                        String contractCategory) throws BaseClassException
    {
        Date today = new java.util.Date();
        long t = today.getTime();
        int rsult = 0;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        int qtyamount = 0;
        try
        {
            logger.info(":::::::::::::::::::::: updateApprovedQuantity repository ::::::::::::::::::::::::");
            Contract contract = jdbcTemplate.queryForObject(
                                DSCConstants.CONTRACT_QUANTITY, new Object[]
                                { approvedQuantity.getContractId(),
                                                contractCategory },
                                new BeanPropertyRowMapper<Contract>(
                                                    Contract.class));
            qtyamount = approvedQuantity.getApprovedQty()
                                + contract.getApprovedQuantity();
            
            if (qtyamount <= contract.getQuantity())
            {
                
                rsult = jdbcTemplate.update(DSCConstants.CONTRACT_UPDATE_APPQTY,
                                    new Object[]
                                    { qtyamount, userid, new java.sql.Date(t),
                                                    approvedQuantity.getContractId() });
            } else
            {
                approvedQuantity.setResult(-1);
            }
            
            if (rsult > 0)
            {
                approvedQuantity.setTotalContractQTY(qtyamount);
                approvedQuantity.setResult(jdbcTemplate.update(
                                    DSCConstants.INSERT_APPROVED_QUANTITY,
                                    new Object[]
                                    { approvedQuantity.getContractId(),
                                                    approvedQuantity.getApprovedQty(),
                                                    userid,
                                                    new java.sql.Date(t),
                                                    userid,
                                                    new java.sql.Date(t) }));
            }
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return approvedQuantity;
    }
    
    /**
     * Method to get approved QTY
     * 
     * @param contractId
     * @return
     */
    public ApprovedQuantity getApprovedQuantityList(int contractId)
                        throws BaseClassException
    {
        logger.info(":::::::::::::::::::::: getApprovedQuantityList repository ::::::::::::::::::::::::");
        ApprovedQuantity approvedQuantity = null;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            approvedQuantity = jdbcTemplate.queryForObject(
                                DSCConstants.STATUS_GET, new Object[]
                                { contractId },
                                new BeanPropertyRowMapper<ApprovedQuantity>(
                                                    ApprovedQuantity.class));
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return approvedQuantity;
    }
}
