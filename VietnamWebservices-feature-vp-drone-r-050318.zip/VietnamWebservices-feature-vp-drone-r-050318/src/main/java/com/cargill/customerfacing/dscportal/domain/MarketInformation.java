/*
 * MarketInformation.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.domain;

public class MarketInformation extends BaseModel
{
  
  private String heading;
  private String status;
  private String details;
  private int marketId;
  private String contractCategory;
  private int result;
  private int nextval;
  
  public String getHeading()
  {
    return heading;
  }
  public void setHeading(String heading)
  {
    this.heading = heading;
  }
  public String getStatus()
  {
    return status;
  }
  public void setStatus(String status)
  {
    this.status = status;
  }
  public String getDetails()
  {
    return details;
  }
  public void setDetails(String details)
  {
    this.details = details;
  }
  public int getMarketId()
  {
    return marketId;
  }
  public void setMarketId(int marketId)
  {
    this.marketId = marketId;
  }
  public String getContractCategory()
  {
    return contractCategory;
  }
  public void setContractCategory(String contractCategory)
  {
    this.contractCategory = contractCategory;
  }
public int getResult()
{
    return result;
}
public void setResult(int result)
{
    this.result = result;
}
public int getNextval()
{
    return nextval;
}
public void setNextval(int nextval)
{
    this.nextval = nextval;
}
  
}
