package com.cargill.customerfacing.dscportal.webservices;

import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.cargill.customerfacing.dscportal.domain.DSCConstants;
import com.cargill.customerfacing.dscportal.domain.User;

public class RestAPIHandler
{
    
    private static final Logger LOG = Logger.getLogger(RestAPIHandler.class);
    
    public String callRestEndpoint(String requestType, User user) throws Exception {

        
        String result;
        String url;
        //String bzAPIUrl = ""; 
        switch (requestType) {
            case DSCConstants.BZAPI_COMMODITY: url = DSCConstants.BZAPI_URL+"/"+DSCConstants.BZAPI_COMMODITY; break;
            case DSCConstants.BZAPI_ACCOUNTS: url =  DSCConstants.BZAPI_URL+"/"+DSCConstants.BZAPI_ACCOUNTS; break;
            
            default:
                result = "invalid request-type: " + requestType;
                return result;
        }

       // LOG.info("Calling Rest endpoint: " + url);

        HttpHeaders headers = new HttpHeaders();
       // headers.add("Authorization", "Bearer " + user.getAccessToken());
       // LOG.info("setting Authorization header to: Bearer " + user.getAccessToken());

        RestTemplate restTemplate = new RestTemplate();

        HttpEntity<String> requestHeaders = new HttpEntity<>(headers);
        ResponseEntity<String> response;

        try {
            response = restTemplate.exchange(url, HttpMethod.GET, requestHeaders, String.class);
            if (response != null) {
                result = response.getBody();
                LOG.info("response body: " + response.getBody());
            } else {
                String msg = "No Response Received";
                result = msg;
                LOG.info(msg);
            }
        }
        catch (Exception e) {
            result=e.getMessage();
        }

        return result;
    }
    
}
