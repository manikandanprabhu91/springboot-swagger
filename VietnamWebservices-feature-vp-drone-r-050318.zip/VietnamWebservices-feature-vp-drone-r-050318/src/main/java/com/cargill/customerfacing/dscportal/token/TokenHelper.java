package com.cargill.customerfacing.dscportal.token;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Component;





@Component
public class TokenHelper {



    public String getToken(HttpServletRequest request) {
	/**
	 * Getting the token from Authentication header e.g Bearer your_token
	 */
	String authHeader = getAuthHeaderFromHeader(request);
	if (authHeader != null && authHeader.startsWith("Bearer ")) {
	    return authHeader.substring(7);
	}

	return null;
    }

    public String getAuthHeaderFromHeader(HttpServletRequest request) {
	return request.getHeader("Authorization");
    }

}
