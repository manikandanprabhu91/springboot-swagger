//package com.cargill.customerfacing.dscportal.wrapper;
//
//import org.springframework.stereotype.Service;
//
//import com.amazonaws.AmazonClientException;
//import com.amazonaws.AmazonServiceException;
//import com.amazonaws.services.s3.AmazonS3;
//import com.amazonaws.services.s3.AmazonS3ClientBuilder;
//import com.amazonaws.services.s3.model.DeleteObjectRequest;
//import com.amazonaws.services.s3.model.GetObjectRequest;
//import com.amazonaws.services.s3.model.PutObjectRequest;
//import com.amazonaws.services.s3.model.S3Object;
//import com.amazonaws.services.s3.model.S3ObjectInputStream;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.core.env.Environment;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.MediaType;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.multipart.MultipartFile;
//import org.apache.commons.io.IOUtils;
//
//import javax.annotation.PostConstruct;
//import java.io.File;
//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.util.Date;
//import java.net.URLEncoder;
///**
// * This class is used to put and get the file from AWS S3 bucket
// * @author 430196 (Manikandan Prabhu D)
// *
// */
//@Service
//public class AmazonS3Wrapper {
//
//	private Logger logger = LoggerFactory.getLogger(AmazonS3Wrapper.class);
//	private AmazonS3 s3client;
//	@Autowired
//	private Environment environment;
//
//
//	@PostConstruct
//	private void initializeAmazon() {
//		s3client = AmazonS3ClientBuilder.standard().build();
//	}
//
//	/**
//	 * This method is used to upload the file to AWS S3 bucket.
//	 * @param multipartFile
//	 * @return fileurl
//	 */
//	public String uploadFile(MultipartFile multipartFile) {
//		String fileUrl = "";
//		try {
//			File file = convertMultiPartToFile(multipartFile);
//			String fileName = generateFileName(multipartFile,1,12,"payment");
//			uploadFileTos3bucket(fileName, file);
//			file.delete();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return fileUrl;
//	}
//
//	/**
//	 * This method is used to convert multipartfile to normal file
//	 * @param file
//	 * @return convFile
//	 * @throws IOException
//	 */
//	private File convertMultiPartToFile(MultipartFile file) throws IOException {
//		File convFile = new File(file.getOriginalFilename());
//		FileOutputStream fos = new FileOutputStream(convFile);
//		fos.write(file.getBytes());
//		fos.close();
//		return convFile;
//	}
//
//	/**
//	 * This method is used to generate the file name.
//	 * @param multiPart
//	 * @return filename
//	 */
//	private String generateFileName(MultipartFile multiPart,int contractId,int screenid,String constant) {
//		return contractId+"/"+constant+"/"+screenid + "-" +new Date().getTime() + "-" + multiPart.getOriginalFilename().replace(" ", "_");
//	}
//
//	/**
//	 * This method is use to put the file to the S3 bucket.
//	 * @param fileName
//	 * @param file
//	 */
//	private void uploadFileTos3bucket(String fileName, File file) {
//		logger.info(" ****************************** uploadFileTos3bucket start *************************");
//		try {
//			logger.info(" ****************************** environemt variable Bucket Name *************************" + environment.getProperty("BUCKET_NAME"));
//			s3client.putObject(new PutObjectRequest(environment.getProperty("BUCKET_NAME"), fileName, file));
//			logger.info(" ****************************** uploadFileTos3bucket end try block *************************");
//		}  
//		catch (AmazonServiceException ase) {
//			logger.error("Caught an AmazonServiceException, which " +
//            		"means your request made it " +
//                    "to Amazon S3, but was rejected with an error response" +
//                    " for some reason.");
//            logger.error("Error Message:    " + ase.getMessage());
//            logger.error("HTTP Status Code: " + ase.getStatusCode());
//            logger.error("AWS Error Code:   " + ase.getErrorCode());
//            logger.error("Error Type:       " + ase.getErrorType());
//            logger.error("Request ID:       " + ase.getRequestId());
//        } catch (AmazonClientException ace) {
//        	logger.error("Caught an AmazonClientException, which " +
//            		"means the client encountered " +
//                    "an internal error while trying to " +
//                    "communicate with S3, " +
//                    "such as not being able to access the network.");
//        	logger.error("Error Message: " + ace.getMessage());
//        }
//		catch(Exception e) {
//			logger.error(" ****************************** uploadFileTos3bucket exception *************************"+ e.getMessage());
//		} 
//	}
//
//	/**
//	 * This method is used to delete the file from S3 bucket.
//	 * @param fileUrl
//	 * @return message
//	 */
//	public String deleteFileFromS3Bucket(String fileUrl) {
//		String fileName = fileUrl.substring(fileUrl.lastIndexOf("/") + 1);
//		s3client.deleteObject(new DeleteObjectRequest(environment.getProperty("BUCKET_NAME"), fileName));
//		return "Successfully deleted";
//	}
//	
//	/**
//	 * This method is used to download the file from S3 bucket.
//	 * @param key
//	 * @return responseentity
//	 * @throws IOException
//	 */
//	public ResponseEntity<byte[]> download(String key) throws IOException {
//		GetObjectRequest getObjectRequest = new GetObjectRequest(environment.getProperty("BUCKET_NAME"), key);
//		S3Object s3Object = s3client.getObject(getObjectRequest);
//		S3ObjectInputStream objectInputStream = s3Object.getObjectContent();
//		byte[] bytes = IOUtils.toByteArray(objectInputStream);
//		String fileName = URLEncoder.encode(key, "UTF-8").replaceAll("\\+", "%20");
//		HttpHeaders httpHeaders = new HttpHeaders();
//		httpHeaders.setContentType(MediaType.APPLICATION_OCTET_STREAM);
//		httpHeaders.setContentLength(bytes.length);
//		httpHeaders.setContentDispositionFormData("attachment", fileName);
//		return new ResponseEntity<>(bytes, httpHeaders, HttpStatus.OK);
//	}
//}
