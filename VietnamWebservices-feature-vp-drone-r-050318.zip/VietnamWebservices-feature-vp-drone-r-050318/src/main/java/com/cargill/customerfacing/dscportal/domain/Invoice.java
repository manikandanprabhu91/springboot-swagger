/*
 * Invoice.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.domain;

public class Invoice extends BaseModel
{
    
    private int invoiceNo;
    private String invoiceDate;
    private double commodityQty;
    private double invoiceAmount;
    private String fileName;
    private String commodityName;
    private int contractId;
    private int result;
    private int nextval;
    private int invoiceId;
    private String customerName;
    
    public int getInvoiceNo()
    {
        return invoiceNo;
    }
    public void setInvoiceNo(int invoiceNo)
    {
        this.invoiceNo = invoiceNo;
    }
    public String getInvoiceDate()
    {
        return invoiceDate;
    }
    public void setInvoiceDate(String invoiceDate)
    {
        this.invoiceDate = invoiceDate;
    }
    public double getInvoiceAmount()
    {
        return invoiceAmount;
    }
    public void setInvoiceAmount(double invoiceAmount)
    {
        this.invoiceAmount = invoiceAmount;
    }
    public int getContractId()
    {
        return contractId;
    }
    public void setContractId(int contractId)
    {
        this.contractId = contractId;
    }
    public int getResult()
    {
        return result;
    }
    public void setResult(int result)
    {
        this.result = result;
    }
    public int getNextval()
    {
        return nextval;
    }
    public void setNextval(int nextval)
    {
        this.nextval = nextval;
    }
    public int getInvoiceId()
    {
        return invoiceId;
    }
    public void setInvoiceId(int invoiceId)
    {
        this.invoiceId = invoiceId;
    }
    public double getCommodityQty()
    {
        return commodityQty;
    }
    public void setCommodityQty(double commodityQty)
    {
        this.commodityQty = commodityQty;
    }
    public String getFileName()
    {
        return fileName;
    }
    public void setFileName(String fileName)
    {
        this.fileName = fileName;
    }
    public String getCommodityName()
    {
        return commodityName;
    }
    public void setCommodityName(String commodityName)
    {
        this.commodityName = commodityName;
    }
    public String getCustomerName()
    {
        return customerName;
    }
    public void setCustomerName(String customerName)
    {
        this.customerName = customerName;
    }
    
}
