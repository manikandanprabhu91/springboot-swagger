/*
 * RegionFactoryService.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.region.factory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cargill.customerfacing.dscportal.domain.DSCConstants;
import com.cargill.customerfacing.dscportal.service.IAlertNotification;
import com.cargill.customerfacing.dscportal.service.IArrivalSchedule;
import com.cargill.customerfacing.dscportal.service.IContractService;
import com.cargill.customerfacing.dscportal.service.IInventory;
import com.cargill.customerfacing.dscportal.service.IInvoice;
import com.cargill.customerfacing.dscportal.service.IMarketInformation;
import com.cargill.customerfacing.dscportal.service.IPaymentService;
import com.cargill.customerfacing.dscportal.service.IPickUpSchedule;
import com.cargill.customerfacing.dscportal.service.IUserProfile;

@Service
public class RegionFactoryService
{
  
  @Autowired
  private IContractService vietnamContractService;
  
  @Autowired
  private IPaymentService vietnamPaymentService;
  
  @Autowired
  private IPickUpSchedule vietnamPickUpScheduleService;
  
  @Autowired
  private IMarketInformation vietnamMarketInformationService;
  
  @Autowired
  private IArrivalSchedule vietnamArrivalScheduleService;
  
  @Autowired
  private IInvoice vietnamInvoiceService;
  
  @Autowired
  private IInventory vietnamInventoryService;
  
  @Autowired
  private IAlertNotification vietnamAlertNotificationService;
  
  @Autowired
  private IUserProfile vietnamUserProfileService;
  
  public IContractService getContractService(String contractCategory)
  {
    if (contractCategory.equalsIgnoreCase(DSCConstants.VIETNAM))
    {
      return vietnamContractService;
    }
    return null;
  }
  
  public IPaymentService getPaymentService(String contractCategory)
  {
    if (contractCategory.equalsIgnoreCase(DSCConstants.VIETNAM))
    {
      return vietnamPaymentService;
    }
    return null;
  }
  
  public IPickUpSchedule getPickUpScheduleService(String categoryType)
  {
    if (categoryType.equalsIgnoreCase(DSCConstants.VIETNAM))
    {
      return vietnamPickUpScheduleService;
    }
    return null;
  }
  
  public IMarketInformation getMarketInfoService(String contractCategory)
  {
    if (contractCategory.equalsIgnoreCase(DSCConstants.VIETNAM))
    {
      return vietnamMarketInformationService;
    }
    return null;
  }
  
  public IArrivalSchedule getArrivalSchedule(String contractCategory)
  {
    if (contractCategory.equalsIgnoreCase(DSCConstants.VIETNAM))
    {
      return vietnamArrivalScheduleService;
    }
    return null;
  }
  
  public IInvoice getInvoice(String contractCategory)
  {
    if (contractCategory.equalsIgnoreCase(DSCConstants.VIETNAM))
    {
      return vietnamInvoiceService;
    }
    return null;
  }
  
  public IInventory getInventory(String contractCategory)
  {
    if (contractCategory.equalsIgnoreCase(DSCConstants.VIETNAM))
    {
      return vietnamInventoryService;
    }
    return null;
  }
  
  public IAlertNotification getAlerts(String contractCategory)
  {
    if (contractCategory.equalsIgnoreCase(DSCConstants.VIETNAM))
    {
      return vietnamAlertNotificationService;
    }
    return null;
  }
  
  public IUserProfile getUserConfig(String contractCategory)
  {
    if (contractCategory.equalsIgnoreCase(DSCConstants.VIETNAM))
    {
      return vietnamUserProfileService;
    }
    return null;
  }
  
  public void setVietnamMarketInformationService(
            IMarketInformation vietnamMarketInformationService)
  {
    this.vietnamMarketInformationService = vietnamMarketInformationService;
  }
  
  public void setVietnamArrivalScheduleService(
            IArrivalSchedule vietnamArrivalScheduleService)
  {
    this.vietnamArrivalScheduleService = vietnamArrivalScheduleService;
  }
  
  public void setVietnamContractService(IContractService vietnamContractService)
  {
    this.vietnamContractService = vietnamContractService;
  }
  
  public void setVietnamInvoiceService(IInvoice vietnamInvoiceService)
  {
    this.vietnamInvoiceService = vietnamInvoiceService;
  }
  
  public void setVietnamInventoryService(IInventory vietnamInventoryService)
  {
    this.vietnamInventoryService = vietnamInventoryService;
  }
  
  public void setVietnamAlertNotificationService(
            IAlertNotification vietnamAlertNotificationService)
  {
    this.vietnamAlertNotificationService = vietnamAlertNotificationService;
  }
  
  public void setVietnamPaymentService(IPaymentService vietnamPaymentService)
  {
    this.vietnamPaymentService = vietnamPaymentService;
  }
  
  public void setVietnamPickUpScheduleService(
            IPickUpSchedule vietnamPickUpScheduleService)
  {
    this.vietnamPickUpScheduleService = vietnamPickUpScheduleService;
  }
  
  public void setVietnamUserProfileService(
            IUserProfile vietnamUserProfileService)
  {
    this.vietnamUserProfileService = vietnamUserProfileService;
  }
}
