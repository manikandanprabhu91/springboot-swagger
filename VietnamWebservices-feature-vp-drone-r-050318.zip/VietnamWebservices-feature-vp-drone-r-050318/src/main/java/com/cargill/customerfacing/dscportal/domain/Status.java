/*
 * Status.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.domain;

public class Status extends BaseModel
{
  
  private int statusId;
  private String statusType;
  private String description;
  private String screen;
  
  public int getStatusId()
  {
    return statusId;
  }
  public void setStatusId(int statusId)
  {
    this.statusId = statusId;
  }
  public String getStatusType()
  {
    return statusType;
  }
  public void setStatusType(String statusType)
  {
    this.statusType = statusType;
  }
  public String getDescription()
  {
    return description;
  }
  public void setDescription(String description)
  {
    this.description = description;
  }
  public String getScreen()
  {
    return screen;
  }
  public void setScreen(String screen)
  {
    this.screen = screen;
  }
  
}
