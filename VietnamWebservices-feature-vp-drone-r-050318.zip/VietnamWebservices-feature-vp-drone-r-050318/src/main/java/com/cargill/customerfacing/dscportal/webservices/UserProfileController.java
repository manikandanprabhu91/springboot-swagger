/*
 * UserProfileController.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.webservices;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cargill.customerfacing.dscportal.domain.DSCConstants;
import com.cargill.customerfacing.dscportal.domain.ResponseGateway;
import com.cargill.customerfacing.dscportal.domain.UserConfig;
import com.cargill.customerfacing.dscportal.domain.UserProfile;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.region.factory.RegionFactoryService;

@RestController
@EnableAutoConfiguration
@RequestMapping(value = "/api/dxo/dsc/v1/auth")
public class UserProfileController
{
    
    private Logger logger = LoggerFactory.getLogger(UserProfileController.class);
    
    @Autowired
    RegionFactoryService regionFactoryService;
    
    private ResponseGateway gateway;
    
    /**
     * Method to get user config list
     * 
     * @param contractCategory
     * @param userid
     * @return
     */
    @RequestMapping(value = "/userConfigList", method = RequestMethod.GET, produces = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> getUserConfig(
                        @RequestParam("contractCategory")
                        String contractCategory , @RequestParam("userid")
                        String userid) throws BaseClassException
    {
        gateway = new ResponseGateway();
        logger.info(":::::::::: getUserConfig :::::::::::::::");
        List<UserConfig> userConfigs = null;
        ResponseEntity<ResponseGateway> responseGateway = null;
        try
        {
            userConfigs = regionFactoryService.getUserConfig(contractCategory)
                                .getUserConfig(contractCategory, userid);
            if (userConfigs != null && !userConfigs.isEmpty())
            {
                responseGateway = gateway.buildResponse(userConfigs,
                                    DSCConstants.SUCCESS, "",
                                    DSCConstants.CODE200, "");
            } else
            {
                responseGateway = gateway.buildResponse(userConfigs,
                                    DSCConstants.FAIL, DSCConstants.NORESULT,
                                    DSCConstants.CODE200, DSCConstants.F101);
            }
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR,
                                DSCConstants.SERVERERROR, DSCConstants.CODE500,
                                DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to update user config details
     * 
     * @param userConfig
     * @param userConfigId
     * @param contractCategory
     * @param userid
     * @return
     * @throws BaseClassException
     */
    @RequestMapping(value = "/updateUserConfig", method = RequestMethod.PATCH, produces = DSCConstants.APPLICATION_JSON, consumes = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> updateUserConfig(@RequestBody
    UserConfig userConfig , @RequestParam("contractCategory")
    String contractCategory , @RequestParam("userid")
    String userid) throws BaseClassException
    {
        logger.info(":::::::::: updateUserConfig :::::::::::::::");
        ResponseEntity<ResponseGateway> responseGateway = null;
        int updatestatus = 0;
        gateway = new ResponseGateway();
        try
        {
            updatestatus = regionFactoryService.getUserConfig(contractCategory)
                                .updateUserConfig(userConfig, contractCategory,
                                                    userid);
            if (updatestatus > 0)
            {
                responseGateway = gateway.buildResponse(null,
                                    DSCConstants.SUCCESS,
                                    DSCConstants.SUCCESS_UPDATE,
                                    DSCConstants.CODE200,
                                    String.valueOf(userConfig
                                                        .getUserConfigId()));
            } else
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.FAIL,
                                    DSCConstants.NOTUPDATED,
                                    DSCConstants.CODE200, DSCConstants.F102);
            }
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR,
                                DSCConstants.SERVERERROR, DSCConstants.CODE500,
                                DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to update user config details
     * 
     * @param userConfig
     * @param userConfigId
     * @param contractCategory
     * @param userid
     * @return
     * @throws BaseClassException
     */
    @RequestMapping(value = "/userProfile", method = RequestMethod.POST, produces = DSCConstants.APPLICATION_JSON, consumes = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> insertUserProfile(@RequestBody
    UserProfile userProfile , @RequestParam("contractCategory")
    String contractCategory , @RequestParam("userid")
    String userid) throws BaseClassException
    {
        logger.info(":::::::::: updateUserConfig :::::::::::::::");
        ResponseEntity<ResponseGateway> responseGateway = null;
        UserProfile status = null;
        gateway = new ResponseGateway();
        try
        {
            status = regionFactoryService.getUserConfig(contractCategory)
                                .insertUserProfile(userProfile,
                                                    userid);
            if (status.getResult() > 0)
            {
                responseGateway = gateway.buildResponse(null,
                                    DSCConstants.SUCCESS,
                                    DSCConstants.SUCCESS_UPDATE,
                                    DSCConstants.CODE200,
                                    String.valueOf(userProfile.getNextVal()));
            } else
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.FAIL,
                                    DSCConstants.NOTUPDATED,
                                    DSCConstants.CODE200, DSCConstants.F102);
            }
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR,
                                DSCConstants.SERVERERROR, DSCConstants.CODE500,
                                DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * 
     * @param userProfile
     * @param contractCategory
     * @param userid
     * @return
     * @throws BaseClassException
     */
    @RequestMapping(value = "/updateUserProfile", method = RequestMethod.PATCH, produces = DSCConstants.APPLICATION_JSON, consumes = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> updateUserProfile(@RequestBody
    UserProfile userProfile , @RequestParam("contractCategory")
    String contractCategory , @RequestParam("userid")
    String userid) throws BaseClassException
    {
        logger.info(":::::::::: updateUserConfig :::::::::::::::");
        ResponseEntity<ResponseGateway> responseGateway = null;
        int updatestatus = 0;
        gateway = new ResponseGateway();
        try
        {
            updatestatus = regionFactoryService.getUserConfig(contractCategory)
                                .updateUserProfile(userProfile,
                                                    userid);
            if (updatestatus > 0)
            {
                responseGateway = gateway.buildResponse(null,
                                    DSCConstants.SUCCESS,
                                    DSCConstants.SUCCESS_UPDATE,
                                    DSCConstants.CODE200,
                                    String.valueOf(userProfile
                                                        .getUserProfileId()));
            } else
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.FAIL,
                                    DSCConstants.NOTUPDATED,
                                    DSCConstants.CODE200, DSCConstants.F102);
            }
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR,
                                DSCConstants.SERVERERROR, DSCConstants.CODE500,
                                DSCConstants.E100);
        }
        return responseGateway;
    }
}
