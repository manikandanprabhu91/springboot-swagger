/*
 * UserConfig.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.domain;

public class UserConfig extends BaseModel
{
  
  private String userId;
  private int screenId;
  private int sectionId;
  private int attributeId;
  private String attributeValue;
  private String userConfigCol;
  private String customerId;
  private int userConfigId;
  
  public String getUserId()
  {
    return userId;
  }
  public void setUserId(String userId)
  {
    this.userId = userId;
  }
  public int getScreenId()
  {
    return screenId;
  }
  public void setScreenId(int screenId)
  {
    this.screenId = screenId;
  }
  public int getSectionId()
  {
    return sectionId;
  }
  public void setSectionId(int sectionId)
  {
    this.sectionId = sectionId;
  }
  public int getAttributeId()
  {
    return attributeId;
  }
  public void setAttributeId(int attributeId)
  {
    this.attributeId = attributeId;
  }
  public String getAttributeValue()
  {
    return attributeValue;
  }
  public void setAttributeValue(String attributeValue)
  {
    this.attributeValue = attributeValue;
  }
  public String getUserConfigCol()
  {
    return userConfigCol;
  }
  public void setUserConfigCol(String userConfigCol)
  {
    this.userConfigCol = userConfigCol;
  }
  public String getCustomerId()
  {
    return customerId;
  }
  public void setCustomerId(String customerId)
  {
    this.customerId = customerId;
  }
public int getUserConfigId()
{
    return userConfigId;
}
public void setUserConfigId(int userConfigId)
{
    this.userConfigId = userConfigId;
}
  
}
