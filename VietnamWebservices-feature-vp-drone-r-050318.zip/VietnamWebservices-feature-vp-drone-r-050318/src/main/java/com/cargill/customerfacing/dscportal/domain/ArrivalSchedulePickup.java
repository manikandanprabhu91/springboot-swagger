/*
 * ArrivalSchedule.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.domain;

import java.util.ArrayList;
import java.util.List;

public class ArrivalSchedulePickup extends ArrivalSchedule
{
    
    
    private String pickUpDate;
    private String approvedPickUpDate;
    private String pickUpId;
    private String document;
    private String cakNo;
    private int pickUpQty;
    private String fileName;
    private String status;
    private String authorizationNumber;
    private String pickUpTime;
    private String approvedPickUpTime;
    private int arrivalTotalQty;
    
   
    public String getPickUpDate()
    {
        return pickUpDate;
    }
    public void setPickUpDate(String pickUpDate)
    {
        this.pickUpDate = pickUpDate;
    }
    public String getApprovedPickUpDate()
    {
        return approvedPickUpDate;
    }
    public void setApprovedPickUpDate(String approvedPickUpDate)
    {
        this.approvedPickUpDate = approvedPickUpDate;
    }
    public String getDocument()
    {
        return document;
    }
    public void setDocument(String document)
    {
        this.document = document;
    }
    public String getCakNo()
    {
        return cakNo;
    }
    public void setCakNo(String cakNo)
    {
        this.cakNo = cakNo;
    }
    public String getPickUpId()
    {
        return pickUpId;
    }
    public void setPickUpId(String pickUpId)
    {
        this.pickUpId = pickUpId;
    }
    public int getPickUpQty()
    {
        return pickUpQty;
    }
    public void setPickUpQty(int pickUpQty)
    {
        this.pickUpQty = pickUpQty;
    }
    public String getFileName()
    {
        return fileName;
    }
    public void setFileName(String fileName)
    {
        this.fileName = fileName;
    }
    public String getStatus()
    {
        return status;
    }
    public void setStatus(String status)
    {
        this.status = status;
    }
    public String getAuthorizationNumber()
    {
        return authorizationNumber;
    }
    public void setAuthorizationNumber(String authorizationNumber)
    {
        this.authorizationNumber = authorizationNumber;
    }
    public String getPickUpTime()
    {
        return pickUpTime;
    }
    public void setPickUpTime(String pickUpTime)
    {
        this.pickUpTime = pickUpTime;
    }
    public String getApprovedPickUpTime()
    {
        return approvedPickUpTime;
    }
    public void setApprovedPickUpTime(String approvedPickUpTime)
    {
        this.approvedPickUpTime = approvedPickUpTime;
    }
    public int getArrivalTotalQty()
    {
        return arrivalTotalQty;
    }
    public void setArrivalTotalQty(int arrivalTotalQty)
    {
        this.arrivalTotalQty = arrivalTotalQty;
    }
    
    
    }
