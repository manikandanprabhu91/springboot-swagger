/*
 * UserAlertMapping.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.domain;

public class UserAlertMapping extends BaseModel
{
  
  private String userId;
  private String message;
  private String web;
  private String email;
  private String sms;
  private int alertId;
  private int userMappingId;
  
  public String getUserId()
  {
    return userId;
  }
  public void setUserId(String userId)
  {
    this.userId = userId;
  }
  public String getMessage()
  {
    return message;
  }
  public void setMessage(String message)
  {
    this.message = message;
  }
  public String getWeb()
  {
    return web;
  }
  public void setWeb(String web)
  {
    this.web = web;
  }
  public String getEmail()
  {
    return email;
  }
  public void setEmail(String email)
  {
    this.email = email;
  }
  public String getSms()
  {
    return sms;
  }
  public void setSms(String sms)
  {
    this.sms = sms;
  }
  public int getAlertId()
  {
    return alertId;
  }
  public void setAlertId(int alertId)
  {
    this.alertId = alertId;
  }
public int getUserMappingId()
{
    return userMappingId;
}
public void setUserMappingId(int userMappingId)
{
    this.userMappingId = userMappingId;
}
  
}
