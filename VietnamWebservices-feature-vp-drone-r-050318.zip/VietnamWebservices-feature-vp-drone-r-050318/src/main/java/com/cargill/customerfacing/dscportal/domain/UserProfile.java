/*
 * UserProfile.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.domain;

public class UserProfile extends BaseModel
{
    
    private String userId;
    private String email;
    private String customerId;
    private String cargillUser;
    private int result;
    private int nextVal;
    private int userProfileId;
    
    public String getUserId()
    {
        return userId;
    }
    public void setUserId(String userId)
    {
        this.userId = userId;
    }
    public String getEmail()
    {
        return email;
    }
    public void setEmail(String email)
    {
        this.email = email;
    }
    public String getCustomerId()
    {
        return customerId;
    }
    public void setCustomerId(String customerId)
    {
        this.customerId = customerId;
    }
    public String getCargillUser()
    {
        return cargillUser;
    }
    public void setCargillUser(String cargillUser)
    {
        this.cargillUser = cargillUser;
    }
    public int getResult()
    {
        return result;
    }
    public void setResult(int result)
    {
        this.result = result;
    }
    public int getNextVal()
    {
        return nextVal;
    }
    public void setNextVal(int nextVal)
    {
        this.nextVal = nextVal;
    }
    public int getUserProfileId()
    {
        return userProfileId;
    }
    public void setUserProfileId(int userProfileId)
    {
        this.userProfileId = userProfileId;
    }
    
}
