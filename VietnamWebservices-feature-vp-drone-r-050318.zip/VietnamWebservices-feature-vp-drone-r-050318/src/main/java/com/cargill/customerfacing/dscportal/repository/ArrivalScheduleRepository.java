/*
 * ArrivalScheduleRepository.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.cargill.customerfacing.dscportal.domain.ArrivalSchedule;
import com.cargill.customerfacing.dscportal.domain.ArrivalSchedulePickup;
import com.cargill.customerfacing.dscportal.domain.Contract;
import com.cargill.customerfacing.dscportal.domain.DSCConstants;
import com.cargill.customerfacing.dscportal.domain.PickUpSchedule;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;

@Repository
public class ArrivalScheduleRepository
{
    
    private static Logger logger = LoggerFactory
                        .getLogger(ArrivalScheduleRepository.class);
    
    @Autowired
    JdbcTemplate jdbcTemplate;
    
    /**
     * Method to insert arrival schedule details
     * 
     * @param arrivalSchedule
     * @param contractId
     * @param userid
     * @return
     * @throws BaseClassException
     */
    public ArrivalSchedule insertArrivalSchedule(
                        ArrivalSchedule arrivalSchedule , String userid ,
                        String contractCategory) throws BaseClassException
    {
        Date today = new java.util.Date();
        long t = today.getTime();
        int nextval = 0;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        int quantity = 0;
        logger.info(":::::::::::::::::::::: insertArrivalSchedule repository ::::::::::::::::::::::::");
        try
        {
            
            ArrivalSchedule arrivalSchedule2 = jdbcTemplate.queryForObject(
                                DSCConstants.ARRIVAL_COMPARE_TOTALQTY,
                                new Object[]
                                { arrivalSchedule.getContractId(),
                                                contractCategory },
                                new BeanPropertyRowMapper<ArrivalSchedule>(
                                                    ArrivalSchedule.class));
            quantity = arrivalSchedule2.getApprovedQuantity()
                                + arrivalSchedule.getApprovedQuantity();
            
            if (arrivalSchedule2.getContractTotalQty() > arrivalSchedule2
                                .getApprovedQuantity()
                                && arrivalSchedule2.getContractTotalQty() >= quantity)
            {
                nextval = jdbcTemplate.queryForObject(
                                    DSCConstants.ARRIVAL_NEXTVAL, new Object[]
                                    {}, Integer.class);
                arrivalSchedule.setResult(jdbcTemplate.update(
                                    DSCConstants.ARRIVALSCHDULE_INSERT_QUERY,
                                    new Object[]
                                    {nextval, arrivalSchedule.getCommodity(),
                                                    arrivalSchedule.getApprovedQuantity(),
                                                    arrivalSchedule.getTendered(),
                                                    arrivalSchedule.getShipmentPeriod(),
                                                    arrivalSchedule.getVesselName(),
                                                    arrivalSchedule.getWareHouse(),
                                                    arrivalSchedule.getEtaDate(),
                                                    arrivalSchedule.getEtaTime(),
                                                    userid,
                                                    new java.sql.Date(t),
                                                    userid,
                                                    new java.sql.Date(t),
                                                    arrivalSchedule.getContractId(),
                                                    arrivalSchedule.getDeliveryBasis(),
                                                    arrivalSchedule.getContractId() }));
                if(arrivalSchedule.getResult() >0 ) {
                    arrivalSchedule.setNextval(nextval);
                }
                                    
            } else
            {
                arrivalSchedule.setResult(-1);
            }
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return arrivalSchedule;
    }
    
    /**
     * Method to update arrival schedule details
     * 
     * @param arrivalSchedule
     * @param arrivalScheduleId
     * @param userid
     * @param contractId
     * @return
     * @throws BaseClassException
     */
    public int updateArrivalSchedule(ArrivalSchedule arrivalSchedule ,
                        String userid , String contractCategory)
                        throws BaseClassException
    {
        logger.info(":::::::::::::::::::::: updateArrivalSchedule repository ::::::::::::::::::::::::");
        Date today = new java.util.Date();
        long t = today.getTime();
        int rsult = 0;
        int quantity = 0;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            ArrivalSchedule arrivalSchedule2 = jdbcTemplate.queryForObject(
                                DSCConstants.ARRIVAL_COMPARE_TOTALQTY,
                                new Object[]
                                { arrivalSchedule.getContractId(),
                                                contractCategory },
                                new BeanPropertyRowMapper<ArrivalSchedule>(
                                                    ArrivalSchedule.class));
            quantity = arrivalSchedule2.getApprovedQuantity()
                                + arrivalSchedule.getApprovedQuantity();
            
            if (arrivalSchedule2.getContractTotalQty() > arrivalSchedule2
                                .getApprovedQuantity()
                                && arrivalSchedule2.getContractTotalQty() >= quantity)
            {
                rsult = jdbcTemplate.update(
                                    DSCConstants.ARRIVAL_SCHDL_UPDATE_QUERY,
                                    new Object[]
                                    { arrivalSchedule.getCommodity(),
                                                    arrivalSchedule.getApprovedQuantity(),
                                                    arrivalSchedule.getTendered(),
                                                    arrivalSchedule.getShipmentPeriod(),
                                                    arrivalSchedule.getVesselName(),
                                                    arrivalSchedule.getWareHouse(),
                                                    arrivalSchedule.getEtaDate(),
                                                    arrivalSchedule.getEtaTime(),
                                                    userid,
                                                    new java.sql.Date(t),
                                                    arrivalSchedule.getDeliveryBasis(),
                                                    arrivalSchedule.getContractId(),
                                                    arrivalSchedule.getArrivalScheduleId() });
                                    
            } else
            {
                rsult = 0;
            }
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return rsult;
    }
    
    /**
     * Method to delete arrival schedule details
     * 
     * @param arrivalScheduleId
     * @param contractId
     * @return
     * @throws BaseClassException
     */
    public int deleteArrivalSchedule(int arrivalScheduleId , int contractId)
                        throws BaseClassException
    {
        logger.info(":::::::::::::::::::::: deleteArrivalSchedule repository ::::::::::::::::::::::::");
        int rsult = 0;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            rsult = jdbcTemplate.update(DSCConstants.ARRIVAL_SCHDL_DELETE_QUERY,
                                new Object[]
                                { arrivalScheduleId, contractId });
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return rsult;
    }
    
    /**
     * Method to get arrival schedule list
     * 
     * @param arrivalScheduleId
     * @param userid
     * @return
     * @throws BaseClassException
     * @throws Exception
     */
    public List<ArrivalSchedule> getArrivalScheduleList(int contractId ,
                        String userid , String basiscode)
                        throws BaseClassException
    {
        List<ArrivalSchedulePickup> arrivalSchedulePickups = null;
        List<ArrivalSchedule> arrivalScheduleList = new ArrayList<ArrivalSchedule>();
        List<PickUpSchedule> pickUpSchedules = null;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        StringBuilder var1 = new StringBuilder();
        ArrivalSchedule arrivalSchedule = null;
        int arrivalScheduleId = 0;
        logger.info(":::::::::::::::::::::: getArrivalScheduleList repository ::::::::::::::::::::::::");
        try
        {
            if (basiscode.isEmpty())
            {
                arrivalSchedulePickups = jdbcTemplate.query(
                                    DSCConstants.ARRIVAL_SCHDL_SELECT_QUERY,
                                    new Object[]
                                    { contractId },
                                    new BeanPropertyRowMapper<ArrivalSchedulePickup>(
                                                        ArrivalSchedulePickup.class));
                                    
            } else
            {
                basiscode = var1.append(basiscode.toUpperCase()).append("%")
                                    .toString();
                
                arrivalSchedulePickups = jdbcTemplate.query(
                                    DSCConstants.ARRIVAL_SCHDL_SELECT_QUERY_WITHKEY,
                                    new Object[]
                                    { contractId, basiscode },
                                    new BeanPropertyRowMapper<ArrivalSchedulePickup>(
                                                        ArrivalSchedulePickup.class));
            }
            
            // Map<Integer,List<ArrivalSchedule>> arrivalSchedulemap = new
            // ConcurrentHashMap<>();
            
            pickUpSchedules = new ArrayList<PickUpSchedule>();
            
            if (!CollectionUtils.isEmpty(arrivalSchedulePickups))
            {
                for (ArrivalSchedulePickup arrivalSchedule1 : arrivalSchedulePickups)
                {
                    
                    if (arrivalScheduleId != arrivalSchedule1
                                        .getArrivalScheduleId())
                    {
                        
                        if (arrivalScheduleId != 0)
                        {
                            arrivalSchedule.setPickUpList(pickUpSchedules);
                            arrivalScheduleList.add(arrivalSchedule);
                            pickUpSchedules = new ArrayList<PickUpSchedule>();
                            logger.info(":::::::::::::::::::::: arrivalSchId ::::::::::::::::::::::::"
                                                + arrivalScheduleId);
                        }
                        
                        arrivalSchedule = new ArrivalSchedule();
                        arrivalSchedule.setArrivalScheduleId(arrivalSchedule1
                                            .getArrivalScheduleId());
                        arrivalSchedule.setApprovedQuantity(arrivalSchedule1
                                            .getApprovedQuantity());
                        arrivalSchedule.setArrivalSequence(arrivalSchedule1
                                            .getArrivalSequence());
                        arrivalSchedule.setCommodity(
                                            arrivalSchedule1.getCommodity());
                        arrivalSchedule.setContractId(
                                            arrivalSchedule1.getContractId());
                        arrivalSchedule.setContractTotalQty(arrivalSchedule1
                                            .getContractTotalQty());
                        arrivalSchedule.setDeliveryBasis(arrivalSchedule1
                                            .getDeliveryBasis());
                        arrivalSchedule.setDeliveryBasisCode(arrivalSchedule1
                                            .getDeliveryBasisCode());
                        arrivalSchedule.setEtaDate(
                                            arrivalSchedule1.getEtaDate());
                        arrivalSchedule.setEtaTime(
                                            arrivalSchedule1.getEtaTime());
                        arrivalSchedule.setTendered(
                                            arrivalSchedule1.getTendered());
                        arrivalSchedule.setShipmentPeriod(arrivalSchedule1
                                            .getShipmentPeriod());
                        arrivalSchedule.setVesselName(
                                            arrivalSchedule1.getVesselName());
                        arrivalSchedule.setWareHouse(
                                            arrivalSchedule1.getWareHouse());
                        arrivalScheduleId = arrivalSchedule1
                                            .getArrivalScheduleId();
                        // arrivalSchedulemap.put(arrivalSchedule1.getArrivalScheduleId(),
                        // arrivalSchedule);
                        
                    }
                    logger.info(":::::::::::::::::::::: PickupSchId ::::::::::::::::::::::::"
                                        + arrivalScheduleId + "-"
                                        + arrivalSchedule1.getPickUpId());
                    
                    if (arrivalSchedule1.getPickUpId() != null)
                    {
                        PickUpSchedule pickUpSchedule = new PickUpSchedule();
                        pickUpSchedule.setApprovedPickUpDate(arrivalSchedule1
                                            .getApprovedPickUpDate());
                        pickUpSchedule.setArrivalScheduleId(arrivalSchedule1
                                            .getArrivalScheduleId());
                        pickUpSchedule.setContractId(arrivalSchedule1.getContractId());
                        // pickUpSchedule.setDocument(null);
                        pickUpSchedule.setPickUpDate(
                                            arrivalSchedule1.getPickUpDate());
                        pickUpSchedule.setFileName(
                                            arrivalSchedule1.getFileName());
                        pickUpSchedule.setPickUpId(Integer.parseInt(
                                            arrivalSchedule1.getPickUpId()));
                        pickUpSchedule.setPickUpQty(
                                            arrivalSchedule1.getPickUpQty());
                        pickUpSchedule.setStatus(arrivalSchedule1.getStatus());
                        pickUpSchedule.setAuthorizationNumber(arrivalSchedule1.getAuthorizationNumber());
                        pickUpSchedules.add(pickUpSchedule);
                        
                    }
                    //
                }
                
                arrivalSchedule.setPickUpList(pickUpSchedules);
                arrivalScheduleList.add(arrivalSchedule);
                
                // arrivalSchedulemap.put(arrivalScheduleId, arrivalSchedules);
            }
            
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return arrivalScheduleList;
    }
    
}
