/*
 * IMarketInformation.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.service;

import java.util.List;

import com.cargill.customerfacing.dscportal.domain.MarketInformation;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;

public interface IMarketInformation
{
    
    public MarketInformation insertMarketInformation(MarketInformation marketInformation ,
                        String userid , String contractCategory)
                        throws BaseClassException;
    
    public int updateMarketInformation(MarketInformation marketInformation ,
                         String userid , String contractCategory)
                        throws BaseClassException;
    
    public int deleteMarketInformation(int marketId , String userid)
                        throws BaseClassException;
    
    public List<MarketInformation> getMarketInfoList(String contractCategory)
                        throws BaseClassException;
    
}
