/*
 * InvoiceRepository.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;

import com.cargill.customerfacing.dscportal.domain.DSCConstants;
import com.cargill.customerfacing.dscportal.domain.Invoice;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.domain.User;

@Repository
public class InvoiceRepository
{
    
    private static Logger logger = LoggerFactory
                        .getLogger(InvoiceRepository.class);
    
    @Autowired
    JdbcTemplate jdbcTemplate;
    
    /**
     * Method to get invoice list
     * 
     * @param contractId
     * @param userid
     * @return
     * @throws BaseClassException
     * @throws Exception
     */
    public List<Invoice> getInvoiceList(int contractId , String userid ,
                        String customerId ,
                        String customerName, int invoiceId , int limit ,
                        int index,int month,int year,String direction) throws BaseClassException
    {
        List<Invoice> invoices = null;
        logger.info(":::::::::::::::::::::: getInvoiceList repository ::::::::::::::::::::::::");
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        //boolean isCustomerUser = user.isCustomerUser();
        boolean isCustomerUser = false;
        StringBuilder query = new StringBuilder();
        query.append(DSCConstants.INVOICE_SELECT_QUERY);
        
        if (contractId != 0)
        {
            query.append(DSCConstants.CONTRACTID_APPEND);
        }
        
        if (!customerId.isEmpty())
        {
            query.append(DSCConstants.CUSTOMERID_APPEND);
        }
        
        if (invoiceId != 0)
        {
            query.append(DSCConstants.INVOICE_ID_APPEND);
        }
        
        if(!customerName.isEmpty()) {
            query.append(DSCConstants.CUSTOMER_NAME_APPEND);
        }
        
        if(month !=0 && year !=0) {            
            query.append(DSCConstants.INVOICE_MONTHYEAR_QUERY);
        }
        
        if (isCustomerUser)
        {
            query.append(DSCConstants.UNIVERSAL_SECURITY_QUERY);
        }
        
        if(direction.isEmpty()) {
            query.append(DSCConstants.INVOICE_ORDERBY_APPEND);
            query.append(DSCConstants.ASCDESC);
        }else {
            query.append(DSCConstants.INVOICE_ORDERBY_APPEND);
            query.append(direction);
        }
        
        if (limit > 0)
        {
            query.append(DSCConstants.QUERY_LIMIT_APPEND);
        }
        try
        {
            PreparedStatementSetter pss = new PreparedStatementSetter()
            {
                public void setValues(PreparedStatement preparedStatement)
                                    throws SQLException
                {
                    int i = 0;
                    if (contractId != 0)
                    {
                        i++;
                        preparedStatement.setInt(i, contractId);
                    }
                    
                    if (!customerId.isEmpty())
                    {
                        i++;
                        preparedStatement.setString(i, customerId);
                    }
                    
                    if (invoiceId != 0)
                    {
                        i++;
                        preparedStatement.setInt(i, invoiceId);
                    }
                    
                    if(!customerName.isEmpty()) {
                        i++;
                        preparedStatement.setString(i, "%"+customerName.toUpperCase().concat("%"));
                    }
                    
                    if(month !=0 && year !=0) {  
                        i++;
                        preparedStatement.setInt(i, month);
                        i++;
                        preparedStatement.setInt(i, year);
                    }
                    
                    if (isCustomerUser)
                    {
                        i++;
                        preparedStatement.setString(i, userid);
                    }
                    
                    if (limit > 0)
                    {
                        int offset = (index == 0) ? 0 : index - 1;
                        i++;
                        preparedStatement.setInt(i, limit);
                        i++;
                        preparedStatement.setInt(i, offset);
                    }
                    
                }
            };
            
            invoices = jdbcTemplate.query(query.toString(), pss,
                                new BeanPropertyRowMapper<Invoice>(
                                                    Invoice.class));
            
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return invoices;
    }
    
    /**
     * Method to insert invoice details
     * 
     * @param contractId
     * @param invoice
     * @param userid
     * @return
     * @throws BaseClassException
     */
    public Invoice insertInvoice(Invoice invoice , String userid)
                        throws BaseClassException
    {
        Date today = new java.util.Date();
        long t = today.getTime();
        int nextval = 0;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            logger.info(":::::::::::::::::::::: insertInvoice repository ::::::::::::::::::::::::");
            nextval = jdbcTemplate.queryForObject(DSCConstants.INVOICE_NEXTVAL,
                                new Object[]
                                {}, Integer.class);
                                
            invoice.setResult(jdbcTemplate.update(
                                DSCConstants.INVOICE_INSERT_QUERY, new Object[]
                                { nextval, invoice.getInvoiceNo(),
                                                invoice.getInvoiceDate(),
                                                invoice.getCommodityQty(),
                                                invoice.getInvoiceAmount(),
                                                invoice.getCommodityName(),
                                                invoice.getFileName(),
                                                invoice.getContractId(), userid,
                                                new java.sql.Date(t), userid,
                                                new java.sql.Date(t) }));
            if (invoice.getResult() > 0)
            {
                invoice.setNextval(nextval);
            }
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return invoice;
    }
    
    /**
     * Method to update invoice details
     * 
     * @param invoice
     * @param contractId
     * @param userid
     * @return
     * @throws BaseClassException
     */
    public int updateInvoice(Invoice invoice , String userid)
                        throws BaseClassException
    {
        Date today = new java.util.Date();
        long t = today.getTime();
        int rsult = 0;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            logger.info(":::::::::::::::::::::: updateInvoice repository ::::::::::::::::::::::::");
            rsult = jdbcTemplate.update(DSCConstants.INVOICE_UPDATE_QUERY,
                                new Object[]
                                { invoice.getInvoiceNo(),
                                                invoice.getInvoiceDate(),
                                                invoice.getCommodityQty(),
                                                invoice.getInvoiceAmount(),
                                                invoice.getCommodityName(),
                                                userid, new java.sql.Date(t),
                                                invoice.getInvoiceId(),
                                                invoice.getContractId() });
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return rsult;
    }
    
    /**
     * This method is used to delete invoice
     * 
     * @param contractId
     * @param userid
     */
    public int deleteInvoice(int invoiceId ,String userid)
                        throws BaseClassException
    {
        Date today = new java.util.Date();
        long t = today.getTime();
        int rsult = 0;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            rsult = jdbcTemplate.update(DSCConstants.INVOICE_DELETE_QUERY,
                                new Object[]
                                { invoiceId });
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return rsult;
    }
    
}
