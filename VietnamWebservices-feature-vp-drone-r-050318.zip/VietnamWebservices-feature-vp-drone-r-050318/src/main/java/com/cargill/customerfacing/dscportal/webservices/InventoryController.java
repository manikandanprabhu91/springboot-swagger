/*
 * InventoryController.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.webservices;

import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cargill.customerfacing.dscportal.domain.DSCConstants;
import com.cargill.customerfacing.dscportal.domain.Inventory;
import com.cargill.customerfacing.dscportal.domain.ResponseGateway;
import com.cargill.customerfacing.dscportal.domain.Summary;
import com.cargill.customerfacing.dscportal.domain.User;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.region.factory.RegionFactoryService;

@RestController
@EnableAutoConfiguration
@RequestMapping(value = "/api/dxo/dsc/v1/auth")
public class InventoryController
{
    
    private Logger logger = LoggerFactory.getLogger(InventoryController.class);
    
    @Autowired
    RegionFactoryService regionFactoryService;
    
    private ResponseGateway gateway;
    private User user;
    
    /**
     * Method to get inventory list
     * 
     * @param contractId
     * @param customerId
     * @param inventoryId
     * @param contractCategory
     * @param userid
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/inventoryList", method = RequestMethod.GET, produces = DSCConstants.APPLICATION_JSON)
    public @ResponseBody
    ResponseEntity<ResponseGateway> getInventoryList(
                        @RequestParam(value = "contractId", required = false)
                        Integer contractId ,
                        @RequestParam(value = "customerId", required = false)
                        String customerId ,
                        @RequestParam(value = "inventoryId", required = false)
                        Integer inventoryId , 
                        @RequestParam("contractCategory")
                        String contractCategory , 
                        @RequestParam("userid")
                        String userid ,
                        @RequestParam(value = "limit", required = false)
                        Integer limit ,
                        @RequestParam(value = "offset", required = false)
                        Integer offset ,
                        @RequestParam(value = "searchCriteria", required = false)
                        String searchCriteria,
                        @RequestParam(value = "sortby", required = false)
                        String sortby,
                        @RequestParam(value = "direction", required = false)
                        String direction) throws BaseClassException
    {
        gateway = new ResponseGateway();
        
        user = new User(userid, true);
        
        logger.info(":::::::::: getInventoryList :::::::::::::::");
        List<Inventory> inventories = null;
        ResponseEntity<ResponseGateway> responseGateway = null;
        try
        {
            if (contractId == null)
            {
                contractId = 0;
            }
            if (customerId == null)
            {
                customerId = "";
            }
            if (inventoryId == null)
            {
                inventoryId = 0;
            }
            if (limit == null)
            {
                limit = 0;
            }
            if (offset == null)
            {
                offset = 0;
            }
            if (searchCriteria == null)
            {
                searchCriteria = "";
            }
            if (sortby == null)
            {
                sortby = "";
            }
            if (direction == null)
            {
                direction = "";
            }
            inventories = regionFactoryService.getInventory(contractCategory)
                                .getInventoryList(contractId, customerId,
                                                    inventoryId,
                                                    contractCategory, user,
                                                    limit, offset,
                                                    searchCriteria,sortby,direction);
            if (inventories != null && !inventories.isEmpty())
            {
                responseGateway = gateway.buildResponse(inventories,
                                    DSCConstants.SUCCESS, "",
                                    DSCConstants.CODE200, "");
            } else
            {
                responseGateway = gateway.buildResponse(inventories,
                                    DSCConstants.FAIL, DSCConstants.NORESULT,
                                    DSCConstants.CODE200, DSCConstants.F101);
            }
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR,
                                DSCConstants.SERVERERROR, DSCConstants.CODE500,
                                DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to insert inventory details
     * 
     * @param contractId
     * @param inventory
     * @param contractCategory
     * @param userid
     * @return
     */
    @RequestMapping(value = "/inventory", method = RequestMethod.POST, produces = DSCConstants.APPLICATION_JSON, consumes = DSCConstants.APPLICATION_JSON)
    public @ResponseBody
    ResponseEntity<ResponseGateway> insertInventory(@RequestParam("contractId")
    int contractId , @RequestBody
    Inventory inventory , @RequestParam("contractCategory")
    String contractCategory , @RequestParam("userid")
    String userid) throws BaseClassException
    {
        logger.info(":::::::::: insertInventory :::::::::::::::");
        ResponseEntity<ResponseGateway> responseGateway = null;
        Inventory insertstaus = null;
        gateway = new ResponseGateway();
        try
        {
            insertstaus = regionFactoryService.getInventory(contractCategory)
                                .insertInventory(contractId, inventory, userid);
            if (insertstaus.getResult() > 0)
            {
                responseGateway = gateway.buildResponse(null,
                                    DSCConstants.SUCCESS,
                                    DSCConstants.SUCCESS_SAVE,
                                    DSCConstants.CODE200,
                                    String.valueOf(insertstaus.getNextval()));
            } else
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.FAIL,
                                    DSCConstants.NOTUPDATED,
                                    DSCConstants.CODE200, DSCConstants.F102);
            }
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR,
                                DSCConstants.SERVERERROR, DSCConstants.CODE500,
                                DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to update inventory details
     * 
     * @param contractId
     * @param inventoryId
     * @param inventory
     * @param contractCategory
     * @param userid
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/updateInventory", method = RequestMethod.PATCH, produces = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> updateInventory(@RequestBody
    Inventory inventory , @RequestParam("contractCategory")
    String contractCategory , @RequestParam("userid")
    String userid) throws BaseClassException
    {
        logger.info(":::::::::: updateInventory :::::::::::::::");
        ResponseEntity<ResponseGateway> responseGateway = null;
        int updatestatus = 0;
        gateway = new ResponseGateway();
        try
        {
            updatestatus = regionFactoryService.getInventory(contractCategory)
                                .updateInventory(inventory, userid);
            if (updatestatus > 0)
            {
                responseGateway = gateway.buildResponse(null,
                                    DSCConstants.SUCCESS,
                                    DSCConstants.SUCCESS_UPDATE,
                                    DSCConstants.CODE200,
                                    String.valueOf(inventory.getInventoryId()));
            } else
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.FAIL,
                                    DSCConstants.NOTUPDATED,
                                    DSCConstants.CODE200, DSCConstants.F102);
            }
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR,
                                DSCConstants.SERVERERROR, DSCConstants.CODE500,
                                DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * 
     * @param contractCategory
     * @param userid
     * @return
     * @throws BaseClassException
     */
    @RequestMapping(value = "/summaryAndTotalInventory", method = RequestMethod.GET, produces = DSCConstants.APPLICATION_JSON)
    public @ResponseBody
    ResponseEntity<ResponseGateway> getSummaryAndTotalInventory(
                        @RequestParam("contractCategory")
                        String contractCategory , @RequestParam("userid")
                        String userid,
                        @RequestParam(value = "searchCriteria", required = false)
                        String searchCriteria,
                        @RequestParam(value = "contractId", required = false)
                        Integer contractId) throws BaseClassException
    {
        gateway = new ResponseGateway();
        
        user = new User(userid, true);
        
        logger.info(":::::::::: getSummaryAndTotalInventory :::::::::::::::");
        List<Summary> summaries = null;
        ResponseEntity<ResponseGateway> responseGateway = null;
        try
        {
            if(contractId == null) {
                contractId = 0;
            }
            if(searchCriteria == null) {
                searchCriteria = "";
            }
            summaries = regionFactoryService.getInventory(contractCategory)
                                .getSummaryAndTotalInventory(contractCategory,
                                                    user,searchCriteria,contractId);
            if (summaries != null && !summaries.isEmpty())
            {
                responseGateway = gateway.buildResponse(summaries,
                                    DSCConstants.SUCCESS, "",
                                    DSCConstants.CODE200, "");
            } else
            {
                responseGateway = gateway.buildResponse(summaries,
                                    DSCConstants.FAIL, DSCConstants.NORESULT,
                                    DSCConstants.CODE200, DSCConstants.F101);
            }
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR,
                                DSCConstants.SERVERERROR, DSCConstants.CODE500,
                                DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to get inventory list
     * 
     * @param contractId
     * @param customerId
     * @param inventoryId
     * @param contractCategory
     * @param userid
     * @return
     * @throws IOException
     * @throws Exception
     */
    @RequestMapping(value = "/downloadInventoryCSV", method = RequestMethod.GET, produces = "text/csv")
    public void downloadInventoryCSV(
                        @RequestParam(value = "contractId", required = false)
                        Integer contractId ,
                        @RequestParam(value = "customerId", required = false)
                        String customerId ,
                        @RequestParam(value = "inventoryId", required = false)
                        Integer inventoryId , @RequestParam("contractCategory")
                        String contractCategory , @RequestParam("userid")
                        String userid , HttpServletResponse response ,
                        @RequestParam(value = "searchCriteria", required = false)
                        String searchCriteria)
                        throws BaseClassException , IOException
    {
        user = new User(userid, true);
        
        logger.info(":::::::::: downloadInventoryCSV :::::::::::::::");
        List<Inventory> inventories = null;
        OutputStream outputStream = null;
        try
        {
            if (contractId == null)
            {
                contractId = 0;
            }
            if (customerId == null)
            {
                customerId = "";
            }
            if (inventoryId == null)
            {
                inventoryId = 0;
            }
            int limit = 0;
            int offset = 0;
            if (searchCriteria == null)
            {
                searchCriteria = "";
            }
            String sortby = "";
            String direction ="";
            SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-DD");
            String outputResult = "Cargo,VehicleType,VehicleNo,Mode,Remarks,TimeInDate,WeightIn,WeightOut,TotalWeight,TimeOutDate,TimeInTime,TimeOutTime,Packing,Location,PickupId,CakNo,InventoryId,ContractId,NetWeight,EtaDate,DeliveredVolume,EtaTime\n";
            inventories = regionFactoryService.getInventory(contractCategory)
                                .getInventoryList(contractId, customerId,
                                                    inventoryId,
                                                    contractCategory, user,
                                                    limit, offset,
                                                    searchCriteria,sortby,direction);
            
            if (inventories != null && !inventories.isEmpty())
            {
                response.setContentType("text/csv");
                response.setHeader("Content-Disposition",
                                    "attachment; filename=\"InventoryReport.csv\"");
                outputStream = response.getOutputStream();
                
                StringBuilder sb = new StringBuilder();
                for (Inventory inv : inventories)
                {
                    sb.append(inv.getCargo()).append(",")
                                        .append(inv.getVehicleType())
                                        .append(",").append(inv.getVehicleNo())
                                        .append(",").append(inv.getMode())
                                        .append(",").append(inv.getRemarks())
                                        .append(",")
                                        .append(sdf.format(sdf.parse(inv
                                                            .getTimeInDate())))
                                        .append(",").append(inv.getWeightIn())
                                        .append(",").append(inv.getWeightOut())
                                        .append(",")
                                        .append(inv.getTotalWeight())
                                        .append(",")
                                        .append(inv.getTimeOutDate())
                                        .append(",").append(inv.getTimeInTime())
                                        .append(",")
                                        .append(inv.getTimeOutTime())
                                        .append(",").append(inv.getPacking())
                                        .append(",").append(inv.getLocation())
                                        .append(",").append(inv.getPickUpId())
                                        .append(",").append(inv.getCakNo())
                                        .append(",")
                                        .append(inv.getInventoryId())
                                        .append(",").append(inv.getContractId())
                                        .append(",").append(inv.getNetWeight())
                                        .append(",").append(inv.getEtaDate())
                                        .append(",")
                                        .append(inv.getDeliveredVolume())
                                        .append(",").append(inv.getEtaTime())
                                        .append("\n");
                }
                
                outputResult += sb.toString();
                outputStream.write(outputResult.getBytes());
                logger.info(":::::::::: Successfully inventory report generated :::::::::::::::");
            } else
            {
                logger.info(":::::::::: Inventory report not generated due to empty list:::::::::::::::");
            }
        } catch (Exception e)
        {
            logger.info(":::::::::: Error in inventory report :::::::::::::::"
                                + e.toString());
        } finally
        {
            if (outputStream != null)
            {
                outputStream.flush();
                outputStream.close();
            }
        }
    }
    
    /**
     * Delete set flag = 'N'
     * @param inventoryId
     * @param contractCategory
     * @param userid
     * @return
     * @throws BaseClassException
     */
    @RequestMapping(value = "/inventory", method = RequestMethod.DELETE, produces = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> deleteInventory(
                        @RequestParam("inventoryId")
                        int inventoryId , @RequestParam("contractCategory")
                        String contractCategory , @RequestParam("userid")
                        String userid) throws BaseClassException
    {
        logger.info(":::::::::: deleteInventory :::::::::::::::");
        int deletestatus = 0;
        gateway = new ResponseGateway();
        ResponseEntity<ResponseGateway> responseGateway = null;
        try
        {
            deletestatus = regionFactoryService
                                .getInventory(contractCategory)
                                .deleteInventory(inventoryId, userid);
            if (deletestatus > 0)
            {
                responseGateway = gateway.buildResponse(null,
                                    DSCConstants.SUCCESS,
                                    DSCConstants.SUCCESS_DELETE,
                                    DSCConstants.CODE200,
                                    String.valueOf(inventoryId));
            } else
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.FAIL,
                                    DSCConstants.NOTUPDATED,
                                    DSCConstants.CODE200, DSCConstants.F102);
            }
        } catch (Exception e)
        {
            responseGateway = gateway.buildResponse(null, DSCConstants.ERROR,
                                DSCConstants.SERVERERROR, DSCConstants.CODE500,
                                DSCConstants.E100);
        }
        return responseGateway;
    }
}
