/*
 * UserProfileRepository.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.repository;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cargill.customerfacing.dscportal.domain.DSCConstants;
import com.cargill.customerfacing.dscportal.domain.Inventory;
import com.cargill.customerfacing.dscportal.domain.UserConfig;
import com.cargill.customerfacing.dscportal.domain.UserProfile;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;

@Repository
public class UserProfileRepository
{
    
    private static Logger logger = LoggerFactory
                        .getLogger(UserProfileRepository.class);
    
    @Autowired
    JdbcTemplate jdbcTemplate;
    
    /**
     * This method is to get user config details
     * 
     * @param contractCategory
     * @param userid
     * @return
     * @throws Exception
     */
    public List<UserConfig> getUserConfig(String contractCategory ,
                        String userid) throws BaseClassException
    {
        logger.info(":::::::::::::::::::::: getUserConfig repository ::::::::::::::::::::::::");
        List<UserConfig> configs = null;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            configs = jdbcTemplate.query(DSCConstants.USERCONFIG_SELECT_QUERY,
                                new Object[]
                                { userid, contractCategory },
                                new BeanPropertyRowMapper<UserConfig>(
                                                    UserConfig.class));
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return configs;
    }
    
    /**
     * Method to update user config details
     * 
     * @param userConfig
     * @param userConfigId
     * @param contractCategory
     * @param userid
     * @return
     * @throws BaseClassException
     */
    public int updateUserConfig(UserConfig userConfig ,
                        String contractCategory , String userid)
                        throws BaseClassException
    {
        Date today = new java.util.Date();
        long t = today.getTime();
        int rsult = 0;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            logger.info(":::::::::::::::::::::: updateUserConfig ::::::::::::::::::::::::");
            rsult = jdbcTemplate.update(DSCConstants.USERCONFIG_UPDATE_QUERY,
                                new Object[]
                                { userConfig.getScreenId(),
                                                userConfig.getSectionId(),
                                                userConfig.getAttributeId(),
                                                userConfig.getAttributeValue(),
                                                userid, new java.sql.Date(t),
                                                userConfig.getUserConfigId(),
                                                userid, contractCategory });
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return rsult;
    }
    
    /**
     * Method to insert User Profile details
     * 
     */
    public UserProfile insertUserProfile(UserProfile userProfile ,
                        String userid) throws BaseClassException
    {
        Date today = new java.util.Date();
        long t = today.getTime();
        int nextval = 0;
        logger.info(":::::::::::::::::::::: insertInventory repository ::::::::::::::::::::::::");
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            nextval = jdbcTemplate.queryForObject(
                                DSCConstants.USER_PROFILE_NEXTVAL, new Object[]
                                {}, Integer.class);
                                
            userProfile.setResult(jdbcTemplate.update(
                                DSCConstants.USER_PROFILE_INSERT_QUERY,
                                new Object[]
                                { nextval, userProfile.getUserId(),
                                                userProfile.getEmail(), 'Y',
                                                userProfile.getCargillUser(),
                                                userid, new java.sql.Date(t),
                                                userid, new java.sql.Date(t),
                                                userProfile.getCustomerId() }));
            if (userProfile.getResult() > 0)
            {
                userProfile.setNextVal(nextval);
            }
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return userProfile;
    }
    
    /**
     * 
     * @param userConfig
     * @param contractCategory
     * @param userid
     * @return
     * @throws BaseClassException
     */
    public int updateUserProfile(UserProfile userProfile , String userid)
                        throws BaseClassException
    {
        Date today = new java.util.Date();
        long t = today.getTime();
        int rsult = 0;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            logger.info(":::::::::::::::::::::: updateUserConfig ::::::::::::::::::::::::");
            rsult = jdbcTemplate.update(DSCConstants.USER_PROFILE_UPDATE_QUERY,
                                new Object[]
                                { userProfile.getUserId(),
                                                userProfile.getEmail(),
                                                userProfile.getCargillUser(),userProfile.getCustomerId(),
                                                userid, new java.sql.Date(t),  "Y",                                            
                                                userProfile.getUserProfileId() });
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return rsult;
    }
    
}
