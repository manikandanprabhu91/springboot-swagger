/*
 * ArrivalSchedule.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.domain;

import java.util.List;

public class ArrivalSchedule extends BaseModel
{
    
    private String commodity;
    private String tendered;
    private int approvedQuantity;
    private String shipmentPeriod;
    private String vesselName;
    private String wareHouse;
    private String etaDate;
    private String etaTime;
    private int arrivalScheduleId;
    private int contractId;
    private String deliveryBasis;
    private int arrivalSequence;
    private String deliveryBasisCode;
    private int contractTotalQty;
    private List<PickUpSchedule> pickUpList;
    private int result;
    private int nextval;
    private String cakNo;
    
    
    public int getArrivalScheduleId()
    {
        return arrivalScheduleId;
    }
    public void setArrivalScheduleId(int arrivalScheduleId)
    {
        this.arrivalScheduleId = arrivalScheduleId;
    }
    
    public int getContractId()
    {
        return contractId;
    }
    public void setContractId(int contractId)
    {
        this.contractId = contractId;
    }
    public String getCommodity()
    {
        return commodity;
    }
    public void setCommodity(String commodity)
    {
        this.commodity = commodity;
    }
    public String getTendered()
    {
        return tendered;
    }
    public void setTendered(String tendered)
    {
        this.tendered = tendered;
    }
    public String getShipmentPeriod()
    {
        return shipmentPeriod;
    }
    public void setShipmentPeriod(String shipmentPeriod)
    {
        this.shipmentPeriod = shipmentPeriod;
    }
    public String getVesselName()
    {
        return vesselName;
    }
    public void setVesselName(String vesselName)
    {
        this.vesselName = vesselName;
    }
    public int getApprovedQuantity()
    {
        return approvedQuantity;
    }
    public void setApprovedQuantity(int approvedQuantity)
    {
        this.approvedQuantity = approvedQuantity;
    }
    public String getDeliveryBasis()
    {
        return deliveryBasis;
    }
    public void setDeliveryBasis(String deliveryBasis)
    {
        this.deliveryBasis = deliveryBasis;
    }
    public String getEtaDate()
    {
        return etaDate;
    }
    public void setEtaDate(String etaDate)
    {
        this.etaDate = etaDate;
    }
    public String getEtaTime()
    {
        return etaTime;
    }
    public void setEtaTime(String etaTime)
    {
        this.etaTime = etaTime;
    }
    public int getArrivalSequence()
    {
        return arrivalSequence;
    }
    public void setArrivalSequence(int arrivalSequence)
    {
        this.arrivalSequence = arrivalSequence;
    }
    public int getResult()
    {
        return result;
    }
    public void setNextval(int nextval)
    {
        this.nextval = nextval;
    }
    public String getWareHouse()
    {
        return wareHouse;
    }
    public void setWareHouse(String wareHouse)
    {
        this.wareHouse = wareHouse;
    }
    public String getDeliveryBasisCode()
    {
        return deliveryBasisCode;
    }
    public void setDeliveryBasisCode(String deliveryBasisCode)
    {
        this.deliveryBasisCode = deliveryBasisCode;
    }
    public int getContractTotalQty()
    {
        return contractTotalQty;
    }
    public void setContractTotalQty(int contractTotalQty)
    {
        this.contractTotalQty = contractTotalQty;
    }
    public List<PickUpSchedule> getPickUpList()
    {
        return pickUpList;
    }
    public void setPickUpList(List<PickUpSchedule> pickUpList)
    {
        this.pickUpList = pickUpList;
    }
    public int getNextval()
    {
        return nextval;
    }
    public void setResult(int result)
    {
        this.result = result;
    }
    public String getCakNo()
    {
        return cakNo;
    }
    public void setCakNo(String cakNo)
    {
        this.cakNo = cakNo;
    }
    
}
