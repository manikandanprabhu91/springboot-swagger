/*
 * PickUpScheduleRepository.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.repository;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cargill.customerfacing.dscportal.domain.ArrivalSchedule;
import com.cargill.customerfacing.dscportal.domain.Contract;
import com.cargill.customerfacing.dscportal.domain.DSCConstants;
import com.cargill.customerfacing.dscportal.domain.PickUpSchedule;
import com.cargill.customerfacing.dscportal.domain.SetUpAlert;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;

@Repository
public class PickUpScheduleRepository
{
    
    private static Logger logger = LoggerFactory
                        .getLogger(PickUpScheduleRepository.class);
    
    @Autowired
    JdbcTemplate jdbcTemplate;
    
    @Autowired
    AlertNotificationRepository alertNotificationRepository; 
    
    /**
     * Method to insert pickup schedule details
     * 
     * @param pickUpSchedule
     * @param userid
     * @return
     * @throws BaseClassException
     */
    public PickUpSchedule insertPickUpSchedule(PickUpSchedule pickUpSchedule ,
                        String userid,String contractCategory) throws BaseClassException
    {
        Date today = new java.util.Date();
        long t = today.getTime();
        int rsult = 0;
        int quantity = 0;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        int nextval = 0;
        SetUpAlert setUpAlert = null;
        try
        {
            PickUpSchedule pickUpSchedule2 = jdbcTemplate.queryForObject(
                                DSCConstants.PICKUP_COMPARE_TOTALQTY,
                                new Object[]
                                { pickUpSchedule.getContractId(), pickUpSchedule
                                                    .getArrivalScheduleId() },
                                new BeanPropertyRowMapper<PickUpSchedule>(
                                                    PickUpSchedule.class));
            quantity = pickUpSchedule2.getPickUpQty()
                                + pickUpSchedule.getPickUpQty();
            
            if (pickUpSchedule2.getArrivalTotalQty() > pickUpSchedule2
                                .getPickUpQty()
                                && pickUpSchedule2.getArrivalTotalQty() >= quantity)
            {
                nextval = jdbcTemplate.queryForObject(
                                    DSCConstants.PICKUP_NEXTVAL, new Object[]
                                    {}, Integer.class);
                
                pickUpSchedule.setResult(jdbcTemplate.update(DSCConstants.PICKUP_INSERT_QUERY,
                                    new Object[]
                                    { nextval,pickUpSchedule.getContractId(),
                                                    pickUpSchedule.getPickUpDate(),
                                                    pickUpSchedule.getPickUpTime(),
                                                    null, "00:00",
                                                    pickUpSchedule.getFileName(),
                                                    pickUpSchedule.getPickUpQty(),
                                                    pickUpSchedule.getArrivalScheduleId(),
                                                    userid,
                                                    new java.sql.Date(t),
                                                    userid,
                                                    new java.sql.Date(t), "",
                                                    pickUpSchedule.getAuthorizationNumber() }));
                
                pickUpSchedule.setNextval(nextval);
                
                Contract con = jdbcTemplate.queryForObject(
                                    DSCConstants.CUSTOMER_VALUE,
                                    new BeanPropertyRowMapper<Contract>(
                                                        Contract.class),
                                    new Object[]
                                    { pickUpSchedule.getContractId() });
                logger.info("::::con list to getcustomer for pickup alert :::"+con);
                if(con!=null && pickUpSchedule.getResult() >0) {
                        setUpAlert = alertNotificationRepository.setupAlert(DSCConstants.PICKUP_ADD_CODE,
                                            contractCategory, con.getCustomerId(), userid, pickUpSchedule.getContractId(), 0,0, nextval);
                }
            } else
            {
                pickUpSchedule.setResult(-1);
            }
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return pickUpSchedule;
    }
    
    /**
     * Method to get pickupschedule details
     * 
     * @param contractId
     * @param userid
     * @return
     * @throws Exception
     */
    public List<PickUpSchedule> getPickUpScheduleList(int contractId ,
                        String userid) throws BaseClassException
    {
        logger.info(":::::::::::::::::::::: getPickUpScheduleList repository ::::::::::::::::::::::::");
        List<PickUpSchedule> pickUpSchedules = null;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            pickUpSchedules = jdbcTemplate.query(DSCConstants.PICKUP_GET_ALL,
                                new Object[]
                                { contractId },
                                new BeanPropertyRowMapper<PickUpSchedule>(
                                                    PickUpSchedule.class));
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return pickUpSchedules;
    }
    
    /**
     * Method to get pickupschedule by id
     * 
     * @param contractId
     * @param pickupId
     * @return
     * @throws Exception
     */
    public List<PickUpSchedule> getPickUpScheduleBYID(int contractId , int pickupId)
                        throws BaseClassException
    {
        logger.info(":::::::::::::::::::::: getPickUpScheduleBYID repository ::::::::::::::::::::::::");
        List<PickUpSchedule> pickUpSchedule = null;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            pickUpSchedule = jdbcTemplate.query(
                                DSCConstants.PICKUP_BYID, new Object[]
                                { contractId, pickupId },
                                new BeanPropertyRowMapper<PickUpSchedule>(
                                                    PickUpSchedule.class));
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return pickUpSchedule;
    }
    
    /**
     * Method to update pickupschedule
     * 
     * @param pickUpSchedule
     * @param contractId
     * @param userid
     * @return
     * @throws BaseClassException
     */
    public int updatePickUpSchedule(PickUpSchedule pickUpSchedule ,
                        int contractId , String userid,String contractCategory)
                        throws BaseClassException
    {
        Date today = new java.util.Date();
        long t = today.getTime();
        int rsult = 0;
        logger.info(":::::::::::::::::::::: updatePickUpSchedule ::::::::::::::::::::::::");
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        int quantity = 0;
        SetUpAlert setUpAlert = null;
        try
        {
            
            PickUpSchedule pickUpSchedule2 = jdbcTemplate.queryForObject(
                                DSCConstants.PICKUP_COMPARE_TOTALQTY_UPDATE,
                                new Object[]
                                { pickUpSchedule.getPickUpId(),contractId, pickUpSchedule
                                                    .getArrivalScheduleId() },
                                new BeanPropertyRowMapper<PickUpSchedule>(
                                                    PickUpSchedule.class));
            quantity = pickUpSchedule2.getPickUpQty()
                                + pickUpSchedule.getPickUpQty();
            
            if (pickUpSchedule2.getArrivalTotalQty() > pickUpSchedule2
                                .getPickUpQty()
                                && pickUpSchedule2.getArrivalTotalQty() >= quantity)
            {
                Contract con = jdbcTemplate.queryForObject(
                                    DSCConstants.CUSTOMER_VALUE,
                                    new BeanPropertyRowMapper<Contract>(
                                                        Contract.class),
                                    new Object[]
                                    { contractId });
                logger.info("::::con list to getcustomer for methods pickup alert :::"+con);
                
                if (pickUpSchedule.getStatus().equalsIgnoreCase("Agree"))
                {
                    rsult = jdbcTemplate.update(
                                        DSCConstants.UPDATE_PICKUP_STATUS,
                                        new Object[]
                                        { "Approved",pickUpSchedule.getPickUpQty(), new java.sql.Date(t),
                                                        userid,
                                                        pickUpSchedule.getPickUpId() });
                    if(con!=null && rsult >0 ) {
                        setUpAlert = alertNotificationRepository.setupAlert(DSCConstants.PICKUP_APPROVED_CODE,
                                        contractCategory, con.getCustomerId(), userid, pickUpSchedule.getContractId(), 0,0, pickUpSchedule.getPickUpId());
                    }
                } else if (pickUpSchedule.getStatus()
                                    .equalsIgnoreCase("DisAgree"))
                {
                    rsult = jdbcTemplate.update(
                                        DSCConstants.UPDATE_PICKUP_STATUS,
                                        new Object[]
                                        { "Deny",pickUpSchedule.getPickUpQty(), new java.sql.Date(t), userid,
                                                        pickUpSchedule.getPickUpId() });
                    if(con!=null && rsult >0 ) {
                    setUpAlert = alertNotificationRepository.setupAlert(DSCConstants.PICKUP_DENIED_CODE,
                                        contractCategory, con.getCustomerId(), userid, pickUpSchedule.getContractId(), 0, 0,pickUpSchedule.getPickUpId());
                    }
                } else
                {
                    rsult = jdbcTemplate.update(DSCConstants.UPDATE_PICKUP,
                                        new Object[]
                                        { "", pickUpSchedule.getPickUpQty(),
                                                        pickUpSchedule.getPickUpDate(),
                                                        pickUpSchedule.getPickUpTime(),
                                                        new java.sql.Date(t),
                                                        userid, contractId,
                                                        pickUpSchedule.getPickUpId() });
                }
            } else
            {
                rsult = -1;
            }
        } catch (
        
        CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return rsult;
    }
    
    /**
     * Method to delete pickupschedule
     * 
     * @param contractId
     * @param userid
     * @param pickupid
     * @return
     * @throws BaseClassException
     */
    public int deletePickUpSchedule(int contractId , String userid ,
                        int pickupid) throws BaseClassException
    {
        logger.info(":::::::::::::::::::::: deletePickUpSchedule ::::::::::::::::::::::::");
        Date today = new java.util.Date();
        long t = today.getTime();
        int rsult = 0;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try
        {
            rsult = jdbcTemplate.update(DSCConstants.PICKUP_DELETE, new Object[]
            { new java.sql.Date(t), userid, contractId, pickupid });
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return rsult;
    }

    /**
     * 
     * @param contractId
     * @param pickUpId
     * @return
     */
    public ArrivalSchedule generateQRCode(int contractId , int pickUpId) throws BaseClassException
    {
        ArrivalSchedule arrivalSchedule = null;
        StringBuilder var = new StringBuilder();
        var = var.append(DSCConstants.ERROR);
        try {
        arrivalSchedule = jdbcTemplate.queryForObject(
                            DSCConstants.DOWNLOAD_QRCODE,
                            new Object[]
                            { pickUpId,contractId},
                            new BeanPropertyRowMapper<ArrivalSchedule>(ArrivalSchedule.class));
        } catch (CannotGetJdbcConnectionException cannotGetJdbcConnectionException)
        {
            logger.error(var.append(
                                cannotGetJdbcConnectionException.getMessage())
                                .toString());
            throw new BaseClassException(
                                cannotGetJdbcConnectionException.getMessage()
                                                    + DSCConstants.ERROR500);
        } catch (DataAccessException accessException)
        {
            logger.error(var.append(accessException.getMessage()).toString());
            throw new BaseClassException(accessException.getMessage()
                                + DSCConstants.ERROR500);
        } catch (Exception e)
        {
            logger.error(var.append(e.getMessage()).toString());
            throw new BaseClassException(e.getMessage());
        }
        return arrivalSchedule;
    }
}
