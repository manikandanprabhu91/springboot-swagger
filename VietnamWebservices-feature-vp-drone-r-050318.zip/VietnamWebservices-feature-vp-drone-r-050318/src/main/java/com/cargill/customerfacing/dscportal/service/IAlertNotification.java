/*
 * IAlertNotification.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.service;

import java.util.List;

import com.cargill.customerfacing.dscportal.domain.SetUpAlert;
import com.cargill.customerfacing.dscportal.domain.UserAlertMapping;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;

public interface IAlertNotification
{
    
    public SetUpAlert setupAlert(int alertCode , String contractCategory ,
                        String customerId , String userid , int contractId ,
                        int paymentId , int invoiceId,int addon)
                        throws BaseClassException;
    
    public List<SetUpAlert> getAlertList(String contractCategory ,
                        String userId,
                        int limit, int offset) throws BaseClassException;
    
    public int getAlertCount(String contractCategory ,
                        String userId) throws BaseClassException;
    
    public int updateAlert(int actualAlertId , String alertStatus ,
                        String userid) throws BaseClassException;
    
    public List<UserAlertMapping> getAlertUserMappingList(
                        String contractCategory , String userid)
                        throws BaseClassException;
    
    public int updateAlertUserMapping(UserAlertMapping userAlertMapping ,
                         String contractCategory ,
                        String userid) throws BaseClassException;
}
