/*
 * InvoiceController.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.webservices;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cargill.customerfacing.dscportal.domain.DSCConstants;
import com.cargill.customerfacing.dscportal.domain.Invoice;
import com.cargill.customerfacing.dscportal.domain.ResponseGateway;
import com.cargill.customerfacing.dscportal.domain.User;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.region.factory.RegionFactoryService;

@RestController
@EnableAutoConfiguration
@RequestMapping(value = "/api/dxo/dsc/v1/auth")
public class InvoiceController
{
  
  private Logger logger = LoggerFactory.getLogger(InvoiceController.class);
  
  @Autowired
  RegionFactoryService regionFactoryService;
  
  private ResponseGateway gateway;
  
  private User user;
  
  /**
   * Method to get invoice details
   * 
   * @param contractId
   * @param contractCategory
   * @param userid
   * @return
   * @throws Exception
   */
  @RequestMapping(value = "/invoiceList", method = RequestMethod.GET, produces = DSCConstants.APPLICATION_JSON)
  public ResponseEntity<ResponseGateway> getInvoiceList(
            @RequestParam(value="contractId",required=false)
            Integer contractId , @RequestParam("contractCategory")
            String contractCategory , @RequestParam("userid")
            String userid,@RequestParam(value="customerId",required=false)
            String customerId,@RequestParam(value="customerName",required=false)
            String customerName,@RequestParam(value="invoiceId",required=false) Integer invoiceId,@RequestParam(value = "limit", required = false)
            Integer limit,@RequestParam(value = "offset", required = false)
            Integer offset,@RequestParam(value="month",required=false) Integer month ,
            @RequestParam(value="year",required=false) Integer  year,@RequestParam(value="direction",required=false) String direction) throws BaseClassException
  {
    gateway = new ResponseGateway();
    logger.info(":::::::::: getInvoiceList :::::::::::::::");
    ResponseEntity<ResponseGateway> responseGateway = null;
    //user = new User(userid, true);
    List<Invoice> invoicelist = null;
    try
    {
        if(contractId == null) {
            contractId = 0;
        }
        if(customerId == null) {
            customerId = "";
        }
        if(customerName == null) {
            customerName = "";
        }
        if(invoiceId == null) {
            invoiceId = 0;
        }
        if(limit == null) {
            limit = 0;
        }
        if(offset==null) {
            offset = 0;
        }
        if(month == null) {
            month = 0;
        }
        if(year == null) {
            year = 0;
        }
        if(direction == null) {
            direction = "";
        }
      invoicelist = regionFactoryService.getInvoice(contractCategory)
                .getInvoiceList(contractId, userid, customerId,customerName, invoiceId,limit,offset,month,year,direction);
      if (invoicelist != null && !invoicelist.isEmpty())
      {
          responseGateway = gateway.buildResponse(invoicelist, DSCConstants.SUCCESS, "", DSCConstants.CODE200, "");
      } else
      {
          responseGateway = gateway.buildResponse(invoicelist, DSCConstants.FAIL, DSCConstants.NORESULT, DSCConstants.CODE200, DSCConstants.F101);
      }
    } catch (Exception e)
    {
        responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
    }
    return responseGateway;
  }
  
  /**
   * Method to insert invoice details
   * 
   * @param contractId
   * @param invoice
   * @param contractCategory
   * @param userid
   * @return
   */
  @RequestMapping(value = "/invoice", method = RequestMethod.POST, produces = DSCConstants.APPLICATION_JSON, consumes = DSCConstants.APPLICATION_JSON)
  public ResponseEntity<ResponseGateway> insertInvoice(@RequestBody
            Invoice invoice , @RequestParam("contractCategory")
            String contractCategory , @RequestParam("userid")
            String userid) throws BaseClassException
  {
    logger.info(":::::::::: insertInvoice :::::::::::::::");
    ResponseEntity<ResponseGateway> responseGateway = null;
    Invoice insertstaus = null;
    gateway = new ResponseGateway();
    try
    {
      insertstaus = regionFactoryService.getInvoice(contractCategory)
                .insertInvoice(invoice, userid);
      if (insertstaus.getResult() > 0)
      {
          responseGateway = gateway.buildResponse(null, DSCConstants.SUCCESS, DSCConstants.SUCCESS_SAVE, DSCConstants.CODE200, String.valueOf(insertstaus.getNextval()));
      } else
      {
          responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.NOTUPDATED, DSCConstants.CODE200, DSCConstants.F102); 
      }
    } catch (Exception e)
    {
        responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
    }
    return responseGateway;
  }
  
  /**
   * Method to update invoice details
   * 
   * @param cakNo
   * @param contract
   * @param contractCategory
   */
  @RequestMapping(value = "/updateInvoice", method = RequestMethod.PATCH, produces = DSCConstants.APPLICATION_JSON)
  public ResponseEntity<ResponseGateway> updateInvoice(@RequestBody
            Invoice invoice , @RequestParam("contractCategory")
            String contractCategory , @RequestParam("userid")
            String userid) throws BaseClassException
  {
    logger.info(":::::::::: updateInvoice :::::::::::::::");
    int updatestaus = 0;
    gateway = new ResponseGateway();
    ResponseEntity<ResponseGateway> responseGateway = null;
    try
    {
      updatestaus = regionFactoryService.getInvoice(contractCategory)
                .updateInvoice(invoice, userid);
      if (updatestaus > 0)
      {
          responseGateway = gateway.buildResponse(null, DSCConstants.SUCCESS, DSCConstants.SUCCESS_UPDATE, DSCConstants.CODE200, String.valueOf(invoice.getInvoiceId()));
      } else
      {
          responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.NOTUPDATED, DSCConstants.CODE200, DSCConstants.F102); 
      }
    } catch (Exception e)
    {
        responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
    }
    return responseGateway;
  }
  
  /**
   * 
   * @param contractId
   * @param contractCategory
   * @param userid
   * @param customerId
   * @param invoiceId
   * @param response
   * @throws BaseClassException
   * @throws IOException
   */
  @RequestMapping(value = "/downloadInvoiceCSV", method = RequestMethod.GET, produces ="text/csv")
  public void downloadInvoiceCSV(
            @RequestParam(value="contractId",required=false)
            Integer contractId , @RequestParam("contractCategory")
            String contractCategory , @RequestParam("userid")
            String userid,@RequestParam(value="customerId",required=false) String customerId,@RequestParam(value="customerName",required=false) String customerName
            ,@RequestParam(value="invoiceId",required=false) Integer invoiceId, HttpServletResponse response) throws BaseClassException, IOException
  {
    gateway = new ResponseGateway();
    logger.info(":::::::::: downloadInvoiceCSV :::::::::::::::");
    user = new User(userid, true);
    List<Invoice> invoicelist = null;
    OutputStream outputStream = null;
    try
    {
        if(contractId == null) {
            contractId = 0;
        }
        if(customerId == null) {
            customerId = "";
        }
        if(invoiceId == null) {
            invoiceId = 0;
        }
        if(customerName == null) {
            customerName = "";
        }
        
           int limit = 0;
           int offset = 0;
           int month=0;
           int year=0;
           String direction="";
      invoicelist = regionFactoryService.getInvoice(contractCategory)
                .getInvoiceList(contractId, userid, customerId,customerName, invoiceId,limit,offset,month,year,direction);
      String outputResult = "InvoiceNo,InvoiceId,InvoiceDate,InvoiceAmount,CommodityQty,CommodityName,ContractId,Filename\n";
      
      if (invoicelist != null && !invoicelist.isEmpty())
      {
          response.setContentType("text/csv");
          response.setHeader("Content-Disposition",
                              "attachment; filename=\"InvoiceReport.csv\"");
          outputStream = response.getOutputStream();
          
          StringBuilder sb = new StringBuilder();
          for (Invoice invoice : invoicelist)
          {
              sb.append(invoice.getInvoiceNo()).append(",")
                                  .append(invoice.getInvoiceId())
                                  .append(",").append(invoice.getInvoiceDate())
                                  .append(",").append(invoice.getInvoiceAmount())
                                  .append(",").append(invoice.getCommodityQty())
                                  .append(",").append(invoice.getCommodityName())
                                  .append(",").append(invoice.getContractId())
                                  .append(",").append(invoice.getFileName())
                                  .append("\n");
          }
          
          outputResult += sb.toString();
          outputStream.write(outputResult.getBytes());
          logger.info(":::::::::: Successfully Invoice report generated :::::::::::::::");
      } else
      {
          logger.info(":::::::::: Invoice report not generated due to empty list:::::::::::::::");
      }
  } catch (Exception e)
  {
      logger.info(":::::::::: Error in Invoice report :::::::::::::::"
                          + e.toString());
  } finally
  {
      if (outputStream != null)
      {
          outputStream.flush();
          outputStream.close();
      }
  }
  }
  
  /**
   * Delete Particular Invoice
   * @param inventoryId
   * @param contractCategory
   * @param userid
   * @return
   * @throws BaseClassException
   */
  @RequestMapping(value = "/invoice", method = RequestMethod.DELETE, produces = DSCConstants.APPLICATION_JSON)
  public ResponseEntity<ResponseGateway> deleteInvoice(
                      @RequestParam("invoiceId")
                      int invoiceId , @RequestParam("contractCategory")
                      String contractCategory , @RequestParam("userid")
                      String userid) throws BaseClassException
  {
      logger.info(":::::::::: deleteInvoice :::::::::::::::");
      int deletestatus = 0;
      gateway = new ResponseGateway();
      ResponseEntity<ResponseGateway> responseGateway = null;
      try
      {
          deletestatus = regionFactoryService
                              .getInvoice(contractCategory)
                              .deleteInvoice(invoiceId, userid);
          if (deletestatus > 0)
          {
              responseGateway = gateway.buildResponse(null,
                                  DSCConstants.SUCCESS,
                                  DSCConstants.SUCCESS_DELETE,
                                  DSCConstants.CODE200,
                                  String.valueOf(invoiceId));
          } else
          {
              responseGateway = gateway.buildResponse(null, DSCConstants.FAIL,
                                  DSCConstants.NOTUPDATED,
                                  DSCConstants.CODE200, DSCConstants.F102);
          }
      } catch (Exception e)
      {
          responseGateway = gateway.buildResponse(null, DSCConstants.ERROR,
                              DSCConstants.SERVERERROR, DSCConstants.CODE500,
                              DSCConstants.E100);
      }
      return responseGateway;
  }
  
}
