/*
 * IInvoice.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.service;

import java.util.List;

import com.cargill.customerfacing.dscportal.domain.Invoice;
import com.cargill.customerfacing.dscportal.domain.User;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;

public interface IInvoice
{
  
  public List<Invoice> getInvoiceList(int contractId , String userid,String customerId,String customerName,int invoiceId,int limit,int offset,int month,int year,String direction)
            throws BaseClassException;
  
  public Invoice insertInvoice( Invoice invoice , String userid)
            throws BaseClassException;
  
  public int updateInvoice(Invoice invoice, String userid)
            throws BaseClassException;

public int deleteInvoice(int invoiceId , String userid) throws BaseClassException;
  
}
