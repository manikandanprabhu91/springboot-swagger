/*
 * IContractService.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.service;

import java.util.List;

import com.cargill.customerfacing.dscportal.domain.Contract;
import com.cargill.customerfacing.dscportal.domain.Customer;
import com.cargill.customerfacing.dscportal.domain.Status;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;

public interface IContractService
{
    
    public List<Contract> getContract(int contractId , String contractCategory ,
                        String userid) throws BaseClassException;
    
    public Contract insertContract(Contract contract , String userid ,
                        String contractCategory) throws BaseClassException;
    
    public int updateContract(Contract contract , int contractId ,
                        String userid) throws BaseClassException;
    
    public int deleteContract(int contractId , String userid)
                        throws BaseClassException;
    
    public List<Contract> getContractlist(String contractType ,
                        String contractStatus , String contractCategory ,
                        String userid , String searchCriteria , int startindex ,
                        int limit) throws BaseClassException;
    
    public List<Status> getStatusList(String screen) throws BaseClassException;
    
    public List<Customer> getCustomerList(String contractCategory)
                        throws BaseClassException;

    public int getContractTotal(String contractType , String contractStatus ,
                        String contractCategory , String userid ,
                        String searchCriteria) throws BaseClassException;
    
}
