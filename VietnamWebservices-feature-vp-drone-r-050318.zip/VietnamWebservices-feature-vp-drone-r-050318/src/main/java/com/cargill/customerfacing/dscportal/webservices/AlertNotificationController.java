/*
 * AlertNotificationController.java
 * 
 * version 1.0
 * 
 * Created by Rubini on 12/11/17.
 * Copyright � 2018 Cargill, Incorporated. All Rights Reserved.
 *  
 */
package com.cargill.customerfacing.dscportal.webservices;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cargill.customerfacing.dscportal.domain.DSCConstants;
import com.cargill.customerfacing.dscportal.domain.ResponseGateway;
import com.cargill.customerfacing.dscportal.domain.SetUpAlert;
import com.cargill.customerfacing.dscportal.domain.UserAlertMapping;
import com.cargill.customerfacing.dscportal.exception.BaseClassException;
import com.cargill.customerfacing.dscportal.region.factory.RegionFactoryService;

@RestController
@EnableAutoConfiguration
@RequestMapping(value = "/api/dxo/dsc/v1/auth")
public class AlertNotificationController
{
    
    private Logger logger = LoggerFactory.getLogger(AlertNotificationController.class);
    
    @Autowired
    RegionFactoryService regionFactoryService;
    
    private ResponseGateway gateway;
    
    /**
     * Method to insert alert in setup alert table
     * 
     * @param userId
     * @param alertCode
     * @param contractCategory
     * @param customerId
     * @return
     * @throws BaseClassException
     */
    @RequestMapping(value = "/alert", method = RequestMethod.POST)
    public @ResponseBody
    ResponseEntity<ResponseGateway> insertAlerts(@RequestParam("userid")
    String userId , @RequestParam("alertCode")
    int alertCode , @RequestParam("contractCategory")
    String contractCategory , @RequestParam("customerId")
    String customerId , @RequestParam("contractId")
    int contractId , @RequestParam("paymentId")
    int paymentId , @RequestParam("invoiceId")
    int invoiceId) throws BaseClassException
    {
        gateway = new ResponseGateway();
        logger.info(":::::::::: insertAlerts :::::::::::::::");
        SetUpAlert alertNotifications = null;
        ResponseEntity<ResponseGateway> responseGateway = null;
        try
        {
            alertNotifications = regionFactoryService
                                .getAlerts(contractCategory)
                                .setupAlert(alertCode, contractCategory,
                                                    customerId, userId,
                                                    contractId, paymentId,
                                                    invoiceId,0);
            if (alertNotifications.getResult() > 0)
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.SUCCESS, DSCConstants.SUCCESS_SAVE, DSCConstants.CODE200, String.valueOf(alertNotifications.getNextval()));
            } else
            {
               responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.NOTUPDATED, DSCConstants.CODE200, DSCConstants.F102); 
            }
        } catch (Exception e)
        {
           responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to get alert list
     * 
     * @param contractCategory
     * @param userId
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/alertList", method = RequestMethod.GET, produces = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> getAlertList(
                        @RequestParam("contractCategory")
                        String contractCategory , @RequestParam("userid")
                        String userId,
                        @RequestParam(value = "limit", required = false)
                        Integer limit ,
                        @RequestParam(value = "offset", required = false)
                        Integer offset ) throws BaseClassException
    {
        logger.info(":::::::::: getAlertList :::::::::::::::");
        List<SetUpAlert> strings = null;
        gateway = new ResponseGateway();
        ResponseEntity<ResponseGateway> responseGateway = null;
        try
        {
            if (limit == null )
            {
                limit = 0;
            }
            if (offset == null)
            {
                offset = 0;
            }
            strings = regionFactoryService.getAlerts(contractCategory)
                                .getAlertList(contractCategory, userId,
                                                    limit, offset);
            if (strings != null && !strings.isEmpty())
            {
                responseGateway = gateway.buildResponse(strings, DSCConstants.SUCCESS, "", DSCConstants.CODE200, "");
            } else
            {
                responseGateway = gateway.buildResponse(strings, DSCConstants.FAIL, DSCConstants.NORESULT, DSCConstants.CODE200, DSCConstants.F101);
            }
        } catch (Exception e)
        {
           responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to get alert count
     * 
     * @param contractCategory
     * @param userId
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/alertCount", method = RequestMethod.GET, produces = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> getAlertCount(
                        @RequestParam("contractCategory")
                        String contractCategory , @RequestParam("userid")
                        String userId) throws BaseClassException
    {
        logger.info(":::::::::: getAlertCount :::::::::::::::");
        int count = 0;
        gateway = new ResponseGateway();
        ResponseEntity<ResponseGateway> responseGateway = null;
        try
        {
            count = regionFactoryService.getAlerts(contractCategory)
                                .getAlertCount(contractCategory, userId);
            if (count > 0)
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.SUCCESS, "", DSCConstants.CODE200, String.valueOf(count));
            } else
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.NORESULT, DSCConstants.CODE200, DSCConstants.F101);
            }
        } catch (Exception e)
        {
           responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to update alert details
     * 
     * @param actualAlertId
     * @param alertStatus
     * @param contractCategory
     * @param userid
     * @return
     * @throws BaseClassException
     */
    @RequestMapping(value = "/updateAlert", method = RequestMethod.PATCH, produces = DSCConstants.APPLICATION_JSON, consumes = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> updateAlert(
                        @RequestParam("actualAlertId")
                        int actualAlertId , @RequestParam("alertStatus")
                        String alertStatus , @RequestParam("contractCategory")
                        String contractCategory , @RequestParam("userid")
                        String userid) throws BaseClassException
    {
        logger.info(":::::::::: updateAlert :::::::::::::::");
        int updatestatus = 0;
        gateway = new ResponseGateway();
        ResponseEntity<ResponseGateway> responseGateway = null;
        try
        {
            updatestatus = regionFactoryService.getAlerts(contractCategory)
                                .updateAlert(actualAlertId, alertStatus,
                                                    userid);
            if (updatestatus > 0)
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.SUCCESS, DSCConstants.SUCCESS_UPDATE, DSCConstants.CODE200, String.valueOf(actualAlertId));
            } else
            {
               responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.NOTUPDATED, DSCConstants.CODE200, DSCConstants.F102); 
            }
        } catch (Exception e)
        {
           responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to update payment reminding
     * 
     * @param alertCode
     * @param paymentId
     * @param userId
     * @param contractCategory
     * @return
     * @throws BaseClassException
     */
    @RequestMapping(value = "/paymentReminding", method = RequestMethod.POST)
    public @ResponseBody
    ResponseEntity<ResponseGateway> paymentReminding(@RequestParam("paymentId")
    int paymentId , @RequestParam("userid")
    String userId , @RequestParam("contractCategory")
    String contractCategory , @RequestParam("customerId")
    String customerId) throws BaseClassException
    {
        gateway = new ResponseGateway();
        logger.info(":::::::::: paymentReminding :::::::::::::::");
        ResponseEntity<ResponseGateway> responseGateway = null;
        SetUpAlert paymentReminding = null;
        int alertCode = 100;
        try
        {
            paymentReminding = regionFactoryService.getAlerts(contractCategory)
                                .setupAlert(alertCode, contractCategory,
                                                    customerId, userId, 0,
                                                    paymentId, 0,0);
            if (paymentReminding.getResult() > 0)
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.SUCCESS, DSCConstants.SUCCESS_SAVE, DSCConstants.CODE200, String.valueOf(paymentReminding.getNextval()));
            } else
            {
               responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.NOTUPDATED, DSCConstants.CODE200, DSCConstants.F102); 
            }
        } catch (Exception e)
        {
           responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to get user mapping list
     * 
     * @param contractCategory
     * @param userid
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/alertUserMappingList", method = RequestMethod.GET, produces = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> getAlertUserMappingList(
                        @RequestParam("contractCategory")
                        String contractCategory , @RequestParam("userid")
                        String userid) throws BaseClassException
    {
        gateway = new ResponseGateway();
        logger.info(":::::::::: getAlertUserMappingList :::::::::::::::");
        List<UserAlertMapping> userAlertMappings = null;
        ResponseEntity<ResponseGateway> responseGateway =null;
        try
        {
            userAlertMappings = regionFactoryService.getAlerts(contractCategory)
                                .getAlertUserMappingList(contractCategory,
                                                    userid);
            if (userAlertMappings != null && !userAlertMappings.isEmpty())
            {
                responseGateway = gateway.buildResponse(userAlertMappings, DSCConstants.SUCCESS, "", DSCConstants.CODE200, "");
            } else
            {
                responseGateway = gateway.buildResponse(userAlertMappings, DSCConstants.FAIL, DSCConstants.NORESULT, DSCConstants.CODE200, DSCConstants.F101);
            }
        } catch (Exception e)
        {
           responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
        }
        return responseGateway;
    }
    
    /**
     * Method to update user mapping list
     * 
     * @param userAlertMapping
     * @param usermappingId
     * @param contractCategory
     * @param userid
     * @return
     * @throws BaseClassException
     */
    @RequestMapping(value = "/updateAlertUserMapping", method = RequestMethod.PATCH, produces = DSCConstants.APPLICATION_JSON, consumes = DSCConstants.APPLICATION_JSON)
    public ResponseEntity<ResponseGateway> updateAlertUserMapping(@RequestBody
    UserAlertMapping userAlertMapping,  @RequestParam("contractCategory")
    String contractCategory , @RequestParam("userid")
    String userid) throws BaseClassException
    {
        logger.info(":::::::::: updateAlertUserMapping :::::::::::::::");
        ResponseEntity<ResponseGateway> responseGateway = null;
        int updatestatus = 0;
        gateway = new ResponseGateway();
        try
        {
            updatestatus = regionFactoryService.getAlerts(contractCategory)
                                .updateAlertUserMapping(userAlertMapping,
                                                    contractCategory, userid);
            if (updatestatus > 0)
            {
                responseGateway = gateway.buildResponse(null, DSCConstants.SUCCESS, DSCConstants.SUCCESS_UPDATE, DSCConstants.CODE200, String.valueOf(userAlertMapping.getUserMappingId()));
            } else
            {
               responseGateway = gateway.buildResponse(null, DSCConstants.FAIL, DSCConstants.NOTUPDATED, DSCConstants.CODE200, DSCConstants.F102); 
            }
        } catch (Exception e)
        {
           responseGateway = gateway.buildResponse(null, DSCConstants.ERROR, DSCConstants.SERVERERROR, DSCConstants.CODE500, DSCConstants.E100);
        }
        return responseGateway;
    }
}
