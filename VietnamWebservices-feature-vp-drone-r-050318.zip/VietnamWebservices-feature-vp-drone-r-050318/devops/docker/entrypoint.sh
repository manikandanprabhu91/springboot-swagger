#!/bin/sh
############################################################################
## Script       :: entrypoint.sh                                          ##  
## Description  :: This scrip start the Vietnam Web Services JAVA process ##
##                 with required JAVA arguments                           ##
## Author       :: SapientRazorfish                                       ##
## Date         :: 06/02/2018                                             ##
## Version      :: 0.1                                                    ##
############################################################################

## function to print message
function printmsg() {
  msg=$1
  echo "${msg}"
}

## variables
JAVA_CHECK=$(which java)

## checking if all java required variables are available
printmsg "========================================="
printmsg "[INFO] => checking if all java required variables are available"
if [ ! -z "${JAVA_CHECK}" -a ! -z "${JAR_DST_LOC}" -a ! -z "${JAR_NAME}" -a ! -z "${JAVA_OPTS}" -a ! -z "${DB_CONNECTION}" -a ! -z "${DB_USERNAME}" -a ! -z "${DB_PASSWORD}" ]
then
    printmsg "[INFO] => all java required variables are available, executing java command with java_opts and jar file"
    printmsg "[INFO] => JAVA = ${JAVA_CHECK}, JAVA OPTS = ${JAVA_OPTS}, JAR NAME = ${JAR_NAME}, JAR DST LOC = ${JAR_DST_LOC}, DB CONNECTION = ${DB_CONNECTION}"
    java \
      ${JAVA_OPTS} \
      -Dspring.datasource.username="${DB_USERNAME}" \
      -Dspring.datasource.password="${DB_PASSWORD}" \
      -Dspring.datasource.url="${DB_CONNECTION}" \
      -jar ${JAR_DST_LOC}/${JAR_NAME}
    if [ $? -eq 0 ]
    then
        printmsg "[INFO] => JAVA process has been started successfully"
    else
        printmsg "[ERROR] => JAVA process is not started, please check logs"
	printmsg "========================================="
	exit 1
    fi
else
    printmsg "[WARNING] => JAVA = ${JAVA_CHECK}, JAVA OPTS = ${JAVA_OPTS}, JAR NAME = ${JAR_NAME}, JAR DST LOC = ${JAR_DST_LOC}, DB CONNECTION = ${DB_CONNECTION}"
    printmsg "[ERROR] => required java variables are not available, please see the above message which one is not available"
    printmsg "========================================="
    exit 1
fi
