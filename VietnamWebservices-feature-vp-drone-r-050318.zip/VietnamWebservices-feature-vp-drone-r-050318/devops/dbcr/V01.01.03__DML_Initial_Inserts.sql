delete from status where status_id=3 and screen='contract';

update status set status_type='USGN', description='Unsigned' where status_id=1;

ALTER TABLE contract DROP COLUMN customer_id;

ALTER TABLE contract ADD COLUMN customer_id INT;

update contract set customer_id = 1;

update contract set status_id='USGN' where contract_id =1;

update contract set commodity='SBM' where contract_id=1; 

update user_profile set customer_id = 1; 

update actual_alert set status='Unsigned' where actual_alert_id=1; 

INSERT INTO contract(
	cak_no, cak_date, commodity, quantity, contract_type_id, customer_id, status_id, contract_id, created_user, created_date, modified_user, modified_date, active_flag, contract_category, tendered_input, basis, storage_terms, tolarance, unit_price, package_type, ship_period, contract_price, destination, final_weightat, cargo_origin, currency, payment_terms, received, balance_stock, erp_contract_status)
	VALUES (2, '2018-01-12', 'Corn', 25,2,'123','USGN',2, 'rk@crgl.com', now(), 'rk@crgl.com', now(), 'Y', 'VNGOSC', 10, 'basis', null, 0, 60, null, null, 50, null, null, null, null, null, 10, 25, 1);

INSERT INTO payment(
	status, date, amount, document, filename, payment_id, created_user, created_date, modified_user, modified_date, active_flag, contract_id)
	VALUES ('NPD', '2018-01-12', '1800', null, '', 2, 'rk@crgl.com', now(), 'rk@crgl.com', now(), 'Y', 2);