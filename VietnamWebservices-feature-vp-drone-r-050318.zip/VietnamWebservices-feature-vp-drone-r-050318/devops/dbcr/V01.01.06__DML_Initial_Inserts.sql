update arrival_schedule set eta='2018-03-30';

INSERT INTO contract(
	cak_no, cak_date, commodity, quantity, contract_type_id, customer_id, status_id, contract_id, created_user, created_date, modified_user, modified_date, active_flag, contract_category, tendered_input, basis, storage_terms, tolarance, unit_price, package_type, ship_period, contract_price, destination, final_weightat, cargo_origin, currency, payment_terms, received, balance_stock, erp_contract_status)
	VALUES (3, '2018-03-12', 'SBM', 25,1,1,'USGN',3, 'rk@crgl.com', now(), 'rk@crgl.com', now(), 'Y', 'VNGOSC', 10, 'basis', null, 0, 60, null, null, 50, null, null, null, null, null, 10, 25, 1);

INSERT INTO payment(
	status, date, amount, document, filename, payment_id, created_user, created_date, modified_user, modified_date, active_flag, contract_id)
	VALUES ('NPD', '2018-03-12', '1200', null, '', 3, 'rk@crgl.com', now(), 'rk@crgl.com', now(), 'Y', 3);
	
INSERT INTO vietnamdsc.actual_alert(
	actual_alert_id, customer_id, alert_id, actual_message, contract_id, payment_id, invoice_id, created_user, created_date, modified_user, modified_date, contract_category)
	VALUES 
    (1,'1',1,'Payment Remainder Alert',1,0,0,'rk@crgl.com','2018-03-19','rk@crgl.com','2018-03-19','VNGOSC');
 
 INSERT INTO vietnamdsc.actual_alert(
	actual_alert_id, customer_id, alert_id, actual_message, contract_id, payment_id, invoice_id, created_user, created_date, modified_user, modified_date, contract_category)
	VALUES (2,'1',1,'Payment Remainder Alert',3,0,1,'rk@crgl.com','2018-03-20','rk@crgl.com','2018-03-20','VNGOSC');
	
INSERT INTO vietnamdsc.actual_alert_usermapping(
	actualalert_usermap_id, actual_alert_id, actual_user_id, web, email, sms, status_web, status_email, status_sms, created_user, created_date, modified_user, modified_date)
	VALUES (1,1,'rk@crgl.com','Y','rk@crgl.com','N','Open','N','N','rk@crgl.com','2018-03-20','rk@crgl.com','2018-03-20');

INSERT INTO vietnamdsc.actual_alert_usermapping(
	actualalert_usermap_id, actual_alert_id, actual_user_id, web, email, sms, status_web, status_email, status_sms, created_user, created_date, modified_user, modified_date)
	VALUES (2,1,'raju@crgl.com','Y','raju@crgl.com','N','Open','N','N','rk@crgl.com','2018-03-20','rk@crgl.com','2018-03-20');
	
