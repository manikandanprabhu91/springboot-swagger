delete from contract where cak_no=99;
delete from contract where cak_no=44;
delete from contract where cak_no=5;