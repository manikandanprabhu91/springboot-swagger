Alter table contract alter column cak_no type varchar(40);
Alter table setup_alert add column alert_category varchar(10);
Alter table actual_alert add column received_date date default now();

INSERT INTO vietnamdsc.setup_alert(
	alert_id, alert_code, description, web, message, created_user, created_date, modified_user, modified_date, contract_category,alert_category)
	VALUES (4,1,'Contract Uploaded Notification','Y','N','rk@crgl.com','2018-03-07','rk@crgl.com','2018-03-07','VNGOSC','Red');
	
INSERT INTO vietnamdsc.setup_alert(
	alert_id, alert_code, description, web, message, created_user, created_date, modified_user, modified_date, contract_category,alert_category)
	VALUES (5,2,'Contract Expiry Alert','Y','N','rk@crgl.com','2018-03-07','rk@crgl.com','2018-03-07','VNGOSC','Yellow');

INSERT INTO vietnamdsc.setup_alert(
	alert_id, alert_code, description, web, message, created_user, created_date, modified_user, modified_date, contract_category,alert_category)
	VALUES (6,102,'Payment Uploaded Alert','Y','N','rk@crgl.com','2018-03-07','rk@crgl.com','2018-03-07','VNGOSC','Red');
	
update setup_alert set alert_category = 'Red' where alert_id=1;
update setup_alert set alert_category = 'Red',description='Payment Sighted Alert' where alert_id=2;
update setup_alert set alert_category = 'Red',description='Total Approved Quantity Update Alert',alert_code=103 where alert_id=3;

INSERT INTO vietnamdsc.setup_alert(
	alert_id, alert_code, description, web, message, created_user, created_date, modified_user, modified_date, contract_category,alert_category)
	VALUES (7,201,'PickUp Schedule Added Alert','Y','N','rk@crgl.com','2018-03-07','rk@crgl.com','2018-03-07','VNGOSC','Yellow');
	
INSERT INTO vietnamdsc.setup_alert(
	alert_id, alert_code, description, web, message, created_user, created_date, modified_user, modified_date, contract_category,alert_category)
	VALUES (8,202,'PickUp Schedule Denied Alert','Y','N','rk@crgl.com','2018-03-07','rk@crgl.com','2018-03-07','VNGOSC','Red');
	
INSERT INTO vietnamdsc.setup_alert(
	alert_id, alert_code, description, web, message, created_user, created_date, modified_user, modified_date, contract_category,alert_category)
	VALUES (9,203,'PickUp Schedule Approved Alert','Y','N','rk@crgl.com','2018-03-07','rk@crgl.com','2018-03-07','VNGOSC','Yellow');