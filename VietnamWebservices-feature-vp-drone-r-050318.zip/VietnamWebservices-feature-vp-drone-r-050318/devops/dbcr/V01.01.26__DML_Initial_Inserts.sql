INSERT INTO vietnamdsc.user_profile(
                user_profile_id, user_id, email, active_flag, cargill_user, created_user, 
    created_date, modified_user, modified_date, customer_id)
                VALUES (11, 'vietnamtest6@cargill.com', 'vietnamtest6@cargill.com', 'Y', 'N',  'Admin',  now(), 'Admin', now(), '');
    
    INSERT INTO vietnamdsc.user_profile(
                user_profile_id, user_id, email, active_flag, cargill_user, created_user, 
    created_date, modified_user, modified_date, customer_id)
                VALUES (12, 'vietnamtest7@cargill.com', 'vietnamtest7@cargill.com', 'Y', 'N',  'Admin',  now(), 'Admin', now(), '');
    
    INSERT INTO vietnamdsc.user_profile(
                user_profile_id, user_id, email, active_flag, cargill_user, created_user, 
    created_date, modified_user, modified_date, customer_id)
                VALUES (13, 'customer@cargill.com', 'customer@cargill.com', 'Y', 'Y',  'Admin',  now(), 'Admin', now(), '1');
                
                INSERT INTO vietnamdsc.user_profile(
                user_profile_id, user_id, email, active_flag, cargill_user, created_user, 
    created_date, modified_user, modified_date, customer_id)
                VALUES (14, 'customer2@cargill.com', 'customer2@cargill.com', 'Y', 'Y',  'Admin',  now(), 'Admin', now(), '2');
                
                INSERT INTO contract(
                cak_no, cak_date, commodity, quantity, contract_type_id, status_id, contract_id, created_user, created_date, modified_user, modified_date, active_flag, contract_category, tendered_input, basis, storage_terms, tolarance, unit_price, package_type, ship_period, contract_price, destination, final_weightat, cargo_origin, currency, payment_terms, received, balance_stock, erp_contract_status, expiration_date, intransit_quantity, approvedquantity, customer_id, customer_name)
                VALUES ('C750', '2018-01-12', 'Corn', 25,2,'USGN', 750, 'Admin', now(), 'Admin', now(), 'Y', 'VNGOSC', 10, 'CDR', 'Store for 30 days', 0, 60, 'Bulk', null, 50, null, null, null, null, null, 0, 25, 1, '2018-06-30', 0, 0, '1', 'Test Customer');
    
        INSERT INTO contract(
                cak_no, cak_date, commodity, quantity, contract_type_id, status_id, contract_id, created_user, created_date, modified_user, modified_date, active_flag, contract_category, tendered_input, basis, storage_terms, tolarance, unit_price, package_type, ship_period, contract_price, destination, final_weightat, cargo_origin, currency, payment_terms, received, balance_stock, erp_contract_status, expiration_date, intransit_quantity, approvedquantity, customer_id, customer_name)
                VALUES ('C751', '2018-01-12', 'Corn', 25,2,'USGN', 751, 'Admin', now(), 'Admin', now(), 'Y', 'VNGOSC', 10, 'CDR', 'Store for 30 days', 0, 60, 'Bulk', null, 50, null, null, null, null, null, 0, 25, 1, '2018-06-30', 0, 0, '1', 'Test Customer');
    
        INSERT INTO contract(
                cak_no, cak_date, commodity, quantity, contract_type_id, status_id, contract_id, created_user, created_date, modified_user, modified_date, active_flag, contract_category, tendered_input, basis, storage_terms, tolarance, unit_price, package_type, ship_period, contract_price, destination, final_weightat, cargo_origin, currency, payment_terms, received, balance_stock, erp_contract_status, expiration_date, intransit_quantity, approvedquantity, customer_id, customer_name)
                VALUES ('C752', '2018-01-12', 'Corn', 25,2,'USGN', 752, 'Admin', now(), 'Admin', now(), 'Y', 'VNGOSC', 10, 'CDR', 'Store for 30 days', 0, 60, 'Bulk', null, 50, null, null, null, null, null, 0, 25, 1, '2018-06-30', 0, 0, '1', 'Test Customer');
    
        INSERT INTO contract(
                cak_no, cak_date, commodity, quantity, contract_type_id, status_id, contract_id, created_user, created_date, modified_user, modified_date, active_flag, contract_category, tendered_input, basis, storage_terms, tolarance, unit_price, package_type, ship_period, contract_price, destination, final_weightat, cargo_origin, currency, payment_terms, received, balance_stock, erp_contract_status, expiration_date, intransit_quantity, approvedquantity, customer_id, customer_name)
                VALUES ('C753', '2018-04-12', 'Wheat', 250,2,'SGN', 753, 'Admin', now(), 'Admin', now(), 'Y', 'VNGOSC', 10, 'CPK', 'Store for 60 days', 0, 30, 'Bulk', null, 50, null, null, null, null, null, 10, 240, 1, '2018-05-30', 10, 100, '1', 'Test Customer');
    
     INSERT INTO contract(
                cak_no, cak_date, commodity, quantity, contract_type_id, status_id, contract_id, created_user, created_date, modified_user, modified_date, active_flag, contract_category, tendered_input, basis, storage_terms, tolarance, unit_price, package_type, ship_period, contract_price, destination, final_weightat, cargo_origin, currency, payment_terms, received, balance_stock, erp_contract_status, expiration_date, intransit_quantity, approvedquantity, customer_id, customer_name)
                VALUES ('C754', '2018-04-12', 'Wheat', 250,2,'SGN', 754, 'Admin', now(), 'Admin', now(), 'Y', 'VNGOSC', 10, 'CPK', 'Store for 60 days', 0, 30, 'Bulk', null, 50, null, null, null, null, null, 150, 100, 1, '2018-05-30', 100, 100, '1', 'Test Customer'); -- Fully Approved
    
     INSERT INTO contract(
                cak_no, cak_date, commodity, quantity, contract_type_id, status_id, contract_id, created_user, created_date, modified_user, modified_date, active_flag, contract_category, tendered_input, basis, storage_terms, tolarance, unit_price, package_type, ship_period, contract_price, destination, final_weightat, cargo_origin, currency, payment_terms, received, balance_stock, erp_contract_status, expiration_date, intransit_quantity, approvedquantity, customer_id, customer_name)
                VALUES ('C755', '2018-04-12', 'Maize', 250,2,'SGN', 755, 'Admin', now(), 'Admin', now(), 'Y', 'VNGOSC', 10, 'CPK', 'Store for 60 days', 0, 30, 'Bulk', null, 50, null, null, null, null, null, 150, 100, 1, '2018-05-10', 50, 50, '1', 'Test Customer');
    
    INSERT INTO contract(
                cak_no, cak_date, commodity, quantity, contract_type_id, status_id, contract_id, created_user, created_date, modified_user, modified_date, active_flag, contract_category, tendered_input, basis, storage_terms, tolarance, unit_price, package_type, ship_period, contract_price, destination, final_weightat, cargo_origin, currency, payment_terms, received, balance_stock, erp_contract_status, expiration_date, intransit_quantity, approvedquantity, customer_id, customer_name)
                VALUES ('C756', '2018-01-2', 'Maize', 250,2,'CMP', 756, 'Admin', now(), 'Admin', now(), 'Y', 'VNGOSC', 10, 'CPK', 'Store for 60 days', 0, 30, 'Bulk', null, 50, null, null, null, null, null, 250, 0, 1, '2018-03-30', 0, 250, '1', 'Test Customer'); -- Completed
                
                INSERT INTO vietnamdsc.payment(
                status, payment_date, payment_amount, filename, payment_id, created_user, created_date, modified_user, modified_date, active_flag, contract_id, bank_name, branch_name, transaction_ref, "time")
                VALUES ('NPD','2018-05-30', 1500, '',  nextval('payment_payment_id_seq'), 'Admin', now(), 'Admin', now(), 'Y', 750, '', '', '', '11:00');
    
    INSERT INTO vietnamdsc.payment(
                status, payment_date, payment_amount, filename, payment_id, created_user, created_date, modified_user, modified_date, active_flag, contract_id, bank_name, branch_name, transaction_ref, "time")
                VALUES ('NPD','2018-05-30', 1500, '', nextval('payment_payment_id_seq'), 'Admin', now(), 'Admin', now(), 'Y', 750, '', '', '', '11:00');
    
    INSERT INTO vietnamdsc.payment(
                status, payment_date, payment_amount, filename, payment_id, created_user, created_date, modified_user, modified_date, active_flag, contract_id, bank_name, branch_name, transaction_ref, "time")
                VALUES ('NPD','2018-05-30', 1500, '', nextval('payment_payment_id_seq'), 'Admin', now(), 'Admin', now(), 'Y', 751, '', '', '', '11:00');
    
    INSERT INTO vietnamdsc.payment(
                status, payment_date, payment_amount, filename, payment_id, created_user, created_date, modified_user, modified_date, active_flag, contract_id, bank_name, branch_name, transaction_ref, "time")
                VALUES ('NPD','2018-05-30', 1500, '', nextval('payment_payment_id_seq'), 'Admin', now(), 'Admin', now(), 'Y', 752, '', '', '', '11:00');
    
    INSERT INTO vietnamdsc.payment(
                status, payment_date, payment_amount, filename, payment_id, created_user, created_date, modified_user, modified_date, active_flag, contract_id, bank_name, branch_name, transaction_ref, "time")
                VALUES ('NPD','2018-05-30', 2500, '', nextval('payment_payment_id_seq'), 'Admin', now(), 'Admin', now(), 'Y', 753, '', '', '', '11:00');
    
    INSERT INTO vietnamdsc.payment(
                status, payment_date, payment_amount, filename, payment_id, created_user, created_date, modified_user, modified_date, active_flag, contract_id, bank_name, branch_name, transaction_ref, "time")
                VALUES ('VF','2018-05-02', 2000, '', nextval('payment_payment_id_seq'), 'Admin', now(), 'Admin', now(), 'Y', 753, '', '', '', '11:00');
    
    INSERT INTO vietnamdsc.payment(
                status, payment_date, payment_amount, filename, payment_id, created_user, created_date, modified_user, modified_date, active_flag, contract_id, bank_name, branch_name, transaction_ref, "time")
                VALUES ('PD','2018-04-12', 3000, '', nextval('payment_payment_id_seq'), 'Admin', now(), 'Admin', now(), 'Y', 753, '', '', '', '11:00');
    
     INSERT INTO vietnamdsc.payment(
                status, payment_date, payment_amount, filename, payment_id, created_user, created_date, modified_user, modified_date, active_flag, contract_id, bank_name, branch_name, transaction_ref, "time")
                VALUES ('PD','2018-04-10', 3000, '', nextval('payment_payment_id_seq'), 'Admin', now(), 'Admin', now(), 'Y', 754, '', '', '', '11:00');
    
     INSERT INTO vietnamdsc.payment(
                status, payment_date, payment_amount, filename, payment_id, created_user, created_date, modified_user, modified_date, active_flag, contract_id, bank_name, branch_name, transaction_ref, "time")
                VALUES ('PD','2018-04-11', 3000, '', nextval('payment_payment_id_seq'), 'Admin', now(), 'Admin', now(), 'Y', 754, '', '', '', '11:00');
    
     INSERT INTO vietnamdsc.payment(
                status, payment_date, payment_amount, filename, payment_id, created_user, created_date, modified_user, modified_date, active_flag, contract_id, bank_name, branch_name, transaction_ref, "time")
                VALUES ('PD','2018-04-12', 1500, '', nextval('payment_payment_id_seq'), 'Admin', now(), 'Admin', now(), 'Y', 754, '', '', '', '11:00');
    
   
    INSERT INTO vietnamdsc.payment(
                status, payment_date, payment_amount, filename, payment_id, created_user, created_date, modified_user, modified_date, active_flag, contract_id, bank_name, branch_name, transaction_ref, "time")
                VALUES ('NPD','2018-05-30', 4000, '', nextval('payment_payment_id_seq'), 'Admin', now(), 'Admin', now(), 'Y', 755, '', '', '', '11:00');
    
     INSERT INTO vietnamdsc.payment(
                status, payment_date, payment_amount, filename, payment_id, created_user, created_date, modified_user, modified_date, active_flag, contract_id, bank_name, branch_name, transaction_ref, "time")
                VALUES ('VF','2018-05-02', 2000, '', nextval('payment_payment_id_seq'), 'Admin', now(), 'Admin', now(), 'Y', 755, '', '', '', '11:00');
    
     INSERT INTO vietnamdsc.payment(
                status, payment_date, payment_amount, filename, payment_id, created_user, created_date, modified_user, modified_date, active_flag, contract_id, bank_name, branch_name, transaction_ref, "time")
                VALUES ('PD','2018-04-12', 1500, '', nextval('payment_payment_id_seq'), 'Admin', now(), 'Admin', now(), 'Y', 755, '', '', '', '11:00');
    
     INSERT INTO vietnamdsc.payment(
                status, payment_date, payment_amount, filename, payment_id, created_user, created_date, modified_user, modified_date, active_flag, contract_id, bank_name, branch_name, transaction_ref, "time")
                VALUES ('PD','2018-04-10', 3000, '', nextval('payment_payment_id_seq'), 'Admin', now(), 'Admin', now(), 'Y', 756, 'BOI', 'HCMC', '1231', '11:00');
    
     INSERT INTO vietnamdsc.payment(
                status, payment_date, payment_amount, filename, payment_id, created_user, created_date, modified_user, modified_date, active_flag, contract_id, bank_name, branch_name, transaction_ref, "time")
                VALUES ('PD','2018-04-11', 3000, '', nextval('payment_payment_id_seq'), 'Admin', now(), 'Admin', now(), 'Y', 756, 'BOI', 'HCMC', '3454', '11:00');
    
     INSERT INTO vietnamdsc.payment(
                status, payment_date, payment_amount, filename, payment_id, created_user, created_date, modified_user, modified_date, active_flag, contract_id, bank_name, branch_name, transaction_ref, "time")
                VALUES ('PD','2018-04-12', 1500, '', nextval('payment_payment_id_seq'), 'Admin', now(), 'Admin', now(), 'Y', 756, 'BOI', 'HCMC', '6543', '11:00');
                
                INSERT INTO vietnamdsc.arrival_schedule(
                commodity, tendered, shipment_period, vessel_name, warehouse, eta_date, 
    arrival_schedule_id, created_user, created_date, modified_user, modified_date, contract_id, approvedquantity, delivery_basis, eta_time, arrival_sequence)
                VALUES ('Corn', 'Y', '30 days', 'AEGEAN SEA I', 'SITV', '2018-05-17', 251, 'Admin', now(), 'Admin', now(), 751, 0, 'CDR', '12:15', 1);
    
    INSERT INTO vietnamdsc.arrival_schedule(
                commodity, tendered, shipment_period, vessel_name, warehouse, eta_date, 
    arrival_schedule_id, created_user, created_date, modified_user, modified_date, contract_id, approvedquantity, delivery_basis, eta_time, arrival_sequence)
                VALUES ('Corn', 'Y', '30 days', 'AEGEAN SEA I', 'SITV', '2018-05-17', 252, 'Admin', now(), 'Admin', now(), 752, 0, 'CDR', '12:15', 1);
    
    INSERT INTO vietnamdsc.arrival_schedule(
                commodity, tendered, shipment_period, vessel_name, warehouse, eta_date, 
    arrival_schedule_id, created_user, created_date, modified_user, modified_date, contract_id, approvedquantity, delivery_basis, eta_time, arrival_sequence)
                VALUES ('Corn', 'Y', '30 days', 'AEGEAN SEA II', 'SITV', '2018-06-17', 253, 'Admin', now(), 'Admin', now(), 752, 0, 'CDR', '12:15', 2);
    
    INSERT INTO vietnamdsc.arrival_schedule(
                commodity, tendered, shipment_period, vessel_name, warehouse, eta_date, 
    arrival_schedule_id, created_user, created_date, modified_user, modified_date, contract_id, approvedquantity, delivery_basis, eta_time, arrival_sequence)
                VALUES ('Wheat', 'Y', '30 days', 'BUTTERFLY I', 'SITV', '2018-05-10', 254, 'Admin', now(), 'Admin', now(), 753, 50, 'CPK', '12:15', 1);
    
    INSERT INTO vietnamdsc.arrival_schedule(
                commodity, tendered, shipment_period, vessel_name, warehouse, eta_date, 
    arrival_schedule_id, created_user, created_date, modified_user, modified_date, contract_id, approvedquantity, delivery_basis, eta_time, arrival_sequence)
                VALUES ('Wheat', 'Y', '30 days', 'BUTTERFLY II', 'SITV', '2018-05-10', 255 ,'Admin', now(), 'Admin', now(), 753, 50, 'CPK', '12:15', 2);
    
    INSERT INTO vietnamdsc.arrival_schedule(
                commodity, tendered, shipment_period, vessel_name, warehouse, eta_date, 
    arrival_schedule_id, created_user, created_date, modified_user, modified_date, contract_id, approvedquantity, delivery_basis, eta_time, arrival_sequence)
                VALUES ('Wheat', 'Y', '30 days', 'CARGILL LINE I', 'SITV', '2018-05-10', 256, 'Admin', now(), 'Admin', now(), 754, 150, 'CPK', '12:15', 1);
    
    INSERT INTO vietnamdsc.arrival_schedule(
                commodity, tendered, shipment_period, vessel_name, warehouse, eta_date, 
    arrival_schedule_id, created_user, created_date, modified_user, modified_date, contract_id, approvedquantity, delivery_basis, eta_time, arrival_sequence)
                VALUES ('Wheat', 'Y', '30 days', 'CARGILL LINE II', 'SITV', '2018-06-10', 257, 'Admin', now(), 'Admin', now(), 754, 50, 'CPK', '12:15', 2);
    
     INSERT INTO vietnamdsc.arrival_schedule(
                commodity, tendered, shipment_period, vessel_name, warehouse, eta_date, 
    arrival_schedule_id, created_user, created_date, modified_user, modified_date, contract_id, approvedquantity, delivery_basis, eta_time, arrival_sequence)
                VALUES ('Maize', 'Y', '30 days', 'CARGILL LINE I', 'SITV', '2018-05-10', 258, 'Admin', now(), 'Admin', now(), 755, 50, 'CPK', '12:15', 1);
   
    INSERT INTO vietnamdsc.arrival_schedule(
                commodity, tendered, shipment_period, vessel_name, warehouse, eta_date, 
    arrival_schedule_id, created_user, created_date, modified_user, modified_date, contract_id, approvedquantity, delivery_basis, eta_time, arrival_sequence)
                VALUES ('Maize', 'Y', '30 days', 'CARGILL', 'SITV', '2018-04-10', 259, 'Admin', now(), 'Admin', now(), 756, 250, 'CPK', '12:15', 1);
