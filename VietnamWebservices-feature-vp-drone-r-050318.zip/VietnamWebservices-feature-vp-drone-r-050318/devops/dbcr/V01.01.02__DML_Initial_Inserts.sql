INSERT INTO vietnamdsc.contract_type(
	contract_type, contract_type_id, created_user, created_date, modified_user, modified_date, contract_category)
	VALUES ('Service', 1, 'rk@crgl.com', now(), 'rk@crgl.com', now(), 'VNGOSC');

INSERT INTO vietnamdsc.status(
	status_id, status_type, description, created_user, created_date, modified_user, modified_date, screen)
	VALUES (1, 'OPN','Open', 'rk@crgl.com', now(), 'rk@crgl.com', now(), 'contract');
	
INSERT INTO vietnamdsc.status(
	status_id, status_type, description, created_user, created_date, modified_user, modified_date, screen)
	VALUES (2, 'SGN','Signed', 'rk@crgl.com', now(), 'rk@crgl.com', now(), 'contract');
	
INSERT INTO vietnamdsc.status(
	status_id, status_type, description, created_user, created_date, modified_user, modified_date, screen)
	VALUES (3, 'PND','Pending', 'rk@crgl.com', now(), 'rk@crgl.com', now(), 'contract');
	
INSERT INTO vietnamdsc.status(
	status_id, status_type, description, created_user, created_date, modified_user, modified_date, screen)
	VALUES (4, 'CMP','Completed', 'rk@crgl.com', now(), 'rk@crgl.com', now(), 'contract');
	
INSERT INTO vietnamdsc.status(
	status_id, status_type, description, created_user, created_date, modified_user, modified_date, screen)
	VALUES (5, 'PD','Paid', 'rk@crgl.com', now(), 'rk@crgl.com', now(), 'payment');
	
INSERT INTO vietnamdsc.status(
	status_id, status_type, description, created_user, created_date, modified_user, modified_date, screen)
	VALUES (6, 'NPD','Not Paid', 'rk@crgl.com', now(), 'rk@crgl.com', now(), 'payment');
	
INSERT INTO vietnamdsc.status(
	status_id, status_type, description, created_user, created_date, modified_user, modified_date, screen)
	VALUES (7, 'VF','Verifying', 'rk@crgl.com', now(), 'rk@crgl.com', now(), 'payment');
	
INSERT INTO vietnamdsc.setup_alert(
	alert_id, alert_code, description, web, message, created_user, created_date, modified_user, modified_date, contract_category)
	VALUES (1, 100, 'Payment Remainder Alert', 'Y', 'N', 'rk@crgl.com', now(), 'rk@crgl.com', now(), 'VNGOSC');
	
INSERT INTO vietnamdsc.setup_alert(
	alert_id, alert_code, description, web, message, created_user, created_date, modified_user, modified_date, contract_category)
    VALUES (2, 101, 'Payment Advice Alert', 'Y', 'N', 'rk@crgl.com', now(), 'rk@crgl.com', now(), 'VNGOSC');
	
INSERT INTO vietnamdsc.setup_alert(
	alert_id, alert_code, description, web, message, created_user, created_date, modified_user, modified_date, contract_category)
	VALUES (3, 1, 'Invoice Remainder Alert', 'Y', 'N', 'rk@crgl.com', now(), 'rk@crgl.com', now(), 'VNGOSC');

INSERT INTO vietnamdsc.contract_type(
	contract_type, contract_type_id, created_user, created_date, modified_user, modified_date, contract_category)
	VALUES ('Sales', 2, 'rk@crgl.com', now(), 'rk@crgl.com', now(), 'VNGOSC');
	
INSERT INTO vietnamdsc.customer(
	customer_id, customer_name, contract_category, created_user, created_date, modified_user, modified_date, active_flag)
	VALUES (1,'john','VNGOSC','Admin','2018-02-14','Admin','2018-02-14','Y');

INSERT INTO vietnamdsc.screens(
	contract_category, screen_id, screen_code, screen_name, screen_desc, f_active, created_user, created_date, modified_user, modified_date)
	VALUES ('VNGOSC',1,'SRC','Service Contracts','Service Contracts','Y','rk@crgl.com','2018-02-22','rk@crgl.com','2018-02-22');
    
INSERT INTO vietnamdsc.screens(
	contract_category, screen_id, screen_code, screen_name, screen_desc, f_active, created_user, created_date, modified_user, modified_date)
	VALUES ('VNGOSC',2,'SLC','Sales Contracts','Sales Contracts','Y','rk@crgl.com','2018-02-22','rk@crgl.com','2018-02-22');

INSERT INTO vietnamdsc.screens(
	contract_category, screen_id, screen_code, screen_name, screen_desc, f_active, created_user, created_date, modified_user, modified_date)
	VALUES ('VNGOSC',3,'TIV','Total Inventory','Total Inventory','Y','rk@crgl.com','2018-02-22','rk@crgl.com','2018-02-22');
	
INSERT INTO vietnamdsc.screen_sections(
	section_id, section_code, section_name, section_desc, screen_id, f_active, created_user, created_date, modified_user, modified_date)
	VALUES (1,'CAK','Cak Details','Cak Details',1,'Y','rk@crgl.com','2018-02-22','rk@crgl.com','2018-02-22');
    
INSERT INTO vietnamdsc.screen_sections(
	section_id, section_code, section_name, section_desc, screen_id, f_active, created_user, created_date, modified_user, modified_date)
	VALUES ( 2,'PAY','Payments','Payments',1,'Y','rk@crgl.com','2018-02-22','rk@crgl.com','2018-02-22');
    
INSERT INTO vietnamdsc.screen_sections(
	section_id, section_code, section_name, section_desc, screen_id, f_active, created_user, created_date, modified_user, modified_date)
	VALUES (3,'ARSC','Arrival Schedule','Arrival Schedule',1,'Y','rk@crgl.com','2018-02-22','rk@crgl.com','2018-02-22');
	
INSERT INTO vietnamdsc.section_attributes(
	attribute_id, attribute_code, attribute_name, attribute_desc, section_id, attribute_value, attribute_category, f_active, created_user, created_date, modified_user, modified_date)
	VALUES (1,'ED','Edit','Edit',1,'Edit','VNGOSC','Y','rk@crgl.com','2018-02-22','rk@crgl.com','2018-02-22');
	
INSERT INTO vietnamdsc.section_attributes(
	attribute_id, attribute_code, attribute_name, attribute_desc, section_id, attribute_value, attribute_category, f_active, created_user, created_date, modified_user, modified_date)
	VALUES (2,'UPL','Upload Contract','Upload Contract',1,'Upload Contract','VNGOSC','Y','rk@crgl.com','2018-02-22','rk@crgl.com','2018-02-22');
	
INSERT INTO vietnamdsc.section_attributes(
	attribute_id, attribute_code, attribute_name, attribute_desc, section_id, attribute_value, attribute_category, f_active, created_user, created_date, modified_user, modified_date)
	VALUES (3,'ED','Edit','Edit',2,'Edit','VNGOSC','Y','rk@crgl.com','2018-02-22','rk@crgl.com','2018-02-22');
	
INSERT INTO vietnamdsc.section_attributes(
	attribute_id, attribute_code, attribute_name, attribute_desc, section_id, attribute_value, attribute_category, f_active, created_user, created_date, modified_user, modified_date)
	VALUES (4,'DEL','Delete','Delete',2,'Edit','VNGOSC','Y','rk@crgl.com','2018-02-22','rk@crgl.com','2018-02-22');
	
INSERT INTO vietnamdsc.section_attributes(
	attribute_id, attribute_code, attribute_name, attribute_desc, section_id, attribute_value, attribute_category, f_active, created_user, created_date, modified_user, modified_date)
	VALUES (5,'AD','ADD','ADD',2,'ADD','VNGOSC','Y','rk@crgl.com','2018-02-22','rk@crgl.com','2018-02-22');
	
INSERT INTO vietnamdsc.user_profile(
	user_profile_id, user_id, email, firstname, lastname, language, customer_id, active_flag, cargill_user, created_user, created_date, modified_user, modified_date)
	VALUES (1,'rk@crgl.com','rk@crgl.com','John','K','','123','Y','Y','rk@crgl.com','2018-02-22','rk@crgl.com','2018-02-22');
	
INSERT INTO vietnamdsc.user_profile(
	user_profile_id, user_id, email, firstname, lastname, language, customer_id, active_flag, cargill_user, created_user, created_date, modified_user, modified_date)
	VALUES (2,'raju@crgl.com','raju@crgl.com','Raju','K','','122','Y','Y','rk@crgl.com','2018-02-22','rk@crgl.com','2018-02-22');
	
INSERT INTO vietnamdsc.user_config(
	user_config_id, user_id, screen_id, section_id, attribute_id, attribute_value, f_active, user_configcol, contract_category, created_user, created_date, modified_user, modified_date)
	VALUES (1, 'rk@crgl.com', 1, 1, 1, 'value', 'Y', '', 'VNGOSC', 'rk@crgl.com', now(), 'rk@crgl.com', now());	
	
INSERT INTO vietnamdsc.alert_user_mapping(
	contract_category, alert_user_mapping_id, user_id, web, email, sms, active_flag, created_user, created_date, modified_user, modified_date, alert_id)
	VALUES ('VNGOSC',1,'rk@crgl.com','Y','rk@crgl.com','N','Y','rk@crgl.com','2018-02-23','rk@crgl.com','2018-02-23',1);
	
INSERT INTO vietnamdsc.contract(
	cak_no, cak_date, commodity, quantity, contract_type_id, customer_id, status_id, contract_id, created_user, created_date, modified_user, modified_date, active_flag, contract_category, tendered_input, basis, storage_terms, tolarance, unit_price, package_type, ship_period, contract_price, destination, final_weightat, cargo_origin, currency, payment_terms, received, balance_stock, erp_contract_status)
	VALUES (1, '2017-12-12', 46, 50, 1, 123, 'OPN', 1, 'rk@crgl.com', now(), 'rk@crgl.com', now(), 'Y', 'VNGOSC', 10, 'basis', null, 0, 60, null, null, 50, null, null, null, null, null, 10, 25, 1);
	
INSERT INTO vietnamdsc.payment(
	status, date, amount, document, filename, payment_id, created_user, created_date, modified_user, modified_date, active_flag, contract_id)
	VALUES ('NPD', '2017-12-12', '1500', null, '', 1, 'rk@crgl.com', now(), 'rk@crgl.com', now(), 'Y', 1);

INSERT INTO vietnamdsc.approved_quantity(
	contract_id, approved_qty, approved_qty_id, created_user, created_date, modified_user, modified_date)
	VALUES (1,100,1,'rk@crgl.com','2018-02-23','rk@crgl.com','2018-02-23');
	
INSERT INTO vietnamdsc.market_information(
	heading, details, market_id, status, contract_type, created_user, created_date, modified_user, modified_date, active_flag, contract_category)
	VALUES ('mark','descr',1,'status','service','rk@crgl.com','2018-02-08','rk@crgl.com','2018-02-08','Y','VNGOSC');

INSERT INTO vietnamdsc.market_information(
	heading, details, market_id, status, contract_type, created_user, created_date, modified_user, modified_date, active_flag, contract_category)
	VALUES ('mark','descr',2,'status','service','rk@crgl.com','2018-02-12','rk@crgl.com','2018-02-12','Y','VNGOSC');
    
INSERT INTO vietnamdsc.market_information(
	heading, details, market_id, status, contract_type, created_user, created_date, modified_user, modified_date, active_flag, contract_category)
	VALUES ('marketinfo','descr',3,'status','service','rk@crgl.com','2018-02-08','rk@crgl.com','2018-02-08','Y','VNGOSC');
	
INSERT INTO vietnamdsc.market_information(
    heading, details, market_id, status, contract_type, created_user, created_date, modified_user, modified_date, active_flag, contract_category)
    VALUES ('marketinfo','descr',4,'status','service','rk@crgl.com','2018-02-08','rk@crgl.com','2018-02-08','Y','VNGOSC');

INSERT INTO vietnamdsc.inventory(
	cargo, vehicle_type, vehicle_no, time_in, weight_in, time_out, weight_out, total_weight, packing, mode, location, pickup_id, cak_no, inventory_id, remark, contract_id, created_user, created_date, modified_user, modified_date, active_flag, net_weight, eta)
	VALUES ('Wheat','Bus','TN23R456','2017-04-04 04:03:35','10.00','2017-04-04 04:03:35','11.00','26.00','Bulk','Vessel','VTN',1,1,1,'waiting',1,'rk@crgl.com','2018-02-22','rk@crgl.com','2018-02-22','Y','15','2017-04-04');
	
INSERT INTO vietnamdsc.arrival_schedule(
	cargo, volume, tendered, shipment_period, vessel_name, warehouse, eta, arrival_schedule_id, created_user, created_date, modified_user, modified_date, approved_qty_id, contract_id)
	VALUES ('Mark', 10, 'tendered', 10, 'Vessel', 'ware', '2017-12-05', 1, 'rk@crgl.com', now(), 'rk@crgl.com', now(), 1, 1);
	
INSERT INTO vietnamdsc.invoice(
	invoice_no, invoice_id, invoice_date, cargo_volume, invoice_amount, document, created_user, created_date, modified_user, modified_date, cargo_name, contract_id)
	VALUES (12345, 1, '2017-12-16', 15000, 200000, null, 'rk@crgl.com', now(), 'rk@crgl.com', now(), '', 1);
	
INSERT INTO vietnamdsc.pickup_schedule(
	pickup_id, contract_id, cak_no, pickupdate, approvedpickupdate, proposedpickupdate, filename, document, pickup_qty, approved_qty_id, created_user, created_date, modified_user, modified_date, active_flag, status)
	VALUES (1, 1, 1, '2017-04-04 04:03:35', '2017-04-04 04:03:35', '2017-04-04 04:03:35', '', null, 10, 1, 'rk@crgl.com', now(), 'rk@crgl.com', now(), 'Y', 'agree');
