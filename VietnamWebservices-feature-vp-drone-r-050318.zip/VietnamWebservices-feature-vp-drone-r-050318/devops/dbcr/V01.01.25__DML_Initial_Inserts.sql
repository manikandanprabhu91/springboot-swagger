update setup_alert set message = 'Payment advise verified for ContractId %contractId% and PaymentId %paymentId%.' where alert_code=101;
update setup_alert set message = 'Payment advise uploaded for ContractId %contractId%. Please check.' where alert_code=102;
update setup_alert set message = 'Pickup Schedule added by customer for ContractId %contractId% and Pickup Id %pickId%' where alert_code=201;
update setup_alert set message = 'Pickup Schedule denied for ContractId %contractId% and Pickup Id %pickId%. Please choose another slot.' where alert_code=202;
update setup_alert set message = 'Pickup Schedule approved for ContractId No %contractId% and Pickup Id %pickId%.' where alert_code=203;