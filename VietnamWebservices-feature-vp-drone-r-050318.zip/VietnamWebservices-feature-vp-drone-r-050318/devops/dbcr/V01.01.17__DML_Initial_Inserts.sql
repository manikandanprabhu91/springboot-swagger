Alter table pickup_schedule add column pickup_time TIME not null default '00:00';
Alter table pickup_schedule alter column pickupdate type date;
Alter table pickup_schedule alter column approvedpickupdate type date;
Alter table pickup_schedule alter column proposedpickupdate type date;
Alter table pickup_schedule add column approvedpickup_time TIME not null default '00:00';
Alter table pickup_schedule add column proposedpickup_time TIME not null default '00:00';
Alter table pickup_schedule rename approved_qty_id to arrival_schedule_id;