-- Database: dscportaldevpostgres

ALTER DATABASE dscportaldevpostgres
    SET search_path TO "$user", vietnamdsc, dscportaldevpostgres; 
	
-- SCHEMA: vietnamdsc

CREATE SCHEMA IF NOT EXISTS vietnamdsc
    AUTHORIZATION dscportaldevadmin; 
  
  CREATE TABLE IF NOT EXISTS vietnamdsc.actual_alert (
  actual_user_id VARCHAR(50) NULL DEFAULT NULL,
  alert_id INT NULL DEFAULT NULL,
  message VARCHAR(150) NULL DEFAULT NULL,
  web VARCHAR(10) NULL DEFAULT NULL,
  email VARCHAR(50) NULL DEFAULT NULL,
  sms VARCHAR(50) NULL DEFAULT NULL,
  actual_alert_id SERIAL PRIMARY KEY,
  created_user VARCHAR(50) NULL DEFAULT NULL,
  created_date DATE NULL DEFAULT NULL,
  modified_user VARCHAR(50) NULL DEFAULT NULL,
  modified_date DATE NULL DEFAULT NULL,
  contract_category VARCHAR(50) NULL DEFAULT NULL,
  status VARCHAR(10) NOT NULL);
  
  CREATE TABLE IF NOT EXISTS vietnamdsc.setup_alert (
  alert_id SERIAL PRIMARY KEY,
  alert_code INT NULL DEFAULT NULL,
  description VARCHAR(50) NULL DEFAULT NULL,
  web VARCHAR(10) NULL DEFAULT NULL,
  message VARCHAR(150) NULL DEFAULT NULL,
  created_user VARCHAR(50) NULL DEFAULT NULL,
  created_date DATE NULL DEFAULT NULL,
  modified_user VARCHAR(50) NULL DEFAULT NULL,
  modified_date DATE NULL DEFAULT NULL,
  contract_category VARCHAR(50) NULL DEFAULT NULL);
  
   CREATE TABLE IF NOT EXISTS vietnamdsc.alert_user_mapping (
  contract_category VARCHAR(50) NULL DEFAULT NULL,
  alert_user_mapping_id SERIAL PRIMARY KEY,
  user_id VARCHAR(50) NULL DEFAULT NULL,
  web VARCHAR(10) NULL DEFAULT NULL,
  email VARCHAR(50) NULL DEFAULT NULL,
  sms VARCHAR(50) NULL DEFAULT NULL,
  active_flag VARCHAR(3) NULL DEFAULT NULL,
  created_user VARCHAR(50) NULL DEFAULT NULL,
  created_date DATE NULL DEFAULT NULL,
  modified_user VARCHAR(50) NULL DEFAULT NULL,
  modified_date DATE NULL DEFAULT NULL,
  alert_id INT NULL DEFAULT NULL,
  CONSTRAINT alert_id
    FOREIGN KEY (alert_id)
    REFERENCES vietnamdsc.setup_alert (alert_id)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);
  
  CREATE TABLE IF NOT EXISTS vietnamdsc.contract_type (
  contract_type VARCHAR(20) NULL DEFAULT NULL,
  contract_type_id SERIAL PRIMARY KEY,
  created_user VARCHAR(50) NULL DEFAULT NULL,
  created_date DATE NULL DEFAULT NULL,
  modified_user VARCHAR(50) NULL DEFAULT NULL,
  modified_date DATE NULL DEFAULT NULL,
  contract_category VARCHAR(45) NULL DEFAULT NULL);
  
  CREATE TABLE IF NOT EXISTS vietnamdsc.contract (
  cak_no INT NULL DEFAULT NULL,
  cak_date DATE NULL DEFAULT NULL,
  commodity VARCHAR(50) NULL DEFAULT NULL,
  quantity INT NULL DEFAULT NULL,
  contract_type_id INT NULL DEFAULT NULL,
  customer_id VARCHAR(50) NULL DEFAULT NULL,
  status_id VARCHAR(50) NULL DEFAULT NULL,
  contract_id SERIAL PRIMARY KEY,
  created_user VARCHAR(50) NULL DEFAULT NULL,
  created_date DATE NULL DEFAULT NULL,
  modified_user VARCHAR(50) NULL DEFAULT NULL,
  modified_date DATE NULL DEFAULT NULL,
  active_flag VARCHAR(3) NULL DEFAULT NULL,
  contract_category VARCHAR(45) NULL DEFAULT NULL,
  tendered_input INT NULL DEFAULT NULL,
  basis VARCHAR(45) NULL DEFAULT NULL,
  storage_terms VARCHAR(45) NULL DEFAULT NULL,
  tolarance INT NULL DEFAULT NULL,
  unit_price INT NULL DEFAULT NULL,
  package_type VARCHAR(45) NULL DEFAULT NULL,
  ship_period VARCHAR(45) NULL DEFAULT NULL,
  contract_price INT NULL DEFAULT NULL,
  destination VARCHAR(45) NULL DEFAULT NULL,
  final_weightat VARCHAR(45) NULL DEFAULT NULL,
  cargo_origin VARCHAR(45) NULL DEFAULT NULL,
  currency VARCHAR(45) NULL DEFAULT NULL,
  payment_terms VARCHAR(45) NULL DEFAULT NULL,
  received INT NULL DEFAULT NULL,
  balance_stock INT NULL DEFAULT NULL,
  erp_contract_status INT NULL DEFAULT NULL,
  CONSTRAINT contract_type_id
    FOREIGN KEY (contract_type_id)
    REFERENCES vietnamdsc.contract_type (contract_type_id)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);
  
 CREATE TABLE IF NOT EXISTS vietnamdsc.approved_quantity (
  contract_id INT NULL DEFAULT NULL,
  approved_qty INT NULL DEFAULT NULL,
  approved_qty_id SERIAL PRIMARY KEY,
  created_user VARCHAR(50) NULL DEFAULT NULL,
  created_date DATE NULL DEFAULT NULL,
  modified_user VARCHAR(50) NULL DEFAULT NULL,
  modified_date DATE NULL DEFAULT NULL,
  CONSTRAINT contract_id
    FOREIGN KEY (contract_id)
    REFERENCES vietnamdsc.contract (contract_id)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);
  
   CREATE TABLE IF NOT EXISTS vietnamdsc.arrival_schedule (
  cargo VARCHAR(50) NULL DEFAULT NULL,
  volume VARCHAR(50) NULL DEFAULT NULL,
  tendered VARCHAR(50) NULL DEFAULT NULL,
  shipment_period VARCHAR(50) NULL DEFAULT NULL,
  vessel_name VARCHAR(50) NULL DEFAULT NULL,
  warehouse VARCHAR(50) NULL DEFAULT NULL,
  eta DATE NULL DEFAULT NULL,
  arrival_schedule_id SERIAL PRIMARY KEY,
  created_user VARCHAR(50) NULL DEFAULT NULL,
  created_date DATE NULL DEFAULT NULL,
  modified_user VARCHAR(50) NULL DEFAULT NULL,
  modified_date DATE NULL DEFAULT NULL,
  approved_qty_id INT NULL DEFAULT NULL,
  contract_id INT NULL DEFAULT NULL,
  CONSTRAINT contract_id
    FOREIGN KEY (contract_id)
    REFERENCES vietnamdsc.contract (contract_id)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);
  
  CREATE TABLE IF NOT EXISTS vietnamdsc.chat (
  user_Id VARCHAR(50) NULL DEFAULT NULL,
  cak_no INT NULL DEFAULT NULL,
  chennal_id VARCHAR(50) NULL DEFAULT NULL,
  document VARCHAR(50) NULL DEFAULT NULL,
  message_details VARCHAR(150) NULL DEFAULT NULL,
  Contract_type VARCHAR(50) NULL DEFAULT NULL,
  created_user VARCHAR(50) NULL DEFAULT NULL,
  created_date DATE NULL DEFAULT NULL,
  modified_user VARCHAR(50) NULL DEFAULT NULL,
  modified_date DATE NULL DEFAULT NULL);
  
  CREATE TABLE IF NOT EXISTS vietnamdsc.code_type (
  code VARCHAR(50) NULL DEFAULT NULL,
  description VARCHAR(100) NULL DEFAULT NULL,
  language VARCHAR(50) NULL DEFAULT NULL,
  code_id SERIAL PRIMARY KEY,
  group_id INT NULL DEFAULT NULL,
  created_user VARCHAR(50) NULL DEFAULT NULL,
  created_date DATE NULL DEFAULT NULL,
  modified_user VARCHAR(50) NULL DEFAULT NULL,
  modified_date DATE NULL DEFAULT NULL,
  contract_category VARCHAR(45) NULL DEFAULT NULL);
  
   CREATE TABLE IF NOT EXISTS vietnamdsc.country (
  country_code VARCHAR(50) NULL DEFAULT NULL,
  country_name VARCHAR(50) NULL DEFAULT NULL,
  country_id SERIAL PRIMARY KEY,
  created_user VARCHAR(50) NULL DEFAULT NULL,
  created_date DATE NULL DEFAULT NULL,
  modified_user VARCHAR(50) NULL DEFAULT NULL,
  modified_date DATE NULL DEFAULT NULL,
  country_prefix VARCHAR(45) NULL DEFAULT NULL);
  
CREATE TABLE IF NOT EXISTS vietnamdsc.customer (
  customer_id SERIAL PRIMARY KEY,
  customer_name VARCHAR(45) NULL DEFAULT NULL,
  contract_category VARCHAR(45) NULL DEFAULT NULL,
  created_user VARCHAR(45) NULL DEFAULT NULL,
  created_date DATE NULL DEFAULT NULL,
  modified_user VARCHAR(45) NULL DEFAULT NULL,
  modified_date DATE NULL DEFAULT NULL,
  active_flag VARCHAR(5) NULL DEFAULT NULL);
  
   CREATE TABLE IF NOT EXISTS vietnamdsc.inventory (
  cargo VARCHAR(50) NULL DEFAULT NULL,
  vehicle_type VARCHAR(20) NULL DEFAULT NULL,
  vehicle_no VARCHAR(100) NULL DEFAULT NULL,
  time_in TIMESTAMP NULL DEFAULT NULL,
  weight_in DECIMAL(20,2) NULL DEFAULT NULL,
  time_out TIMESTAMP NULL DEFAULT NULL,
  weight_out DECIMAL(20,2) NULL DEFAULT NULL,
  total_weight DECIMAL(20,2) NULL DEFAULT NULL,
  packing VARCHAR(50) NULL DEFAULT NULL,
  mode VARCHAR(50) NULL DEFAULT NULL,
  location VARCHAR(50) NULL DEFAULT NULL,
  pickup_id INT NULL DEFAULT NULL,
  cak_no INT NULL DEFAULT NULL,
  inventory_id SERIAL PRIMARY KEY,
  remark VARCHAR(250) NULL DEFAULT NULL,
  contract_id INT NULL DEFAULT NULL,
  created_user VARCHAR(50) NULL DEFAULT NULL,
  created_date DATE NULL DEFAULT NULL,
  modified_user VARCHAR(50) NULL DEFAULT NULL,
  modified_date DATE NULL DEFAULT NULL,
  active_flag VARCHAR(3) NULL DEFAULT NULL,
  net_weight DECIMAL(19,0) NULL DEFAULT NULL,
  eta DATE NULL DEFAULT NULL,
  CONSTRAINT contract_id
    FOREIGN KEY (contract_id)
    REFERENCES vietnamdsc.contract (contract_id)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);
  
   CREATE TABLE IF NOT EXISTS vietnamdsc.invoice (
  invoice_no INT NULL DEFAULT NULL,
  invoice_id SERIAL PRIMARY KEY,
  invoice_date DATE NULL DEFAULT NULL,
  cargo_volume VARCHAR(50) NULL DEFAULT NULL,
  invoice_amount DECIMAL(20,2) NULL DEFAULT NULL,
  document text NULL DEFAULT NULL,
  created_user VARCHAR(50) NULL DEFAULT NULL,
  created_date DATE NULL DEFAULT NULL,
  modified_user VARCHAR(50) NULL DEFAULT NULL,
  modified_date DATE NULL DEFAULT NULL,
  cargo_name VARCHAR(50) NULL DEFAULT NULL,
  contract_id INT NULL DEFAULT NULL,
  CONSTRAINT contract_id
    FOREIGN KEY (contract_id)
    REFERENCES vietnamdsc.contract (contract_id)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);
  
   CREATE TABLE IF NOT EXISTS vietnamdsc.market_information (
  heading VARCHAR(100) NULL DEFAULT NULL,
  details VARCHAR(100) NULL DEFAULT NULL,
  market_id SERIAL PRIMARY KEY,
  status VARCHAR(20) NULL DEFAULT NULL,
  contract_type VARCHAR(50) NULL DEFAULT NULL,
  created_user VARCHAR(50) NULL DEFAULT NULL,
  created_date DATE NULL DEFAULT NULL,
  modified_user VARCHAR(50) NULL DEFAULT NULL,
  modified_date DATE NULL DEFAULT NULL,
  active_flag VARCHAR(3) NULL DEFAULT NULL,
  contract_category VARCHAR(45) NULL DEFAULT NULL);
  
      CREATE TABLE IF NOT EXISTS vietnamdsc.payment (
  status VARCHAR(50) NULL DEFAULT NULL,
  date DATE NULL DEFAULT NULL,
  amount DECIMAL(20,2) NULL DEFAULT NULL,
  document text NULL DEFAULT NULL,
  filename VARCHAR(50) NULL DEFAULT NULL,
  payment_id SERIAL PRIMARY KEY,
  created_user VARCHAR(50) NULL DEFAULT NULL,
  created_date DATE NULL DEFAULT NULL,
  modified_user VARCHAR(50) NULL DEFAULT NULL,
  modified_date DATE NULL DEFAULT NULL,
  active_flag VARCHAR(3) NULL DEFAULT NULL,
  contract_id INT NULL DEFAULT NULL,
  CONSTRAINT contract_id
    FOREIGN KEY (contract_id)
    REFERENCES vietnamdsc.contract (contract_id)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);
  
 CREATE TABLE IF NOT EXISTS vietnamdsc.pickup_schedule (
  pickup_id SERIAL PRIMARY KEY,
  contract_id INT NULL DEFAULT NULL,
  cak_no INT NULL DEFAULT NULL,
  pickUpDate timestamp NULL DEFAULT NULL,
  approvedPickUpDate timestamp NULL DEFAULT NULL,
  proposedPickUpDate timestamp NULL DEFAULT NULL,
  filename VARCHAR(50) NULL DEFAULT NULL,
  document text NULL DEFAULT NULL,
  pickup_qty INT NULL DEFAULT NULL,
  approved_qty_id INT NULL DEFAULT NULL,
  created_user VARCHAR(50) NULL DEFAULT NULL,
  created_date DATE NULL DEFAULT NULL,
  modified_user VARCHAR(50) NULL DEFAULT NULL,
  modified_date DATE NULL DEFAULT NULL,
  active_flag VARCHAR(3) NULL DEFAULT NULL,
  status VARCHAR(45) NULL DEFAULT NULL);
  
    CREATE TABLE IF NOT EXISTS vietnamdsc.screen_sections (
  section_id SERIAL PRIMARY KEY,
  section_code VARCHAR(100) NULL DEFAULT NULL,
  section_name VARCHAR(100) NULL DEFAULT NULL,
  section_desc VARCHAR(250) NULL DEFAULT NULL,
  screen_id INT NULL DEFAULT NULL,
  f_active VARCHAR(1) NULL DEFAULT NULL,
  created_user VARCHAR(50) NULL DEFAULT NULL,
  created_date DATE NULL DEFAULT NULL,
  modified_user VARCHAR(50) NULL DEFAULT NULL,
  modified_date DATE NULL DEFAULT NULL);
  
 CREATE TABLE IF NOT EXISTS vietnamdsc.screens (
  contract_category VARCHAR(22) NULL DEFAULT NULL,
  screen_id SERIAL PRIMARY KEY,
  screen_code VARCHAR(100) NULL DEFAULT NULL,
  screen_name VARCHAR(100) NULL DEFAULT NULL,
  screen_desc VARCHAR(250) NULL DEFAULT NULL,
  f_active VARCHAR(1) NULL DEFAULT NULL,
  created_user VARCHAR(50) NULL DEFAULT NULL,
  created_date DATE NULL DEFAULT NULL,
  modified_user VARCHAR(50) NULL DEFAULT NULL,
  modified_date DATE NULL DEFAULT NULL);
  
CREATE TABLE IF NOT EXISTS vietnamdsc.section_attributes (
  attribute_id SERIAL PRIMARY KEY,
  attribute_code VARCHAR(100) NULL DEFAULT NULL,
  attribute_name VARCHAR(100) NULL DEFAULT NULL,
  attribute_desc VARCHAR(250) NULL DEFAULT NULL,
  section_id INT NULL DEFAULT NULL,
  attribute_value VARCHAR(200) NULL DEFAULT NULL,
  attribute_category VARCHAR(200) NULL DEFAULT NULL,
  f_active VARCHAR(1) NULL DEFAULT NULL,
  created_user VARCHAR(50) NULL DEFAULT NULL,
  created_date DATE NULL DEFAULT NULL,
  modified_user VARCHAR(50) NULL DEFAULT NULL,
  modified_date DATE NULL DEFAULT NULL);
  
CREATE TABLE IF NOT EXISTS vietnamdsc.status (
  status_id SERIAL PRIMARY KEY,
  status_type VARCHAR(50) NULL DEFAULT NULL,
  description VARCHAR(50) NULL DEFAULT NULL,
  created_user VARCHAR(50) NULL DEFAULT NULL,
  created_date DATE NULL DEFAULT NULL,
  modified_user VARCHAR(50) NULL DEFAULT NULL,
  modified_date DATE NULL DEFAULT NULL,
  screen VARCHAR(45) NULL DEFAULT NULL);
  
CREATE TABLE IF NOT EXISTS vietnamdsc.user_config (
  user_config_id SERIAL PRIMARY KEY,
  user_id VARCHAR(100) NULL DEFAULT NULL,
  screen_id INT NULL DEFAULT NULL,
  section_id INT NULL DEFAULT NULL,
  attribute_id INT NULL DEFAULT NULL,
  attribute_value VARCHAR(200) NULL DEFAULT NULL,
  f_active VARCHAR(45) NULL DEFAULT NULL,
  user_configcol VARCHAR(45) NULL DEFAULT NULL,
  contract_category VARCHAR(20) NULL DEFAULT NULL,
  created_user VARCHAR(50) NULL DEFAULT NULL,
  created_date DATE NULL DEFAULT NULL,
  modified_user VARCHAR(50) NULL DEFAULT NULL,
  modified_date DATE NULL DEFAULT NULL);
  
  CREATE TABLE IF NOT EXISTS vietnamdsc.user_profile (
  user_profile_id SERIAL PRIMARY KEY,
  user_id VARCHAR(50) NOT NULL,
  email VARCHAR(50) NULL DEFAULT NULL,
  firstname VARCHAR(50) NULL DEFAULT NULL,
  lastname VARCHAR(50) NULL DEFAULT NULL,
  language VARCHAR(20) NULL DEFAULT NULL,
  customer_id VARCHAR(50) NULL DEFAULT NULL,
  active_flag VARCHAR(3) NULL DEFAULT NULL,
  cargill_user VARCHAR(10) NULL DEFAULT NULL,
  created_user VARCHAR(50) NULL DEFAULT NULL,
  created_date DATE NULL DEFAULT NULL,
  modified_user VARCHAR(50) NULL DEFAULT NULL,
  modified_date DATE NULL DEFAULT NULL);