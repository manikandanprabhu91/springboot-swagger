delete from contract where contract_id=4;
delete from contract where contract_id=5;
delete from contract where contract_id=6;
delete from contract where contract_id=7;
delete from contract where contract_id=8;
delete from contract where contract_id=9;
delete from contract where contract_id=10;
delete from contract where contract_id=11;