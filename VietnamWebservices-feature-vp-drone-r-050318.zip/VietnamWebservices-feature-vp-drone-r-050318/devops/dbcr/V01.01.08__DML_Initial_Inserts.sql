update contract set currency='value';
update contract set storage_terms='term';
update contract set payment_terms='Quartely';
update contract set package_type='Bulk';
update arrival_schedule set eta = '2018-04-20';
update contract set expiration_date = '2018-04-25';