Alter table  market_information drop column contract_type; 
alter table actual_alert drop column customer_id;
Alter table actual_alert add column customer_id integer default 1;