alter table vietnamdsc.actual_alert alter column customer_id type varchar(10);
alter table vietnamdsc.user_profile alter column customer_id type varchar(10);
alter table vietnamdsc.customer alter column customer_id type varchar(10);
alter table vietnamdsc.contract alter column customer_id type varchar(10);
Alter table contract add column customer_name varchar(40);
Update contract set customer_name='John';
Alter table inventory alter column cak_no type varchar(40);