CREATE TABLE vietnamdsc.alert_scheduler
(
    screen VARCHAR(25) NULL DEFAULT NULL,
    rule_days INT NULL DEFAULT NULL,
    created_date DATE NULL DEFAULT NULL,
    created_user VARCHAR(50) NULL DEFAULT NULL,
    modified_date DATE NULL DEFAULT NULL,
    modified_user VARCHAR(50) NULL DEFAULT NULL,
    active_flag VARCHAR(5) NULL DEFAULT NULL
);

INSERT INTO vietnamdsc.alert_scheduler(
	screen, rule_days, created_date, created_user, modified_date, modified_user, active_flag)
	VALUES ('contract', 15, now(),'Admin', now(),'Admin', 'Y');
	
INSERT INTO vietnamdsc.alert_scheduler(
	screen, rule_days, created_date, created_user, modified_date, modified_user, active_flag)
	VALUES ('contract', 7, now(),'Admin', now(),'Admin', 'Y');
	
INSERT INTO vietnamdsc.alert_scheduler(
	screen, rule_days, created_date, created_user, modified_date, modified_user, active_flag)
	VALUES ('contract', 3, now(),'Admin', now(),'Admin', 'Y');
	
INSERT INTO vietnamdsc.alert_scheduler(
	screen, rule_days, created_date, created_user, modified_date, modified_user, active_flag)
	VALUES ('contract', 1, now(),'Admin', now(),'Admin', 'Y');

	
	