update contract set status_id ='USGN' where contract_id=1;
update payment set amount = 1000 where contract_id=1;