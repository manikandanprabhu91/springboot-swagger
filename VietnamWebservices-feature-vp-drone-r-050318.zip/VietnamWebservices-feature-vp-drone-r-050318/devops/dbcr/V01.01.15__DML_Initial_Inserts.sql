Alter table arrival_schedule rename eta to eta_date;
Alter table arrival_schedule add column eta_time TIME not null default '00:00';