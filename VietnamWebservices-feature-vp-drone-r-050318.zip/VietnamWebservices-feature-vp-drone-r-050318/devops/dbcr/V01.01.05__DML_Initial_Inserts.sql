Alter table contract add column expiration_date date default null;
Alter table user_profile drop column customer_id;
Alter table user_profile add column customer_id integer;
Update user_profile set customer_id=1 ;