Alter table pickup_schedule drop column cak_no;
Alter table pickup_schedule drop column document;
Alter table pickup_schedule drop column proposedpickupdate;
Alter table pickup_schedule drop column proposedpickup_time;