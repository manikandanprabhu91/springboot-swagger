Alter table user_profile drop column firstname;
Alter table user_profile drop column lastname;
Alter table user_profile drop column language;
Alter table user_profile alter column customer_id type int;