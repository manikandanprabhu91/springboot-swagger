Alter table arrival_schedule rename cargo to commodity;
Alter table arrival_schedule alter column commodity type varchar(70);
Alter table arrival_schedule drop column approved_qty_id;
Alter table arrival_schedule drop column volume;
ALTER TABLE arrival_schedule add column approvedQuantity integer;
update arrival_schedule  set approvedQuantity = 30;
ALTER TABLE arrival_schedule add column delivery_basis varchar(45);
update arrival_schedule  set delivery_basis = 'basis';
delete from payment where contract_id=24;
delete from payment where contract_id=25;
delete from payment where contract_id=26;
delete from payment where contract_id=27;
delete from contract where cak_no=199;
delete from contract where cak_no=999;

	
	
	
	