alter table pickup_schedule alter column authorization_number type varchar(20);
