DROP TABLE actual_alert;

CREATE TABLE IF NOT EXISTS vietnamdsc.actual_alert (
  actual_alert_id SERIAL PRIMARY KEY,
  customer_id VARCHAR(50) NULL DEFAULT NULL,
  alert_id INT NULL DEFAULT NULL,
  actual_message VARCHAR(150) NULL DEFAULT NULL,
  contract_id INT NULL DEFAULT NULL,
  payment_id INT NULL DEFAULT NULL,
  invoice_id INT NULL DEFAULT NULL,
  created_user VARCHAR(50) NULL DEFAULT NULL,
  created_date DATE NULL DEFAULT NULL,
  modified_user VARCHAR(50) NULL DEFAULT NULL,
  modified_date DATE NULL DEFAULT NULL,
  contract_category VARCHAR(50) NULL DEFAULT NULL) ; 
  
  CREATE TABLE IF NOT EXISTS vietnamdsc.actual_alert_usermapping (
      actualalert_usermap_id SERIAL PRIMARY KEY,
      actual_alert_id INT NULL DEFAULT NULL,
      actual_user_id VARCHAR(50) NULL DEFAULT NULL,
      web VARCHAR(10) NULL DEFAULT NULL,
  	  email VARCHAR(50) NULL DEFAULT NULL,
      sms VARCHAR(50) NULL DEFAULT NULL,
      status_web VARCHAR(10) NOT NULL,
      status_email VARCHAR(10) NOT NULL,
      status_sms VARCHAR(10) NOT NULL,
      created_user VARCHAR(50) NULL DEFAULT NULL,
      created_date DATE NULL DEFAULT NULL,
      modified_user VARCHAR(50) NULL DEFAULT NULL,
      modified_date DATE NULL DEFAULT NULL,
      CONSTRAINT actual_alert_id
    FOREIGN KEY (actual_alert_id)
    REFERENCES vietnamdsc.actual_alert (actual_alert_id)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);
      
	  