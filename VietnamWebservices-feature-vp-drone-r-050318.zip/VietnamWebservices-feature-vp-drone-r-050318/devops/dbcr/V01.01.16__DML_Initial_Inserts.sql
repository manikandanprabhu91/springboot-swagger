Alter table payment drop column document;
Alter table payment rename date to payment_date;
Alter table payment rename amount to payment_amount;
Alter table payment add column bank_name varchar (50) not null default 'hdfc';
Alter table payment add column branch_name varchar (50) not null default 'ckc';
Alter table payment add column transaction_ref varchar (20) not null default 'A254';
Alter table payment add column time TIME not null default '00:00';
Alter table payment  alter column payment_amount type DECIMAL(20,3);
Alter table arrival_schedule add column arrival_sequence integer;
update arrival_schedule set arrival_sequence=1 where arrival_schedule_id=1;
update arrival_schedule set arrival_sequence=2 where arrival_schedule_id=2;
update arrival_schedule set arrival_sequence=3 where arrival_schedule_id=3;
update arrival_schedule set arrival_sequence=4 where arrival_schedule_id=4;
update arrival_schedule set arrival_sequence=5 where arrival_schedule_id=5;
update arrival_schedule set arrival_sequence=6 where arrival_schedule_id=6;
Alter table contract add column approvedQuantity integer default 0;

CREATE TABLE IF NOT EXISTS vietnamdsc.DeliveryBasis (
  basis_code VARCHAR(100) NULL DEFAULT NULL,
  basis_desc VARCHAR(100) NULL DEFAULT NULL,
  basis_id SERIAL PRIMARY KEY,  
  created_user VARCHAR(50) NULL DEFAULT NULL,
  created_date DATE NULL DEFAULT NULL,
  modified_user VARCHAR(50) NULL DEFAULT NULL,
  modified_date DATE NULL DEFAULT NULL,
  active_flag VARCHAR(3) NULL DEFAULT NULL
  );
  
  INSERT INTO vietnamdsc.deliverybasis(
	basis_code, basis_desc, basis_id, created_user, created_date, modified_user, modified_date, active_flag)
	VALUES ('CDR', 'Cargill Delivery', 1, 'rk@crgl.com', now(), 'rk@crgl.com', now(), 'Y');
	
	INSERT INTO vietnamdsc.deliverybasis(
	basis_code, basis_desc, basis_id, created_user, created_date, modified_user, modified_date, active_flag)
	VALUES ('CPK', 'Customer Pickup', 2, 'rk@crgl.com', now(), 'rk@crgl.com', now(), 'Y');