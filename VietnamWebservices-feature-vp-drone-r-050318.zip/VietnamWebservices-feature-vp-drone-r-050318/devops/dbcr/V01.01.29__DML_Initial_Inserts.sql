INSERT INTO vietnamdsc.setup_alert(
	 alert_id,alert_code, description, web, message, created_user, created_date, modified_user, modified_date, contract_category, alert_category)
	VALUES (10,104, 'Payment Due Alert', 'Y', 'Payment due for paymentId %paymentId%.Please check.', 'rk@crgl.com', now(), 'rk@crgl.com', now(), 'VNGOSC','Red');